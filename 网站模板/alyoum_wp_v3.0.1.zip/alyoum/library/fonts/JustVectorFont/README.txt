Author Info
========
The original author of these icons is Alex Peattie (http://www.alexpeattie.com).
I (Sergio D�az(http://www.martianwabbit.com)) just made the font out of Alex's lovely icon set.

License Info
========
The icons are distributed under the Free Art License, and as such can be copied, distributed, transformed and used as you please. If you enjoy the icons, a link back to this page would certainly be appreciated. And if you use the icons on your site, feel free to let me know so I can link to you!

Note: the company logos in the icons are copyright of their respective owners.