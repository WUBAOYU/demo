<?php
//Adding the Open Graph in the Language Attributes
function add_opengraph_doctype( $output ) {
		 return $output . ' xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml"';
	}
add_filter('language_attributes', 'add_opengraph_doctype');

//Lets add Open Graph Meta Info

function insert_fb_in_head() {

	 global $post; 
	 
	 $seo = ot_get_option('seo');
	 if($seo != 'no'){
	 
	 ?>
	 
	 <link rel="author" href="<?php echo ot_get_option( 'google_plus' ); ?>">
	 
	 
	 <meta name="description" content="<?php if(is_home()){ echo ot_get_option('web_description') ;}elseif(is_category()){
	 ob_start();
	 single_cat_title();
	 $single_cat_title = ob_get_contents();
	 ob_end_clean();
	 $thisCat = get_term_by('name', $single_cat_title, 'category'); echo $thisCat->description; } else{ 
	 $meta_description = get_post_custom_values('meta_description', $post->ID); 
	 echo $meta_description[0];} ?>">
	 <meta name="url" content="<?php if( is_home() ) { echo home_url(); } else { the_permalink(); } ?>">
	 
	 <?php } ?>
	 
	 
	 <meta property="og:title" content="<?php if(is_home()) { bloginfo('name'); } elseif(is_category()) { echo single_cat_title();} elseif(is_author()) { $curauth = (get_query_var('author_name')) ? get_user_by('slug', get_query_var('author_name')) : get_userdata(get_query_var('author')); echo $curauth->display_name; } else { echo the_title(); } ?>" />
	 <meta property="og:description" content="<?php if(is_home()){ echo ot_get_option('web_description') ;}elseif(is_category()){
	 ob_start();
	 single_cat_title();
	 $single_cat_title = ob_get_contents();
	 ob_end_clean();
	 $thisCat = get_term_by('name', $single_cat_title, 'category'); echo $thisCat->description; } else{ 
	 $meta_description = get_post_custom_values('meta_description', $post->ID); 
	 echo $meta_description[0];} ?>" />
	 
	 <meta property="og:url" content="<?php if( is_home() ) { echo home_url(); } else { the_permalink(); } ?>" />
	 
	 <?php if(is_single()){
	 	$id_link = get_post_thumbnail_id($post->ID);
	 
	 	$image_url = wp_get_attachment_image_src( $id_link, array(80,80));
	 	if(is_array($image_url)){
	 		$image_url_face = $image_url[0];
	 	}else{
	 		$image_url_face = ot_get_option( 'facebook_thumb' );
	 	}
	 	
	 	
	 }else{
	 	$image_url_face = ot_get_option( 'facebook_thumb' );
	 }
	  ?>
	 <meta property="og:image" content="<?php echo $image_url_face ?>" />
	 
	 <meta property="og:type" content="<?php if (is_single() || is_page()) { echo "article"; } else { echo "website";} ?>" />
	 <meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
	 
	 <meta property="fb:app_id" content="<?php echo ot_get_option('facebook_ID'); ?>" />
	 
	 
	 
	 <?php
	 
	 if(is_home()){
	 	$meta_values = get_post_custom( ot_get_option( 'homepage' ) );
	 }else{
	 	if (isset($post->ID)) {
	 		
	 	$meta_values = get_post_custom($post->ID);
	 	}
	 }
	 
	 if(isset($_POST['main_color'])){
	 	$primary_color = $_POST['main_color'];
	 
	 }else{
	 //Main Color
	 	if( isset($meta_values['meta_custom_color'])  ){
	 		$primary_color = $meta_values['meta_custom_color'][0] ;
	 		if($primary_color == ""){
	 			$primary_color = ot_get_option( 'primary_color' );
	 		}
	 	}else{
	 		$primary_color = ot_get_option( 'primary_color' );
	 	}
	 
	 	if( is_search() ){
	 		$primary_color = ot_get_option( 'primary_color' );
	 	}
	 }
	 
	 if(is_category()){
		 $categories_get = ot_get_option( 'categories', array() );
		 
		     if ($categories_get){
		         foreach ($categories_get as $category) { 
		         	
		         	if(is_category($category['category'])){
		         		$primary_color = $category['color'];
		         	}
		         }
		      }
	 }
	 if(is_tax( 'item_type' )){
	 	 $categories_get = ot_get_option( 'categories_item', array() );
	 	 
	 	     if ($categories_get){
	 	         foreach ($categories_get as $category) { 
	 	         	
	 	         	if(is_tax( 'item_type', $category['category'])){
	 	         		$primary_color = $category['color'];
	 	         	}
	 	         }
	 	      }
	 }
	 
	 
	 
	 $GLOBALS['primary_color'] = $primary_color;
	 
	 $primary_color_2 = '#' . hexDarker(substr($primary_color,1), 50);
	 
	 
	 
	 // Main Background styling
	 if( isset($meta_values['meta_background']) ){
	 	$main_bg = unserialize($meta_values['meta_background'][0]) ;
	 	
	 	if( isset( $meta_values['meta_color_theme'][0] ) ){
	 		
	 		$bg_class=  $meta_values['meta_color_theme'][0];
	 	
	 	}
	 	if($main_bg['background-image'] =="" && $main_bg['background-color'] =="" ){
	 		$main_bg = ot_get_option( 'main_background' );
	 		$bg_class= ot_get_option( 'color_theme' );
	 	}
	 }else{
	 	$main_bg = ot_get_option( 'main_background' );
	 	$bg_class= ot_get_option( 'color_theme' );
	 }
	 
	 if ( isset($main_bg['background-image']) ){
	 	$main_bg_url = "url('". $main_bg['background-image'] . "')";
	 }else{
	 	$main_bg_url = "";
	 }
	 
	 if ( !isset($main_bg['background-color']) ){
	 	$main_bg['background-color'] = "";
	 }
	 
	 if ( !isset($main_bg['background-attachment']) ){
	 	$main_bg['background-attachment'] = "";
	 }
	 
	 if ( !isset($main_bg['background-position']) ){
	 	$main_bg['background-position'] = "";
	 }
	 
	 if ( !isset($main_bg['background-repeat']) ){
	 	$main_bg['background-repeat'] = "";
	 }
	 
	 
	 $color_1= $primary_color;
	 $color_0 = '#' . hexLighter(substr($color_1,1), 50);
	 $color_2 = '#' . hexDarker(substr($color_1,1), 5);
	 $color_3 = '#' . hexDarker(substr($color_1,1), 10);
	 $color_4 = '#' . hexDarker(substr($color_1,1), 20);
	 
	 $color_rgb = hex2rgb($primary_color);
	 
	 ?>
	 
	 <style>
	 
	 body{
	 	background:<?php echo $main_bg['background-color'] . " " . $main_bg_url . " " . $main_bg['background-repeat'] . " " .  $main_bg['background-position'] . " " .  $main_bg['background-attachment'] ; ?> ;
	 }
	 
	 
	 
	  
	 			 
	    			      .bones_page_navi li.bpn-current,
	       .custom_ul li:hover span,
	       .shortcode_4col_posts li a.data-original:hover,
	        .element a.data-original:hover,
	        #filter li a:hover,
	           #filter li a.selected,
	             
	             .nav-buttons a.flex-active,.nav-buttons a:hover,
	             .liteAccordion .slide > h2.selected span,
	             .liteAccordion .slide > h2:hover span ,
	             ul.custom_tabs2 li.current,
	             
	             input#preview_input,
	             
	             
	             
	             p.dark:hover,
	             
	              #topnav  li:hover,
	               #topnav li.show-menu-li,
	               #topnav li li li:hover,
	               #topnav li.current-menu-item,
	               
	               
	               input.element-block:focus,
	               textarea.element-block:focus,
	                #social_icons li.search.active,
	                #social_icons li.search:hover,
	                #social_icons li.search #top_search,
	                 .tabs li.active ,
	                  .tabs li:hover,
	                  p.shuffle-article a:hover,
	                  #top-menu-nav ul.top-menu-nav > li:hover,
	                  #top-menu-nav ul.top-menu-nav > li.current_page_item,
	                  p.thumb-cat:hover,
	                  span.list-icon:hover,
	                  p.social-share-count:hover,
	                   p.thumb-cat-3:hover,
	                    p.social-share-count-3:hover,
	                    
	                    .flexslider ol.flex-control-nav li a.flex-active,
	                    .thumb-like:hover p.post-like,
	                    .thumb-like-single:hover,
	                    .post-content ins,
	                    .review_comment,
	                    .progress-striped .bar ,
	                    p.breaking-title,
	                    h3.title,
	                    #wp-calendar td#today,
	                    .gallery-item .wp-caption-text.gallery-caption,
	                    .pagination a,
	                    p.side_show,
	                    .lt-ie9 .hover_span,
	                    .lt-ie9 p.dark-mini,
	                    .lt-ie9 .hover_span_wrap a.hover_a,
	                    .flip-post .post-data-bg,
	                    .roll-link span:after{
	  	background-color:<?php echo $primary_color; ?>;
	  }
	  
	  ::selection {
	  	background: <?php echo $primary_color; ?>;
	  }
	  ::-moz-selection {
	  	background: <?php echo $primary_color; ?>;
	  }
	  
	  .hover_span,
	  p.dark-mini,
	  .hover_span_wrap a.hover_a{
	  	background-color:rgba(<?php echo $color_rgb[0]; ?> , <?php echo $color_rgb[1]; ?> , <?php echo $color_rgb[2]; ?> , 0.8);
	  }
	  .footer .flickr img:hover{
	  	border-color:<?php echo $primary_color; ?> ;
	  }
	  #header,
	  .top-wide-nav{
	  	border-top:4px solid <?php echo $primary_color; ?> ;
	  }
	  
	  
	  h3.title span.arrow{
	  	
	  	border-top: 7px solid <?php echo $primary_color; ?>;
	  }
	  
	  .title_wrap .border,
	  .password-protected-form{
	  	border-color:<?php echo $primary_color; ?>;
	  	
	  }
	  
	  .blog-thumb-3:hover{
	  	border-left:5px solid <?php echo $primary_color; ?>;
	  }
	  
	  .call_an_action{
	  	border-left:10px solid <?php echo $primary_color; ?>;
	  }
	  
	  .arrow_down{
	  	border-top: 10px solid <?php echo $primary_color; ?>;
	  }
	  a,
	  .comment-author .time_class a,
	  .next_article a:hover,
	  ul.tweets li a,
	  ul.tweets li a:hover,
	  
	  ul.latest_news.comments a:hover,
	  .date-list p:hover,
	   .date-list a:hover,
	   p.cat-content:hover,
	   p.cat-content a:hover,
	   ul.meta-entry li p:hover,
	   ul.meta-entry li a:hover,
	   h2.blogtitle a:hover,
	   .rating_stars span,
	   .widget li a:hover{
	  	color:<?php echo $primary_color; ?>;
	  }
	  
	  #ribbon{
	  	border-left: 20px solid <?php echo $primary_color; ?>;
	  	border-right: 20px solid <?php echo $primary_color; ?>;
	  	border-top: 20px solid <?php echo $primary_color; ?>;
	  }
	  
	  
	  #submit,
	  .button-primary,
	  input.button-primary,
	  .tags a,
	  #mc_signup_submit,
	   .password-protected-form input[type=submit],
	   .compare .ctitle{
	  	background-color: <?php echo $color_1; ?>;
	  	  background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, <?php echo $color_1; ?>), color-stop(100%, <?php echo $color_3; ?>));
	  	  background-image: -webkit-linear-gradient(top, <?php echo $color_1; ?>, <?php echo $color_3; ?>);
	  	  background-image: -moz-linear-gradient(top, <?php echo $color_1; ?>, <?php echo $color_3; ?>);
	  	  background-image: -ms-linear-gradient(top, <?php echo $color_1; ?>, <?php echo $color_3; ?>);
	  	  background-image: -o-linear-gradient(top, <?php echo $color_1; ?>, <?php echo $color_3; ?>);
	  	  background-image: linear-gradient(top, <?php echo $color_1; ?>, <?php echo $color_3; ?>);
	  	  border: 1px solid <?php echo $color_4; ?>;
	  	  box-shadow: inset 0 1px 0 0 '.$color_0.';
	  }
	  
	  
	 
	 
	 /* #logo, */
	 #submit:hover,
	 .button-primary:hover,
	 input.button-primary:hover,
	 .tags a:hover,
	 #mc_signup_submit:hover,
	 
	 .password-protected-form input[type=submit]:hover,
	 .compare .ctitle:hover {
	 	background-color: <?php echo $color_2; ?>;
	 	background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, <?php echo $color_2; ?>), color-stop(100%, <?php echo $color_4; ?>));
	 	background-image: -webkit-linear-gradient(top, <?php echo $color_2; ?>, <?php echo $color_4; ?>);
	 	background-image: -moz-linear-gradient(top, <?php echo $color_2; ?>, <?php echo $color_4; ?>);
	 	background-image: -ms-linear-gradient(top, <?php echo $color_2; ?>, <?php echo $color_4; ?>);
	 	background-image: -o-linear-gradient(top, <?php echo $color_2; ?>, <?php echo $color_4; ?>);
	 	background-image: linear-gradient(top, <?php echo $color_2; ?>, <?php echo $color_4; ?>);
	 }
	 
	  
	  
	  a:hover{
	  	color:<?php echo $primary_color_2; ?>;
	  }
	 
	 
	 
	  #logo{
	  	margin-top:<?php echo ot_get_option( 'logo_margin' );  ?>;
	  }
	 h3.title{
	 	background-color:<?php echo ot_get_option( 'title_color' ); ?>;
	 }
	 h3.title span.arrow{
	 	
	 	border-top: 7px solid <?php echo ot_get_option( 'title_color' ); ?>;
	 }
	 .widget h3.title{
	 	background-color:<?php echo ot_get_option( 'widget_title_color' ); ?>;
	 }
	 .widget h3.title span.arrow{
	 	
	 	border-top: 7px solid <?php echo ot_get_option( 'widget_title_color' ); ?>;
	 }
	 
	 p.breaking-title{
	 	background-color:<?php echo ot_get_option( 'breaking_color' ); ?>;
	 }
	 
	 #header,
	 #header .container{
	 	background-color:<?php echo ot_get_option( 'top_bg_color' ); ?>;
	 }
	 
	 #topnav{
	 	background-color:<?php echo ot_get_option( 'side_bg_color' ); ?>;
	 }
	 
	 .footerbg{
	 	background-color:<?php echo ot_get_option( 'footer_bg_color' ); ?>;
	 }
	 #top-menu-nav ul > li a{
	 	font-size:<?php echo ot_get_option( 'top_menu_fsize' ); ?>;
	 }
	 #topnav li a,
	 #topnav ul.top-nav > li::before,
	 .top-wide-nav #topnav li a{
	 	font-size:<?php echo ot_get_option( 'side_menu_fsize' ); ?>;
	 }
	 p.breaking-title{
	 	font-size:<?php echo ot_get_option( 'breaking_title_fsize' ); ?>;
	 }
	 ul.newsticker{
	 	font-size:<?php echo ot_get_option( 'breaking_text_fsize' ); ?>;
	 }
	 h2.blogtitle{
	 	font-size:<?php echo ot_get_option( 'article_title_fsize' ); ?>;
	 }
	 h3.title span,
	 h3.title{
	 	font-size:<?php echo ot_get_option( 'title_fsize' ); ?>;
	 }
	 .widget h3.title span,
	 .widget h3.title{
	 	font-size:<?php echo ot_get_option( 'widget_title_fsize' ); ?>;
	 }
	 #logo a{
	 	font-size:<?php echo ot_get_option( 'logo_fsize' ); ?>;
	 }
	 .width_50_right a.author{
	 	font-size:<?php echo ot_get_option( 'slider_title_fsize' ); ?>;
	 }
	 
	 <?php $show_top_bar = ot_get_option( 'show_top_bar');
	 if($show_top_bar == 'no'){ ?>
	 #header {
	 height: 0px;
	 margin-top: -30px;
	 }
	 #header .container, #header .row {
	 height: 0px;
	 display: none;
	 }
	 #container{
	 	padding: 0px 30px 30px;
	 	margin-top:30px;
	 }
	 <?php } ?>
	 
	 
	 <?php $website_width = ot_get_option( 'website_width');
	 
	 $responsive = ot_get_option( 'responsive');
	 
	 if($website_width == 'narrow'){
	 	if($responsive !='no'){
	 ?>
		 @media (min-width: 1200px){
		 	.container, .navbar-static-top .container, .navbar-fixed-top .container, .navbar-fixed-	bottom .container {
	 		width: 970px;
	 		}
	 	}
	 <?php }else{ ?>
	 
	 	.container, .navbar-static-top .container, .navbar-fixed-top .container, .navbar-fixed-bottom .container {
	 	width: 970px;
	 	}
	 
	 <?php } } ?>
	 <?php 
	 
	 if($responsive == 'no'){?>
	 
	 .container, .navbar-static-top .container, .navbar-fixed-top .container, .navbar-fixed-bottom .container {
	 width: 1170px;
	 }
	 
	 <?php } ?>
	 
	 
	 <?php 
	 $top_bar_fixed = ot_get_option( 'top_bar_fixed');
	 
	 if($top_bar_fixed == 'no'){ ?>
	 	#header{padding:0;height:32px;display:block;}
	 	#container {padding: 0px 30px 30px;}
	 	.top-main-content {
	 	padding: 20px 0 30px;
	 	}
	 
	 <?php }else{ ?>
	 #header{padding:0;height:32px;position:fixed;display:block;z-index:200;width:100%;}
	 .top-main-content {
	 padding: 30px 0 30px;
	 }
	 
	 <?php } ?>
	 
	 <?php 
	 $categories_get = ot_get_option( 'categories', array() );
	 
	     if ($categories_get){
	         foreach ($categories_get as $category) { 
	         	$cat_array = get_category($category['category']);
	         	
	         	update_option('category_icon_' . $category['category'] , $category['icon']);
	         	update_option('category_layout_' . $category['category'] , $category['layout']);
	         	
	         	$color_cat_rgb = hex2rgb($category['color']);
	         ?>
	 			.<?php echo $cat_array->slug ?> h3.title,
	 			.<?php echo $cat_array->slug ?> p.dark-mini:hover,
	 			.lt-ie9 .<?php echo $cat_array->slug ?> .hover_span,
	 			.lt-ie9 .<?php echo $cat_array->slug ?> p.dark-mini,
	 			.lt-ie9 .<?php echo $cat_array->slug ?> .hover_span_wrap a.hover_a,
	 			.flip-post.<?php echo $cat_array->slug ?> .post-data-bg{
	 					background-color: <?php echo $category['color'] ?>;       
	 			}
	 
	            .<?php echo $cat_array->slug ?> h3.title span.arrow{
	    			border-top-color: <?php echo $category['color'] ?>;       
	           }
	           
	           .<?php echo $cat_array->slug ?> h2.blogtitle a:hover,
	           .<?php echo $cat_array->slug ?> ul.meta-entry li p:hover,
	           .<?php echo $cat_array->slug ?>  a:hover,
	           .<?php echo $cat_array->slug ?>  .rating_stars span{
	           		color: <?php echo $category['color'] ?>;       
	           }
	           
	           
	            .<?php echo $cat_array->slug ?> .hover_span,
	            .<?php echo $cat_array->slug ?> p.dark-mini,
	            .<?php echo $cat_array->slug ?> .hover_span_wrap a.hover_a{
	           	background-color:rgba(<?php echo $color_cat_rgb[0]; ?> , <?php echo $color_cat_rgb[1]; ?> , <?php echo $color_cat_rgb[2]; ?> , 0.8);
	           }
	           
	           .<?php echo $cat_array->slug ?> p.dark-mini a:hover{
	           	color: white;
	           }
	           
	        	<?php $bg_img = $category['background']['background-image'];
	        	if(isset($bg_img)){
	        		$bg_url= "url('".$bg_img."')"; 
	        	}else {
					$bg_url='';	
				}
	        	$bg_color = $category['background']['background-color'];
	        	$bg_repeat = $category['background']['background-repeat'];
	        	$bg_position = $category['background']['background-position'];
	        	$bg_attachment = $category['background']['background-attachment']; ?>
	           
	           <?php if($bg_color != '' || $bg_img != ''){
	            ?>
	            body.category-<?php echo $cat_array->slug ?>{
	            	background:<?php echo $bg_color . " ".$bg_url." " . $bg_repeat . " " .  $bg_position . " " .  $bg_attachment ; ?> ;
	            }
	           
	         <?php } }
	     }
	 
	  ?>
	  <?php 
	  $categories_item = ot_get_option( 'categories_item', array() );
	  
	      if ($categories_item){
	          foreach ($categories_item as $category) { 
	          	$cat_array = get_term($category['category'],'item_type');
	          	
	          	update_option('category_icon_item_' . $category['category'] , $category['icon']);
	          	update_option('category_layout_item_' . $category['category'] , $category['layout']);
	          	
	          	$color_cat_rgb = hex2rgb($category['color']);
	          ?>
	  			.item-cat-<?php echo $cat_array->slug ?> h3.title,
	  			.item-cat-<?php echo $cat_array->slug ?> p.dark-mini:hover,
	  			.lt-ie9 .item-cat-<?php echo $cat_array->slug ?> .hover_span,
	  			.lt-ie9 .item-cat-<?php echo $cat_array->slug ?> p.dark-mini,
	  			.lt-ie9 .item-cat-<?php echo $cat_array->slug ?> .hover_span_wrap a.hover_a,
	  			.flip-post.item-cat-<?php echo $cat_array->slug ?> .post-data-bg{
	  					background-color: <?php echo $category['color'] ?>;       
	  			}
	  
	             .item-cat-<?php echo $cat_array->slug ?> h3.title span.arrow{
	     			border-top-color: <?php echo $category['color'] ?>;       
	            }
	            
	            .item-cat-<?php echo $cat_array->slug ?> h2.blogtitle a:hover,
	            .item-cat-<?php echo $cat_array->slug ?> ul.meta-entry li p:hover,
	            .item-cat-<?php echo $cat_array->slug ?>  a:hover,
	            .item-cat-<?php echo $cat_array->slug ?>  .rating_stars span{
	            		color: <?php echo $category['color'] ?>;       
	            }
	            
	            
	             .item-cat-<?php echo $cat_array->slug ?> .hover_span,
	             .item-cat-<?php echo $cat_array->slug ?> p.dark-mini,
	             .item-cat-<?php echo $cat_array->slug ?> .hover_span_wrap a.hover_a{
	            	background-color:rgba(<?php echo $color_cat_rgb[0]; ?> , <?php echo $color_cat_rgb[1]; ?> , <?php echo $color_cat_rgb[2]; ?> , 0.8);
	            }
	            
	            .item-cat-<?php echo $cat_array->slug ?> p.dark-mini a:hover{
	            	color: white;
	            }
	            
	         	<?php $bg_img = $category['background']['background-image'];
	         	if(isset($bg_img)){
	         		$bg_url= "url('".$bg_img."')"; 
	         	}else {
	  				$bg_url='';	
	  			}
	         	$bg_color = $category['background']['background-color'];
	         	$bg_repeat = $category['background']['background-repeat'];
	         	$bg_position = $category['background']['background-position'];
	         	$bg_attachment = $category['background']['background-attachment']; ?>
	            
	            <?php if($bg_color != '' || $bg_img != ''){
	             ?>
	             body.term-<?php echo $cat_array->slug ?>{
	             	background:<?php echo $bg_color . " ".$bg_url." " . $bg_repeat . " " .  $bg_position . " " .  $bg_attachment ; ?> ;
	             }
	            
	          <?php } }
	      }
	  
	   ?>
	   
	 
	 
	 #topnav li,h1,h2,h3,
	 p.dark,
	 p.breaking-title,
	 .slides-breaking li a,
	 
	 .comment-author .fn a,
	 .comment-reply-link,
	 .social_box_count p,
	 
	 #top_search select#cat,
	 .footer,
	 .next_article a,
	 ul.popular a.entrytitle,
	 h3.title,
	   	#wp-calendar,
	   	.twitter-author,
	   	ul.custom_tabs li a,
	   	p.social-share-count,
	   	 p.cat-content,
	   	  p.thumb-cat,
	   	   p.social-share-count-3,
	   	   .width_50_right a.author,
	   	   ul.newsticker,
	   	   a.post_title_thumb,
	   	   .shortcode_4col_posts li a.data-original,
	   	    .element a.data-original,
	   	    .thumb-like p.post-like a,
	   	    .thumb-like-single,
	   	    .bones_page_navi li,
	   	    .rating_table td p,
	   	    ul.custom_tabs2 li a,
	   	    ul.footer-nav li,
	   	    .widget .latest_news h6 a,
	   	    .top-wide-nav .today p,
	   	    .featured-post p.dark-mini,
	   	    #logo,
	   	    .flip-post a,
	   	    .latest_posts_list li a,
	   	    .compare td,
	   	    p.item-title{
	 	
	 font-family: <?php echo ot_get_option( 'heading_font' );?>,'Droid Arabic Kufi', Helvetica, Georgia, serif;
	 font-weight:normal;
	 }
	 
	 body,
	 .comments_list li a,
	 #top-menu-nav ul li ul li a,
	 #topnav ul li ul li a,
	 .latest_news h6 a,
	 #top-menu-nav ul > li a,
	 p.thumb-cat-3,
	 a.button,
	 .tabs li a{
	 	font-family: <?php echo ot_get_option( 'body_font' );?>,'Droid Arabic Kufi', Helvetica, Georgia, serif;
	 }
	 
	 <?php echo ot_get_option( 'custom_css' );  ?>
	 
	 </style>
	 	
	 <!-- drop Google Analytics Here -->
	 
	 <?php echo ot_get_option( 'google_analytics' );  ?>
	 <!-- end analytics -->
	 
	 
	 <?php
	 
}
add_action( 'wp_head', 'insert_fb_in_head', 229 );


?>