<?php

define('C5_skins_ROOT', C5_ROOT . 'library/includes/skins/');
define('C5_skins_URL', C5_URL . 'library/includes/skins/');

require_once(C5_skins_ROOT . 'classes/C5_skin_base.php' );
require_once(C5_skins_ROOT . 'classes/C5_header.php' );
require_once(C5_skins_ROOT . 'classes/C5_skin.php' );
require_once(C5_skins_ROOT . 'classes/C5_footer.php' );
require_once(C5_skins_ROOT . 'classes/C5_fonts.php' );
require_once(C5_skins_ROOT . 'classes/C5_admin_bar.php' );


$skin_obj = new C5_header();
$skin_obj = new C5_skin();
$skin_obj = new C5_footer();
$skin_obj->single_hook();
$c5_admin_bar = new C5_admin_bar();


?>