<?php 

class C5_skin extends C5_skin_base {
	
	function __construct() {
		$this->slug = 'skin';
		$this->name = 'Skin';
		$this->image = 'skin';
		
		$this->supports = array( 'title' );
		
		$this->hook();
	}
	
	
	function meta_box() {
		
		global $wp_registered_sidebars;
		
		$sidebars = array();
	    foreach ($wp_registered_sidebars as $sidebar_new) {
	        $sidebars[] = array(
	            'label' => $sidebar_new['name'],
	            'value' => $sidebar_new['id']
	        );
	    }
	
		$fonts_obj = new C5_font();
		$google_fonts = $fonts_obj->get_select_array();
	
	
	
	    $layout_array = array(
	    	'728-C',
	    	'960-B-C',
	    	'960-C-B',
	    	'960-C-S',
	    	'960-C',
	    	'960-S-C',
	    	//'1170-B-B-C',
	    	//'1170-C-B-B',
	    	//'1170-B-C-B',
	    	'1170-B-C-S',
	    	'1170-B-C',
	    	'1170-B-S-C',
	    	'1170-C-B-S',
	    	'1170-C-B',
	    	'1170-C-S-B',
	    	//'1170-C-S-S',
	    	'1170-C-S',
	    	'1170-C',
	    	'1170-S-B-C',
	    	'1170-S-C-B',
	    	//'1170-S-C-S',
	    	'1170-S-C',
	    	//'1170-S-S-C'
	    );
		$layout_options = array(
		);
		
		foreach ($layout_array as $value) {
			$layout_options[] = array(
			    'src' => C5_skins_URL. 'images/layout/'.$value.'.png',
			    'label' => '',
			    'value' => $value
			);
		}
		
		$rtl_array = array(
		'ltr',
		'rtl'
		);
		$rtl_options = array(
		);
		
		foreach ($rtl_array as $value) {
			$rtl_options[] = array(
			    'src' => C5_skins_URL. 'images/rtl/'.$value.'.png',
			    'label' => '',
			    'value' => $value
			);
		}
	
	
	    $meta_skins_layout = array(
	        'id' => 'meta_skins',
	        'title' => 'Page Layout Options',
	        'desc' => '',
	        'pages' => array('skin'),
	        'context' => 'normal',
	        'priority' => 'low',
	        'fields' => array(
	            array(
	                'label' => 'Choose The default Header',
	                'id' => 'header_default',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The  Header.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'header',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            array(
	                'label' => 'Choose The default Footer',
	                'id' => 'footer_default',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The Footer.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'footer',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            /*
	            array(
	                'label' => 'Boxed/Full Layout',
	                'id' => 'page_layout',
	                'type' => 'radio-image',
	                'desc' => 'Choose Website Layout Boxed/Full Width, Default: Full.',
	                'choices' => c5_get_boxed_full_images(),
	                'std' => 'boxed-layout',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            */
	            array(
	                'label' => 'RTL',
	                'id' => 'rtl',
	                'type' => 'radio-image',
	                'desc' => 'Choose Website direction.',
	                'choices' => $rtl_options,
	                'std' => 'ltr',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	            ),
	            array(
	              'label'       => 'Page Width & Layout',
	              'id'          => 'layout_width',
	              'type'        => 'radio-image',
	              'desc'        => '',
	              'choices' => $layout_options,
	              'std'         => '1170-S-C-B',
	              'rows'        => '',
	              'post_type'   => '',
	              'taxonomy'    => '',
	              'class'       => 'c5-skin-selector'
	            ),
	            array(
	                'label' => 'Big Sidebar',
	                'id' => 'big_sidebar',
	                'type' => 'select',
	                'desc' => 'Select the Big Page sidebar.',
	                'choices' => $sidebars,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            
	           array(
	                'label' => 'Small Sidebar',
	                'id' => 'small_sidebar',
	                'type' => 'select',
	                'desc' => 'Select the Page small sidebar.',
	                'choices' => $sidebars,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            
	        )
	        ,
	        'std' => '',
	        'rows' => '',
	        'post_type' => '',
	        'taxonomy' => '',
	        'class' => ''
	    );
	
	
	    $meta_skins_style = array(
	        'id' => 'meta_skins_style',
	        'title' => 'Page Style Options',
	        'desc' => '',
	        'pages' => array('skin'),
	        'context' => 'normal',
	        'priority' => 'low',
	        'fields' => array(
	            array(
	                'label' => 'Primary Color',
	                'id' => 'primary_color',
	                'type' => 'colorpicker',
	                'desc' => 'Pick a the main color for the theme (default: #d64a2b ).',
	                'std' => '#d64a2b',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            array(
	                'label' => 'Title Color',
	                'id' => 'title_color',
	                'type' => 'colorpicker',
	                'desc' => 'Pick the title color for the theme (default: #d64a2b ).',
	                'std' => '#d64a2b',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            
	            
	            array(
	                'label' => 'Side Menu Background Color',
	                'id' => 'side_menu_background',
	                'type' => 'colorpicker',
	                'desc' => 'Pick the Side Menu Background Color for the theme (default: #eee ).',
	                'std' => '#eee',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            array(
	                'label' => 'Main Background',
	                'id' => 'main_background',
	                'type' => 'background',
	                'desc' => 'Upload the background pattern you want.',
	                'std' => array(
	                	'background-color'=>'#ffffff',
	                	'background-image'=>C5_URL . 'library/images/bright_squares.png',
	                ),
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            array(
	                'label' => 'Custom CSS for this skin',
	                'id' => 'custom_css',
	                'type' => 'textarea',
	                'desc' => 'Add Custom CSS for this skin.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	            ),
	            array(
	                'label' => 'Custom js for this skin',
	                'id' => 'custom_js',
	                'type' => 'textarea',
	                'desc' => 'Add Custom js for this skin.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	            )
	        )
	        ,
	        'std' => '',
	        'rows' => '',
	        'post_type' => '',
	        'taxonomy' => '',
	        'class' => ''
	    );
	
	    $meta_skins_typography = array(
	        'id' => 'meta_skins_typography',
	        'title' => 'Page Typography Options',
	        'desc' => '',
	        'pages' => array('skin'),
	        'context' => 'normal',
	        'priority' => 'low',
	        'fields' => array(
	            //Fonts
	            array(
	                'label' => 'Primary Heading Font',
	                'id' => 'heading_font',
	                'type' => 'select',
	                'desc' => 'Select your Header font from the available fonts, Fonts are provided via Google Fonts API',
	                'choices' => $google_fonts,
	                'std' => 'Oswald#latin#googlefont',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	            ),
	            array(
	                'label' => 'Body Font',
	                'id' => 'body_font',
	                'type' => 'select',
	                'desc' => 'Select your body "Default" font from the available fonts, Fonts are provided via Google Fonts API',
	                'choices' => $google_fonts,
	                'std' => 'Arial#system#default',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	            ),
	            $this->get_font_size_array('Body' , 'body_fs' , '13'),
	           
	            
	            
	            $this->get_font_size_array('Top Menu' , 'top_menu_fs' , '12'),
	            $this->get_font_size_array('Side Menu' , 'side_menu_fs' , '16'),
	            
	            
	            $this->get_font_size_array('Title' , 'title_fs' , '16'),
	            $this->get_font_size_array('Blog Article Title' , 'article_title_fs' , '20'),
	            $this->get_font_size_array('Slider Title Title' , 'slider_title_fs' , '25'),
	            
	        )
	        ,
	        'std' => '',
	        'rows' => '',
	        'post_type' => '',
	        'taxonomy' => '',
	        'class' => ''
	    );
	    
	    
	    $skin_defaults = array();
	    
	    foreach ($meta_skins_layout['fields'] as $option) {
	    	$skin_defaults[$option['id']] = array($option['type'], $option['std']);
	    }
	    
	    foreach ($meta_skins_style['fields'] as $option) {
	    	$skin_defaults[$option['id']] = array($option['type'], $option['std']);
	    }
	    
	    foreach ($meta_skins_typography['fields'] as $option) {
	    	$skin_defaults[$option['id']] = array($option['type'], $option['std']);
	    }
	    
	    update_option('c5_skin_defaults', $skin_defaults);
	
	    ot_register_meta_box($meta_skins_layout);
	    ot_register_meta_box($meta_skins_style);
	    ot_register_meta_box($meta_skins_typography);
	}
	
	
}

 ?>