<?php 

class C5_admin_bar {

	function __construct() {
		add_action( 'admin_bar_menu', array($this, 'admin_bar'), 1000 );
	}
	
	function admin_bar() {
	    global $wp_admin_bar, $wpdb;
	    if ( !is_super_admin() || !is_admin_bar_showing()  )
	        return;
	        
	        
	     global $post;
	     global $c5_skinid;
	     global $c5_skindata;
	     $c5_skin_id = $c5_skinid;
	     
	     $c5_header_id  = '';
	     if(isset($c5_skindata['header_default'])){
	     	$c5_header_id  = $c5_skindata['header_default'];
	     }
	     
	     $c5_footer_id = '';
	     if(isset($c5_skindata['footer_default'])){
	     	$c5_footer_id  = $c5_skindata['footer_default'];
	     }
	     
	     	$wp_admin_bar->add_menu( array( 'id' => 'c5_parent', 'title' => 'AlYoum Theme Menu', 'href' => home_url() . '/wp-admin/themes.php?page=ot-theme-options' ) );
	     	
	     	if( is_admin() ){
	     		$wp_admin_bar->add_menu( array( 'parent'=>'top-secondary', 'id' => 'c5_install_demo', 'class' =>  'c5-install-demo', 'title' => 'Install Demo Content' ) );
	     	}
	     	if($c5_skin_id !=''){
	     		$wp_admin_bar->add_node( array( 'parent' => 'c5_parent','id' => 'skin_edit', 'title' => __( 'Edit Skin', 'code125-admin' ), 'href' => home_url() . '/wp-admin/post.php?post=' . $c5_skin_id .'&action=edit' ) );
	     	}
	     	if($c5_header_id !=''){
	     		$wp_admin_bar->add_node( array( 'parent' => 'c5_parent','id' => 'header_edit', 'title' => __( 'Edit Header', 'code125-admin' ), 'href' => home_url() . '/wp-admin/post.php?post=' . $c5_header_id.'&action=edit' ) );
	     	}
	     	
	     	if($c5_footer_id !=''){
	     		$wp_admin_bar->add_node( array( 'parent' => 'c5_parent','id' => 'footer_edit', 'title' => __( 'Edit Footer', 'code125-admin' ), 'href' => home_url() . '/wp-admin/post.php?post=' . $c5_footer_id.'&action=edit' ) );
	     	}
	     
	     if(is_page() ||  is_home()){
	     
	    	$id = $post->ID;
	     	$template = get_post_meta($id,'meta_template_id',true);
	     	if($template!=''){
	     		$wp_admin_bar->add_node( array('parent' => 'c5_parent', 'id' => 'template_edit', 'title' => __( 'Edit Page Template', 'code125-admin' ), 'href' => home_url() . '/wp-admin/themes.php?page=aq-page-builder&action=edit&template=' . $template  ) );
	     	}
	     
	     }
	        
	    /* Add the main siteadmin menu item */
	    $wp_admin_bar->add_node( array( 'parent' => 'c5_parent','id' => 'alyoum_options', 'title' =>  'AlYoum Theme Options' , 'href' => home_url() . '/wp-admin/themes.php?page=ot-theme-options' ) );
	   
	    
	    
	    
	    
	}
	
	
}

 ?>