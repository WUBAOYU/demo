<?php 

class C5_header extends C5_skin_base {
	
	function __construct() {
		$this->slug = 'header';
		$this->name = 'Header';
		$this->image = 'header';
		
		$this->supports = array( 'title' );
		
		$this->hook();
	}
	
	
	
	function meta_box() {
	    
	    
	    
	    $meta_header_logo = array(
	        'id' => 'meta_header_logo',
	        'title' => 'Logo Options',
	        'desc' => '',
	        'pages' => array('header'),
	        'context' => 'normal',
	        'priority' => 'low',
	        'fields' => array(
	            array(
	                'label' => 'Main Logo',
	                'id' => 'logo',
	                'type' => 'upload',
	                'desc' => 'Upload the main logo for your website.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            ),
	            array(
	              'label'       => 'Logo Height',
	              'id'          => 'logo_height',
	              'type'        => 'numeric-slider',
	              'desc'        => 'Slide to select your Logo Height in <strong>pixels</strong>. "We will calculate the width automaticly based on the height"',
	              'std'         => '90', 
	              'min_max_step' => '10,300,1',
	              'rows'        => '',
	              'post_type'   => '',
	              'taxonomy'    => '',
	              'class'       => '',
	              'section'     => 'general_default'
	            ),
	            array(
	                'label' => 'Main Logo Top Margin',
	                'id' => 'logo_margin',
	                'type' => 'numeric-slider',
	                'desc' => 'Top Margin for the logo for your website, Default:7px.',
	                'std' => '0',
	                'min_max_step' => '0,300,1',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => ''
	            )
	            
	        )
	        ,
	        'std' => '',
	        'rows' => '',
	        'post_type' => '',
	        'taxonomy' => '',
	        'class' => ''
	    );
	    
	    
	    $meta_header_background = array(
	        'id' => 'meta_header_background',
	        'title' => 'General Settings',
	        'desc' => '',
	        'pages' => array('header'),
	        'context' => 'normal',
	        'priority' => 'low',
	        'fields' => array(
	        	array(
	        	    'label' => 'Choose Header Layout',
	        	    'id' => 'header_layout',
	        	    'type' => 'radio-image',
	        	    'desc' => 'Choose Header Layout.',
	        	    'choices' => $this->get_logo_position_images(),
	        	    'std' => 'logo-left',
	        	    'rows' => '',
	        	    'post_type' => '',
	        	    'taxonomy' => '',
	        	    'class' => ''
	        	),
	        	$this->get_content( 'content_logo' , 'Content beside Logo' , '[c5ab_ads size="ads_728x90" mobile="off" tablet="off" desktop="on" ]<a href="http://themeforest.net/item/alyoum-retina-magazine-blog-wordpress-theme/3925878?ref=code125" /><img src="http://d.pr/i/mUjU+" /></a>[/c5ab_ads][c5ab_ads size="ads_468x60" mobile="off" tablet="on" desktop="off" ]<a href="http://themeforest.net/item/alyoum-retina-magazine-blog-wordpress-theme/3925878?ref=code125" /><img src="http://d.pr/i/6qWw+" /></a>[/c5ab_ads][c5ab_ads size="ads_300x50" mobile="on" tablet="off" desktop="off" ]<a href="http://themeforest.net/item/alyoum-retina-magazine-blog-wordpress-theme/3925878?ref=code125" /><img src="http://d.pr/i/cVyP+" /></a>[/c5ab_ads]'),
	        	array(
	        	    'label' => 'Choose Main Menu Position',
	        	    'id' => 'header_menu_position',
	        	    'type' => 'radio-image',
	        	    'desc' => 'Choose Main Menu Position.',
	        	    'choices' => $this->get_menu_position_images(),
	        	    'std' => 'side',
	        	    'rows' => '',
	        	    'post_type' => '',
	        	    'taxonomy' => '',
	        	    'class' => ''
	        	),
	        	array(
	        	    'label' => 'Choose Main Menu',
	        	    'id' => 'header_menu',
	        	    'type' => 'select',
	        	    'desc' => 'Choose The Main Menu.',
	        	    'choices' => $this->get_current_menus(),
	        	    'std' => 'main-nav',
	        	    'rows' => '',
	        	    'post_type' => '',
	        	    'taxonomy' => '',
	        	    'class' => ''
	        	),
	        	array(
	        	    'label' => 'Show Today',
	        	    'id' => 'header_menu_today',
	        	    'type' => 'on_off',
	        	    'desc' => 'Show Today Date in case you choosed the top menu position.',
	        	    'std' => 'on',
	        	    'rows' => '',
	        	    'post_type' => '',
	        	    'taxonomy' => '',
	        	    'class' => ''
	        	),
	        	
	        	
	        	
	        	
	        	
	        	
	        )
	        ,
	        'std' => '',
	        'rows' => '',
	        'post_type' => '',
	        'taxonomy' => '',
	        'class' => ''
	    );
	    
	    
	    
	    
	    
	    $top_bar_content = array(
	    	        'id' => 'meta_top_bar',
	    	        'title' => 'Header Top Bar',
	    	        'desc' => '',
	    	        'pages' => array('header'),
	    	        'context' => 'normal',
	    	        'priority' => 'low',
	    	        'fields' => array(
	    	        	array(
	    	        	    'label' => 'Show Top Bar',
	    	        	    'id' => 'top_enable',
	    	        	    'type' => 'on_off',
	    	        	    'desc' => 'Choose to Show Top Bar or not.',
	    	        	    'std' => 'on',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	array(
	    	        	    'label' => 'Show Menu On Left',
	    	        	    'id' => 'top_menu_enable',
	    	        	    'type' => 'on_off',
	    	        	    'desc' => 'Show Menu On Left or not.',
	    	        	    'std' => 'on',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	array(
	    	        	    'label' => 'Choose Top Menu',
	    	        	    'id' => 'header_top_menu',
	    	        	    'type' => 'select',
	    	        	    'desc' => 'Choose The Top Menu.',
	    	        	    'choices' => $this->get_current_menus(),
	    	        	    'std' => 'top-nav',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	array(
	    	        	    'label' => 'Show Social Icons On Right',
	    	        	    'id' => 'top_social_enable',
	    	        	    'type' => 'on_off',
	    	        	    'desc' => 'Show Social Icons On Left or not.',
	    	        	    'std' => 'on',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	$this->get_content( 'top_custom_content' , 'Custom Content' , ''),
	    	        	
	    	        	array(
	    	        	    'label' => 'Top Bar Header Background Color',
	    	        	    'id' => 'top_background',
	    	        	    'type' => 'colorpicker',
	    	        	    'desc' => 'Top Bar Header Background Color (default: #57595a ).',
	    	        	    'std' => '#57595a',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	array(
	    	        	    'label' => 'Floating Bar Top Border Color',
	    	        	    'id' => 'top_bar_top_border',
	    	        	    'type' => 'colorpicker',
	    	        	    'desc' => 'Floating Bar Top Border Color (default: #d64a2b ).<br/><br/> leave it blank to disable the top border.',
	    	        	    'std' => '#d64a2b',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        )
	    	        ,
	    	        'std' => '',
	    	        'rows' => '',
	    	        'post_type' => '',
	    	        'taxonomy' => '',
	    	        'class' => ''
	    	    );
	  	
	  	
	  	$floating_bar_content = array(
	  		        'id' => 'meta_floatin_bar',
	  		        'title' => 'Floating Top Bar',
	  		        'desc' => '',
	  		        'pages' => array('header'),
	  		        'context' => 'normal',
	  		        'priority' => 'low',
	  		        'fields' => array(
	  		        	array(
	  		        	    'label' => 'Show Floating Bar',
	  		        	    'id' => 'floating_enable',
	  		        	    'type' => 'on_off',
	  		        	    'desc' => 'Choose to Show Top Bar or not.',
	  		        	    'std' => 'on',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	array(
	  		        	    'label' => 'Main Logo',
	  		        	    'id' => 'floating_logo',
	  		        	    'type' => 'upload',
	  		        	    'desc' => 'Upload the main logo for your website.',
	  		        	    'std' => '',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	array(
	  		        	  'label'       => 'Logo Height',
	  		        	  'id'          => 'floating_logo_height',
	  		        	  'type'        => 'numeric-slider',
	  		        	  'desc'        => 'Slide to select your Logo Height in <strong>pixels</strong>. "We will calculate the width automaticly based on the height"',
	  		        	  'std'         => '27', 
	  		        	  'min_max_step' => '10,300,1',
	  		        	  'rows'        => '',
	  		        	  'post_type'   => '',
	  		        	  'taxonomy'    => '',
	  		        	  'class'       => '',
	  		        	  'section'     => 'general_default'
	  		        	),
	  		        	array(
	  		        	    'label' => 'Main Logo Top Margin',
	  		        	    'id' => 'floating_logo_margin',
	  		        	    'type' => 'numeric-slider',
	  		        	    'desc' => 'Top Margin for the logo for your website, Default:7px.',
	  		        	    'std' => '7',
	  		        	    'min_max_step' => '0,300,1',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	array(
	  		        	    'label' => 'Show Menu On Left',
	  		        	    'id' => 'floating_menu_enable',
	  		        	    'type' => 'on_off',
	  		        	    'desc' => 'Show Menu On Left or not.',
	  		        	    'std' => 'on',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	array(
	  		        	    'label' => 'Choose Top Menu',
	  		        	    'id' => 'floating_top_menu',
	  		        	    'type' => 'select',
	  		        	    'desc' => 'Choose The Top Menu.',
	  		        	    'choices' => $this->get_current_menus(),
	  		        	    'std' => 'main-nav',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	array(
	  		        	    'label' => 'Show Social Icons On Right',
	  		        	    'id' => 'floating_social_enable',
	  		        	    'type' => 'on_off',
	  		        	    'desc' => 'Show Social Icons On Left or not.',
	  		        	    'std' => 'on',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	$this->get_content( 'floating_custom_content' , 'Custom Content' , ''),
	  		        	
	  		        	array(
	  		        	    'label' => 'Floating Bar Background Color',
	  		        	    'id' => 'floating_background',
	  		        	    'type' => 'colorpicker',
	  		        	    'desc' => 'Floating Bar Background Color.<br/><br/>Leave blank for default color of the skin.',
	  		        	    'std' => '',
	  		        	    'rows' => '',
	  		        	    'post_type' => '',
	  		        	    'taxonomy' => '',
	  		        	    'class' => ''
	  		        	),
	  		        	
	  		        	
	  		        )
	  		        ,
	  		        'std' => '',
	  		        'rows' => '',
	  		        'post_type' => '',
	  		        'taxonomy' => '',
	  		        'class' => ''
	  		    );
	    
	    if(!class_exists('C5_post')){
	    	return;
	    }
	    $post_obj = new C5_post();
	    $breaking_news_content = array(
	    	        'id' => 'meta_breaking_news',
	    	        'title' => 'Breaking News Bar',
	    	        'desc' => '',
	    	        'pages' => array('header'),
	    	        'context' => 'normal',
	    	        'priority' => 'low',
	    	        'fields' => array(
	    	        	array(
	    	        	    'label' => 'Show Breaking News Bar',
	    	        	    'id' => 'breaking_enable',
	    	        	    'type' => 'on_off',
	    	        	    'desc' => 'Choose to Show Breaking News Bar or not.',
	    	        	    'std' => 'on',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	
	    	        	array(
	    	        	    'label' => 'Breaking News title',
	    	        	    'id' => 'breaking_title',
	    	        	    'type' => 'text',
	    	        	    'desc' => 'Breaking News Title.',
	    	        	    'std' => 'Breaking News',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	
	    	        	$this->get_font_size_array('Breaking News Title' , 'breaking_news_title_fs' , '20'),
	    	        	$this->get_font_size_array('Breaking News Text' , 'breaking_news_text_fs' , '15'),
	    	        	array(
	    	        	    'label' => 'Follow Current Page query',
	    	        	    'id' => 'breaking_follow',
	    	        	    'type' => 'on_off',
	    	        	    'desc' => 'Follow Current Page query, if you are in category page then the query will be about this category etc.',
	    	        	    'std' => 'off',
	    	        	    'rows' => '',
	    	        	    'post_type' => '',
	    	        	    'taxonomy' => '',
	    	        	    'class' => ''
	    	        	),
	    	        	$post_obj->get_follow_array('breaking_follow' , 'off'),
	    	        	$post_obj->get_posts_per_page_array('breaking_posts_per_page', '10'),
	    	        	$post_obj->get_category_array('breaking_post_type' , 'post'),
	    	        	$post_obj->get_tags_array('breaking_tag' , ''),
	    	        	$post_obj->get_authors_array('breaking_author' , ''),
	    	        	$post_obj->get_orderby_array('breaking_orderby' , 'date'),
	    	        	$post_obj->get_order_array('breaking_order' , 'DESC' ),
	    	        	$post_obj->get_posts_input_array('breaking_posts' , ''),
	    	        	array(
	    	        	  'label'       => 'Breaking News Custom Content',
	    	        	  'id'          => 'breaking_custom',
	    	        	  'type'        => 'list-item',
	    	        	  'desc'        => 'Add Breaking News Custom Content.',
	    	        	  'settings'    => array(
	    	        	    array(
	    	        	      'label'       => '',
	    	        	      'id'          => 'textblock',
	    	        	      'type'        => 'textblock',
	    	        	      'desc'        => '',
	    	        	      'std'         => '',
	    	        	      'rows'        => '',
	    	        	      'post_type'   => '',
	    	        	      'taxonomy'    => '',
	    	        	      'class'       => ''
	    	        	    )
	    	        	    
	    	        	  ),
	    	        	  'std'         => '',
	    	        	  'rows'        => '',
	    	        	  'post_type'   => '',
	    	        	  'taxonomy'    => '',
	    	        	  'class'       => ''
	    	        	),
	    	        	
	    	        	
	    	        )
	    	        ,
	    	        'std' => '',
	    	        'rows' => '',
	    	        'post_type' => '',
	    	        'taxonomy' => '',
	    	        'class' => ''
	    	    );
	    
	    
	    
	    	    
	
		$header_defaults = array();
		
		foreach ($meta_header_background['fields'] as $option) {
			$header_defaults[$option['id']] = array($option['type'], $option['std']);
		}
		foreach ($meta_header_logo['fields'] as $option) {
			$header_defaults[$option['id']] = array($option['type'], $option['std']);
		}
		foreach ($top_bar_content['fields'] as $option) {
			$header_defaults[$option['id']] = array($option['type'], $option['std']);
		}
		foreach ($floating_bar_content['fields'] as $option) {
			$header_defaults[$option['id']] = array($option['type'], $option['std']);
		}
		foreach ($breaking_news_content['fields'] as $option) {
			$header_defaults[$option['id']] = array($option['type'], $option['std']);
		}
		
		
		update_option('c5_header_defaults', $header_defaults);
	    
	    ot_register_meta_box($meta_header_logo);
	    ot_register_meta_box($meta_header_background);
	    ot_register_meta_box($top_bar_content);
	    ot_register_meta_box($floating_bar_content);
	    ot_register_meta_box($breaking_news_content);
	    
	    
	   }
	   
	   
	   
	
}

 ?>