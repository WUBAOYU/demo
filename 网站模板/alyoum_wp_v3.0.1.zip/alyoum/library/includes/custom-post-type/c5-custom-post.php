<?php 

class C5_custom_post_type {
	function __construct() {
		add_action( 'init',  array($this, 'register_custom_posttype'));
	}
	function register_custom_posttype() {
		$custom_posts = ot_get_option('custom_posts', array());
		    if ($custom_posts) {
		        foreach ($custom_posts as $custom_post) {
		           
		            register_post_type( $custom_post['slug'], 
		            	array('labels' => array(
		            		'name' => $custom_post['title'],
		            		'singular_name' =>  $custom_post['title'],
		            		'all_items' => 'All items',
		            		'add_new' => 'Add New', 
		            		'add_new_item' => 'Add New '.$custom_post['title'] ,
		            		'edit' => 'Edit',
		            		'edit_item' => 'Edit '.$custom_post['title'], 
		            		'new_item' => 'New '.$custom_post['title'] , 
		            		'view_item' => 'View '.$custom_post['title'] , 
		            		'search_items' => 'Search '.$custom_post['title'] ,
		            		'not_found' =>  'Nothing found in the Database.', 
		            		'not_found_in_trash' => 'Nothing found in Trash',
		            		'parent_item_colon' => ''
		            		), 
		            		
		            		'description' => 'This is the example '.$custom_post['title'] ,
		            		'public' => true,
		            		'publicly_queryable' => true,
		            		'exclude_from_search' => false,
		            		'show_ui' => true,
		            		'query_var' => true,
		            		'menu_position' => 8, 
		            		'rewrite'	=> array( 'slug' => $custom_post['slug'], 'with_front' => false ), 
		            		'has_archive' => true,
		            		'capability_type' => 'post',
		            		'hierarchical' => false,
		            		'supports' => array( 'title',  'comments' ,'editor', 'thumbnail', 'excerpt'  , 'sticky' , 'post-formats'),
		            		'taxonomies' => array('post_tag' , $custom_post['category'])
		             	) 
		            ); 
		            
		            if($custom_post['category']!= ''){
		            register_taxonomy( $custom_post['category'], 
		            	array($custom_post['slug']), 
		            	array('hierarchical' => true,    
		            		'labels' => array(
		            			'name' => $custom_post['category_name'], 
		            			'singular_name' =>$custom_post['category_name'], 		            
		            			'search_items' =>   'Search '.$custom_post['category_name'],
		            			'all_items' => 'All '.$custom_post['category_name'], 
		            			'parent_item' =>  'Parent '.$custom_post['category_name'], 
		            			'parent_item_colon' => 'Parent '.$custom_post['category_name'].':',
		            			'edit_item' =>  'Edit '.$custom_post['category_name'],
		            			'update_item' =>  'Update '.$custom_post['category_name'], 
		            			'add_new_item' =>  'Add New '.$custom_post['category_name'],
		            			'new_item_name' =>  'New '.$custom_post['category_name'].' Name',	
		            		),
		            		'show_ui' => true,
		            		'query_var' => true,
		            	)
		            ); 
		            }
		            
		            
		        }
		    }
		
	}
}

$obj_custom_types = new C5_custom_post_type();


function c5_get_post_tax($id) {
	$post_type = get_post_type($id);
	$taxonomies=get_taxonomies();
	$skip = array(
		'post_tag',
		'nav_menu',
		'link_category',
		'post_format'
	);
	foreach ($taxonomies as $tax) {
		if(!in_array($tax , $skip) ){
			$tax_obj = get_taxonomy( $tax );
			if($tax_obj->object_type[0] == $post_type){
				return $tax;
			}
		}
	}
	
}

 ?>