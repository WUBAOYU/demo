<?php global $c5_skindata; ?>
<div id="main" class="c5-single-element c5-main-<?php echo $c5_skindata['layout_width'] ?> clearfix" role="main">

    <?php
    if ($c5_skindata['template_id'] != '') {
        echo do_shortcode('[c5ab_template id="' . $c5_skindata['template_id'] . '"]');
    } else {
        if (is_author()) {
            $obj = get_queried_object();
            echo do_shortcode('[c5ab_authors_info author_id="' . $obj->ID . '" ]');
        } elseif (is_category() || is_tax() || is_tag()) {
            $obj = get_queried_object();
            $tax = $obj->taxonomy;
            $term_id = $obj->term_id;
            $term = get_term($term_id, $tax);
            $icon = get_option('c5_term_meta_' . $tax . '_' . $term_id . '_icon');
            $class = 'no-icon';
            if ($icon != '') {
                $class = 'has-icon';
            }
            ?>
            <div class="c5-cat-info-warp <?php echo $class ?> clearfix">
                <?php if ($icon != '') { ?>
                    <div class="c5-cat-icon"><span class="<?php echo $icon ?>"></span></div>
                <?php } ?>
                <div class="c5-cat-info">
                    <h3><?php echo $term->name ?></h3>
                    <p><?php echo $term->description ?></p>
                </div>

            </div>
            <?php
        }


        echo do_shortcode('[c5ab_posts render_type="blog_1" height="400" follow="on" posts_per_page="10" post_type="post" tag="" author="" orderby="date" order="DESC" posts="" paging="on" show_title="off" show_excerpt="on" show_hover="link" show_cat="on" show_date="date" show_author="on" show_comment="on" show_likes="on" show_views="on" show_social="on" show_rating="on" ]');
    }
    ?>


</div>