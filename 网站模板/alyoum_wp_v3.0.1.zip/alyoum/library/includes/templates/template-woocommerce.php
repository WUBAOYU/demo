<?php
$obj_bread_crumb = new C5_bread_crumb();
$obj_bread_crumb->render();
global $c5_skindata;
?>
<div id="main" class="c5-single-element c5-main-<?php echo $c5_skindata['layout_width'] ?> clearfix" role="main">


    <?php woocommerce_content(); ?>

</div>