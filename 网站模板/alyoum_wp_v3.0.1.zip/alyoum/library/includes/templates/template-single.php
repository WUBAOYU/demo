<?php global $c5_skindata; ?>
<div id="main" class="c5-single-element c5-main-<?php echo $c5_skindata['layout_width'] ?> clearfix" role="main">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <?php setPostViews(get_the_ID()); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
                <?php $post_obj = new C5_post(); ?>
                <header class="article-header">

                    <h1 class="entry-title single-title" itemprop="headline"><?php the_title(); ?></h1>
                    <?php
                    $settings_obj = new C5_theme_options();
                    $article_obj = new C5_Article();
                    $meta_options = $settings_obj->get_meta_options();
                    if(!is_array($meta_options)){
                    	$meta_options = array();
                    }
                    $single_meta_style = $settings_obj->get_meta_option('single_meta_style');
                    if ($single_meta_style == 'line') {
                        $atts = array();
                        if (in_array('author', $meta_options)) {
                            $atts['show_author'] = 'on';
                        }
                        if (in_array('category', $meta_options)) {
                            $atts['show_cat'] = 'on';
                        }
                        if (in_array('date', $meta_options)) {
                            $c5_date_format = $settings_obj->get_meta_option('c5_date_format');
                            $atts['show_date'] = $c5_date_format;
                        }
                        if (in_array('comments_count', $meta_options)) {
                            $atts['show_comment'] = 'on';
                        }
                        if (in_array('like', $meta_options)) {
                            $atts['show_likes'] = 'on';
                        }
                        if (in_array('view', $meta_options)) {
                            $atts['show_views'] = 'on';
                        }

                        echo $post_obj->get_metadata($atts);
                    } else {
                        echo $post_obj->get_block_metadata();
                    }
                    
                    
                    if ( in_array('media', $meta_options) ) {
                        echo $post_obj->get_featured_media();
                    }
                    ?>
                    <div style="min-height:30px"></div>
                    <?php 
                    $article_before = $settings_obj->get_meta_option('article_before');
                    echo html_entity_decode( do_shortcode($article_before));
                     ?>
                </header>
                

                <section class="entry-content clearfix" itemprop="articleBody">
                    <?php the_content(); ?>

                    <!-- Navigation -->
                    <?php
                    wp_link_pages(
                            array(
                                'before' => '<nav class="page-links pagination"><span class="page-links-title">' . __('Pages:', 'code125') . '</span>',
                                'after' => '</nav>',
                                'link_before' => '<span>',
                                'link_after' => '</span>'));
                    ?> 
					
					<div style="min-height:30px;"></div>
                </section>

                <footer class="article-footer">
                	<?php 
                	$article_after = $settings_obj->get_meta_option('article_after');
                	echo html_entity_decode( do_shortcode($article_after));
                	 ?>
                    <?php
                    if (in_array('tags', $meta_options)) {
                        ?> <div class="c5-tags-wrap clearfix"> <?php
                        $code = '[c5ab_title apperance="title-style-1" title="' . __('Article Tags', 'code125') . '" font_size="20" font_weight="300" transform="normal" class="" icon="fa fa-tag" link="" id="" ]';
                        echo do_shortcode($code);
                        ?>
                            <div class="tags-meta tags clearfix"><?php the_tags('', ' ', ''); ?><div class="clearfix"></div></div>
                        </div>
                    <?php } ?>

                    <?php
                    if (in_array('related', $meta_options)) {
                        $article_obj->related_posts();
                    }
                    ?>

                </footer>

                <?php
                	$comments_order = $settings_obj->get_meta_option('comments_order');
                	if($comments_order == ''){
                		$comments_order = 'comments_facebook';
                	}
                	$comments_order_array = explode('_', $comments_order);
                	foreach ($comments_order_array as $comment_type) {
                		if($comment_type == 'facebook'){
                			if (in_array('fb_commnets', $meta_options) ) {
                				$article_obj->facebook_comment_form();
                			}
                		}else {
                			if (in_array('wp_commnets', $meta_options) ) {
                				$article_obj->comment_form();
                			}
                		}
                		
                	}
                	
                ?>

            </article>

        <?php endwhile; ?>

    <?php else : ?>

        <article id="post-not-found" class="hentry clearfix">
            <header class="article-header">
                <h1><?php _e('Oops, Post Not Found!', 'bonestheme'); ?></h1>
            </header>
            <section class="entry-content">
                <p><?php _e('Uh Oh. Something is missing. Try double checking things.', 'bonestheme'); ?></p>
            </section>
            <footer class="article-footer">
                <p><?php _e('This is the error message in the single.php template.', 'bonestheme'); ?></p>
            </footer>
        </article>

    <?php endif; ?>

</div>