<?php
$obj_bread_crumb = new C5_bread_crumb();
$obj_bread_crumb->render();
global $c5_skindata;
?>
<div id="main" class="c5-single-element c5-main-<?php echo $c5_skindata['layout_width'] ?> clearfix" role="main">



            <article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article">
				<header class="article-header">
				
													<h1 class="entry-title single-title" itemprop="headline"><?php _e('404 Error, Page not Found','code125'); ?></h1>
																	
												</header>
                <section class="entry-content clearfix">
                    <p><?php _e('The page you are looking for is not available try searching for what you need.','code125') ?></p>
                </section>

			</article>


</div>