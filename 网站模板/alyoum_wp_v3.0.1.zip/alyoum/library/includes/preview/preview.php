<?php 
class C5_preview {
	function __construct() {
		
	}
	
	
	function hook() {
		
		
		add_action( 'wp_enqueue_scripts', array($this,'wp_enqueue_scripts' )  );
		add_action('wp_footer' ,  array($this,'footer_js' ));
		
	}
	function wp_enqueue_scripts() {
		$preview = ot_get_option('preview');
		if($preview != 'on'){
			return;
		}
		wp_register_script( 'iris-js', get_stylesheet_directory_uri() . '/library/includes/preview/iris.min.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-widget' );
		wp_enqueue_script( 'jquery-ui-slider' );
		wp_enqueue_script( 'jquery-ui-draggable' );
			
			 
		
		wp_enqueue_script( 'iris-js' );
	}
	
	function render() {
		$color = '';
		if(isset($_POST['c5-preview-color'])){
			$color = $_POST['c5-preview-color'];
		}
		$layout = '';
		if(isset($_POST['c5-layout-mode'])){
			$layout = $_POST['c5-layout-mode'];
		}
		$menu = '';
		if(isset($_POST['c5-menu-mode'])){
			$menu = $_POST['c5-menu-mode'];
		}
		
		?>
		<div class="c5-preview-wrap c5-hide clearfix">
			
		<form method="post" action="" id="c5-preview">
		 <label for="c5-preview-color">Choose Color</label>
		 <input type="text" name="c5-preview-color" id="c5-preview-color" value="<?php echo $color ?>" />
		 
		 <div class="layout-images">
		 <label for="c5-layout-mode">Choose Layout</label>
		 	<input type="hidden" name="c5-layout-mode" id="c5-layout-mode" value="<?php echo $layout ?>" />
		 	<?php 
		 	$layout_array = array(
		 		'728-C',
		 		'960-B-C',
		 		'960-C-B',
		 		'960-C-S',
		 		'960-C',
		 		'960-S-C',
		 		'1170-B-C-S',
		 		'1170-B-C',
		 		'1170-B-S-C',
		 		'1170-C-B-S',
		 		'1170-C-B',
		 		'1170-C-S-B',
		 		'1170-C-S',
		 		'1170-C',
		 		'1170-S-B-C',
		 		'1170-S-C-B',
		 		'1170-S-C',
		 	);
		 	
		 	foreach ($layout_array as $value) {
		 	$selected = '';
		 	if($layout == $value){
		 		$selected = 'selected';
		 	}
		 		echo '<img src="'.C5_skins_URL. 'images/layout/'.$value.'.png" class="c5-img-layout '.$selected.'" data-value="'.$value.'" alt="" />';
		 	
		 	}
		 	
		 	 ?>
		 
		 </div>
		 
		 <div class="layout-images">
		 <label for="c5-menu-mode">Choose Menu Position</label>
		 	<input type="hidden" name="c5-menu-mode" id="c5-menu-mode" value="<?php echo $menu ?>" />
		 	<?php 
		 	
		 	$layout_array = array(
		 		'top',
		 		'side',
		 	);
		 	
		 	foreach ($layout_array as $value) {
		 		$selected = '';
		 		if($menu == $value){
		 			$selected = 'selected';
		 		}
		 		echo '<img src="'.C5_skins_URL. 'images/menu/'.$value.'.gif" class="c5-menu-layout '.$selected.'" data-value="'.$value.'" alt="" />';
		 	
		 	}
		 	
		 	 ?>
		 
		 </div>
		 
		 
		 <input type="submit" name="c5-submit-preview" id="c5-submit-preview" value="See Changes" />
		 </form>
		 <span class="fa fa-cog"></span>
		 </div>
		<?php
	}
	
	function footer_js() {
		$preview = ot_get_option('preview');
		if($preview != 'on'){
			return;
		}
		?>
		<script  type="text/javascript">
			jQuery(document).ready(function($) {
			    $('#c5-preview-color').iris({
			    	change: function(event, ui) {
			    	       $("#c5-preview-color").css( 'background', ui.color.toString());
			    	        $("#c5-preview-color").css( 'color', 'white');
			    	}
			    });
			    
			    $('.c5-img-layout').click(function () {
			    	$('.c5-img-layout').removeClass('selected');
			    	$(this).addClass('selected');
			    	$('#c5-layout-mode').val($(this).attr('data-value'));
			    	
			    });
			    
			    $('.c5-menu-layout').click(function () {
			    	$('.c5-menu-layout').removeClass('selected');
			    	$(this).addClass('selected');
			    	$('#c5-menu-mode').val($(this).attr('data-value'));
			    });
			    
			    $('.c5-preview-wrap .fa-cog').click(function () {
			    	if( $('.c5-preview-wrap').hasClass('c5-show') ){
			    		$('.c5-preview-wrap').removeClass('c5-show');
			    	}else {
			    		$('.c5-preview-wrap').addClass('c5-show');
			    	}
			    });
			    
			    $('.c5-show-sidenav').click(function () {
			    	if( $('.c5-preview-wrap').hasClass('c5-show') ){
			    		$('.c5-preview-wrap').removeClass('c5-show');
			    	}else {
			    		$('.c5-preview-wrap').addClass('c5-show');
			    	}
			    });
			    
			    
			});
		</script>
		<?php
	}
}


$C5_preview_obj = new C5_preview();
$C5_preview_obj->hook();

 ?>