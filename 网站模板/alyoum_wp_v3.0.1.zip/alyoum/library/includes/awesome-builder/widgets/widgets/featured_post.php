<?php 

class C5AB_featured_post extends C5_Widget {


	public  $_shortcode_name;
	public  $_shortcode_bool = true;
	public  $_options =array();
	
	
	function __construct() {
		
		$id_base = 'featured_post-widget';
		$this->_shortcode_name = 'c5ab_featured_post';
		$name = 'Featured Post';
		$desc = 'Featured Post';
		$classes = '';
		
		$this->self_construct($name, $id_base , $desc , $classes);
		
		
	}
	
	
	function shortcode($atts,$content) {
		
			$post_type = get_post_type($atts['post_id']);
		    $args  =array();
		    
		    $args['post_type'] = $post_type;
		    $args['p'] = $atts['post_id'];
		    // The Query
		    $the_query = new WP_Query( $args );
		    
		    
		    // The Loop
		    if ( $the_query->have_posts() ) {
		          while ( $the_query->have_posts() ) {
		    		$the_query->the_post();
		    		$return = '';
		    		
		    		        $class = '';
		    			$post_obj = new C5_post();
		    		        $cat_id = $post_obj->get_dominaiting_category();
		    		        if ($cat_id) {
		    		            $tax = c5_get_post_tax(get_the_ID());
		    		            $class = $tax . '-' . $cat_id;
		    		        }
		    		
		    		        $width = $GLOBALS['c5_content_width'];
		    		        $height = round( $width * 0.6);
		    		
		    		        $image_size = c5ab_generate_image_size($width, $height, true);
		    		        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);
		    		
		    				$code = '[c5ab_title apperance="title-style-1" title="' . $atts['featured_post'] . '" font_size="20" font_weight="300" transform="normal" class="' .$class . '" icon="' . $atts['icon'] . '" link="" id="" ]';
		    				
		    				
		    				
		    				 $return .= do_shortcode($code);
		    		        $return .= '<article  class=" c5ab_posts_thumb_boxes_single ' . $class . ' clearfix">';
		    		
		    		
		    		        $return .= '<div class="c5-boxes-thumb-hover  clearfix">';
		    		
		    		        $return .= $img_html . '</div>';
		    		
		    		
		    		        $return .= '<div class="box-content ">';
		    				
		    				
		    		        $return .= '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
		    		
		    		        $return .= '</div></article>';
		    		
		    	 }
		   	}
		    return $return;
		
	}
	
	
	function custom_css() {
		
	}
	
	function options() {
		$obj = new C5AB_ICONS();
		$icons = $obj->get_icons_as_images();
		
		
		
		
		
		$this->_options =array(
			
			array(
			    'label' => 'Title',
			    'id' => 'featured_post',
			    'type' => 'text',
			    'desc' => 'Title.',
			    'std' => '',
			    'rows' => '',
			    'post_type' => '',
			    'taxonomy' => '',
			    'class' => ''
			),
			array(
			  'label'       => 'Icon',
			  'id'          => 'icon',
			  'type'        => 'radio-text',
			  'desc'        => '',
			  'choices' => $icons,
			  'std'         => 'fa fa-none',
			  'rows'        => '',
			  'post_type'   => '',
			  'taxonomy'    => '',
			  'class'       => 'c5ab_icons'
			),
			array(
			    'label' => 'Post ID',
			    'id' => 'post_id',
			    'type' => 'text',
			    'desc' => 'Add your Post ID.',
			    'std' => '',
			    'rows' => '',
			    'post_type' => '',
			    'taxonomy' => '',
			    'class' => ''
			),
				 
		);
	}
	
	function css() {
		?>
		<style>
		
		
		h2.featured_post {
		  font-size: 16px;
		  font-weight: 600;
		  margin: 0px;
		  line-height: 1.4;
		  margin-bottom:20px;
		  font-family: "Helvetica Neue", Helvetica;
		}
		h2.featured_post .icon{
			margin-right:15px;
		}
		h2.featured_post.uppercase{
			text-transform:uppercase;
		}
		
		
		
		
		</style>
		<?php
	}

}


 ?>