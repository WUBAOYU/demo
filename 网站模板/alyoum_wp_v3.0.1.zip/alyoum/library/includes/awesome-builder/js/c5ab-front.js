jQuery(document).ready(function ($) {

	$('[c5ab-animation-data]').each(function(index){
		var b = $(window).scrollTop();
		var a = $(this).offset().top -  $(window).height();
		var animataion = $(this).attr('c5ab-animation-data');
		if(b > a){
			$(this).addClass('showme animated ' +  animataion);
		}
	});
	
	$(window).scroll(function() {
	    $('[c5ab-animation-data]').each(function(index){
	    	var b = $(window).scrollTop();
	    	var a = $(this).offset().top - $(window).height();
	    	var animataion = $(this).attr('c5ab-animation-data');
	    	if(b > a){
	    		$(this).addClass('showme animated ' +  animataion);
	    	}
	    });
	    
	});

});