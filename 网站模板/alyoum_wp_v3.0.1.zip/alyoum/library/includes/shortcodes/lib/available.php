<?php

	/**
	 * List of available shortcodes
	 */
	function code125_shortcodes( $shortcode = false ) {
		
		/* build category */
		$slides =  array();
		
		$query = new WP_Query( array( 'post_type' => 'slides', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ) );
		
		/* has posts */
		if ( $query->have_posts() ) {
		  while ( $query->have_posts() ) {
		    $query->the_post();
		    $slides[get_the_ID()] = get_the_title();
		  
		} 
		}
		wp_reset_postdata();
		
		
		$items_all = get_terms('item_type');
		$items_cats = array();
		$items_cats[''] = 'All Categories';
		$items_cats_only =array();
		foreach ($items_all as  $term) {
			 $items_cats[$term->term_id] = $term->name;
			 $items_cats_only[$term->term_id] = $term->name;
		}
		
		
		$users_all = get_users();
		
		$users = array();
		
		foreach ($users_all as $user) {
			$users[$user->ID]=$user->display_name;
		}
		
		$icons = array(
		'none',
		'icon-glass',
		'icon-music',
		'icon-search',
		'icon-envelope',
		'icon-heart',
		'icon-star',
		'icon-star-empty',
		'icon-user',
		'icon-film',
		'icon-th-large',
		'icon-th',
		'icon-th-list',
		'icon-ok',
		'icon-remove',
		'icon-zoom-in',
		'icon-zoom-out',
		'icon-off',
		'icon-signal',
		'icon-cog',
		'icon-trash',
		'icon-home',
		'icon-file',
		'icon-time',
		'icon-road',
		'icon-download-alt',
		'icon-download',
		'icon-upload',
		'icon-inbox',
		'icon-play-circle',
		'icon-repeat',
		'icon-rotate-right',
		'icon-refresh',
		'icon-list-alt',
		'icon-lock',
		'icon-flag',
		'icon-headphones',
		'icon-volume-off',
		'icon-volume-down',
		'icon-volume-up',
		'icon-qrcode',
		'icon-barcode',
		'icon-tag',
		'icon-tags',
		'icon-book',
		'icon-bookmark',
		'icon-print',
		'icon-camera',
		'icon-font',
		'icon-bold',
		'icon-italic',
		'icon-text-height',
		'icon-text-width',
		'icon-align-left',
		'icon-align-center',
		'icon-align-right',
		'icon-align-justify',
		'icon-list',
		'icon-indent-left',
		'icon-indent-right',
		'icon-facetime-video',
		'icon-picture',
		'icon-pencil',
		'icon-map-marker',
		'icon-adjust',
		'icon-tint',
		'icon-edit',
		'icon-share',
		'icon-check',
		'icon-move',
		'icon-step-backward',
		'icon-fast-backward',
		'icon-backward',
		'icon-play',
		'icon-pause',
		'icon-stop',
		'icon-forward',
		'icon-fast-forward',
		'icon-step-forward',
		'icon-eject',
		'icon-chevron-left',
		'icon-chevron-right',
		'icon-plus-sign',
		'icon-minus-sign',
		'icon-remove-sign',
		'icon-ok-sign',
		'icon-question-sign',
		'icon-info-sign',
		'icon-screenshot',
		'icon-remove-circle',
		'icon-ok-circle',
		'icon-ban-circle',
		'icon-arrow-left',
		'icon-arrow-right',
		'icon-arrow-up',
		'icon-arrow-down',
		'icon-share-alt',
		'icon-mail-forward',
		'icon-resize-full',
		'icon-resize-small',
		'icon-plus',
		'icon-minus',
		'icon-asterisk',
		'icon-exclamation-sign',
		'icon-gift',
		'icon-leaf',
		'icon-fire',
		'icon-eye-open',
		'icon-eye-close',
		'icon-warning-sign',
		'icon-plane',
		'icon-calendar',
		'icon-random',
		'icon-comment',
		'icon-magnet',
		'icon-chevron-up',
		'icon-chevron-down',
		'icon-retweet',
		'icon-shopping-cart',
		'icon-folder-close',
		'icon-folder-open',
		'icon-resize-vertical',
		'icon-resize-horizontal',
		'icon-bar-chart',
		'icon-twitter-sign',
		'icon-facebook-sign',
		'icon-camera-retro',
		'icon-key',
		'icon-cogs',
		'icon-comments',
		'icon-thumbs-up',
		'icon-thumbs-down',
		'icon-star-half',
		'icon-heart-empty',
		'icon-signout',
		'icon-linkedin-sign',
		'icon-pushpin',
		'icon-external-link',
		'icon-signin',
		'icon-trophy',
		'icon-github-sign',
		'icon-upload-alt',
		'icon-lemon',
		'icon-phone',
		'icon-check-empty',
		'icon-bookmark-empty',
		'icon-phone-sign',
		'icon-twitter',
		'icon-facebook',
		'icon-github',
		'icon-unlock',
		'icon-credit-card',
		'icon-rss',
		'icon-hdd',
		'icon-bullhorn',
		'icon-bell',
		'icon-certificate',
		'icon-hand-right',
		'icon-hand-left',
		'icon-hand-up',
		'icon-hand-down',
		'icon-circle-arrow-left',
		'icon-circle-arrow-right',
		'icon-circle-arrow-up',
		'icon-circle-arrow-down',
		'icon-globe',
		'icon-wrench',
		'icon-tasks',
		'icon-filter',
		'icon-briefcase',
		'icon-fullscreen',
		'icon-group',
		'icon-link',
		'icon-cloud',
		'icon-beaker',
		'icon-cut',
		'icon-copy',
		'icon-paper-clip',
		'icon-save',
		'icon-sign-blank',
		'icon-reorder',
		'icon-list-ul',
		'icon-list-ol',
		'icon-strikethrough',
		'icon-underline',
		'icon-table',
		'icon-magic',
		'icon-truck',
		'icon-pinterest',
		'icon-pinterest-sign',
		'icon-google-plus-sign',
		'icon-google-plus',
		'icon-money',
		'icon-caret-down',
		'icon-caret-up',
		'icon-caret-left',
		'icon-caret-right',
		'icon-columns',
		'icon-sort',
		'icon-sort-down',
		'icon-sort-up',
		'icon-envelope-alt',
		'icon-linkedin',
		'icon-undo',
		'icon-rotate-left',
		'icon-legal',
		'icon-dashboard',
		'icon-comment-alt',
		'icon-comments-alt',
		'icon-bolt',
		'icon-sitemap',
		'icon-umbrella',
		'icon-paste',
		'icon-lightbulb',
		'icon-exchange',
		'icon-cloud-download',
		'icon-cloud-upload',
		'icon-user-md',
		'icon-stethoscope',
		'icon-suitcase',
		'icon-bell-alt',
		'icon-coffee',
		'icon-food',
		'icon-file-alt',
		'icon-building',
		'icon-hospital',
		'icon-ambulance',
		'icon-medkit',
		'icon-fighter-jet',
		'icon-beer',
		'icon-h-sign',
		'icon-plus-sign-alt',
		'icon-double-angle-left',
		'icon-double-angle-right',
		'icon-double-angle-up',
		'icon-double-angle-down',
		'icon-angle-left',
		'icon-angle-right',
		'icon-angle-up',
		'icon-angle-down',
		'icon-desktop',
		'icon-laptop',
		'icon-tablet',
		'icon-mobile-phone',
		'icon-circle-blank',
		'icon-quote-left',
		'icon-quote-right',
		'icon-spinner',
		'icon-circle',
		'icon-reply',
		'icon-mail-reply',
		'icon-folder-close-alt',
		'icon-folder-open-alt',
		'icon-expand-alt',
		'icon-collapse-alt',
		'icon-smile',
		'icon-frown',
		'icon-meh',
		'icon-gamepad',
		'icon-keyboard',
		'icon-flag-alt',
		'icon-flag-checkered',
		'icon-terminal',
		'icon-code',
		'icon-reply-all',
		'icon-mail-reply-all',
		'icon-star-half-full',
		'icon-star-half-empty',
		'icon-location-arrow',
		'icon-crop',
		'icon-code-fork',
		'icon-unlink',
		'icon-question',
		'icon-info',
		'icon-exclamation',
		'icon-superscript',
		'icon-subscript',
		'icon-eraser',
		'icon-puzzle-piece',
		'icon-microphone',
		'icon-microphone-off',
		'icon-shield',
		'icon-calendar-empty',
		'icon-fire-extinguisher',
		'icon-rocket',
		'icon-maxcdn',
		'icon-chevron-sign-left',
		'icon-chevron-sign-right',
		'icon-chevron-sign-up',
		'icon-chevron-sign-down',
		'icon-html5',
		'icon-css3',
		'icon-anchor',
		'icon-unlock-alt',
		'icon-bullseye',
		'icon-ellipsis-horizontal',
		'icon-ellipsis-vertical',
		'icon-rss-sign',
		'icon-play-sign',
		'icon-ticket',
		'icon-minus-sign-alt',
		'icon-check-minus',
		'icon-level-up',
		'icon-level-down',
		'icon-check-sign',
		'icon-edit-sign',
		'icon-external-link-sign',
		'icon-share-sign'
		
		);
		$new_icons= array();
		foreach ($icons as $icon ) {
			$new_icons[$icon] = substr($icon, 5);
		}
		
		
		
		$args=array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );
		$categories=get_categories($args);
		$cats=array();
		$cats_slug = array();
		$cats['']= 'All Categories';
		$cats_only = array();
		  foreach($categories as $category) { 
		    $cats[  $category->term_id  ] =   $category->name;
		    $cats_only[ $category->term_id ] = $category->name;
		    $cats_slug[ $category->slug] =  $category->name;
		  } 
		
		
		$sidebars_new = ot_get_option( 'sidebars', array() );
		 
		$sidebars= array(
			'default' => 'Default',
			'primary' => 'Primary Sidebar',
			'post' => 'Post Sidebar',
			'page' => 'Page Sidebar'
		);
		
		foreach ($sidebars_new as $sidebar_new) {
		
			$sidebars[ $sidebar_new['slug'] ] = $sidebar_new['title'];
			
		}
		
		$shortcodes = array(
			# basic shortcodes - start
			'basic-shortcodes-open' => array(
				'name' => __( 'Basic shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			# row
			'row' => array(
				'name' => 'row',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# row_fluid
			'row_fluid' => array(
				'name' => 'row_fluid',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 1_12
			'1_12' => array(
				'name' => '1_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 2_12
			'2_12' => array(
				'name' => '2_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 3_12
			'3_12' => array(
				'name' => '3_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			# 4_12
			'4_12' => array(
				'name' => '4_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 5_12
			'5_12' => array(
				'name' => '5_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 6_12
			'6_12' => array(
				'name' => '6_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 7_12
			'7_12' => array(
				'name' => '7_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 8_12
			'8_12' => array(
				'name' => '8_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 9_12
			'9_12' => array(
				'name' => '9_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 10_12
			'10_12' => array(
				'name' => '10_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 11_12
			'11_12' => array(
				'name' => '11_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# 12_12
			'12_12' => array(
				'name' => '12_12',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# text
			'text' => array(
				'name' => 'text',
				'type' => 'wrap',
				'atts' => array(),
				'content' => 'Content'
			),
			
			# sidebar
			'sidebar' => array(
				'name' => 'sidebar',
				'type' => 'wrap',
				'atts' => array(
					'float' => array(
						'values' => array('left'=>'Left','right'=>'Right') ,
						'default' => 'left',
						'desc' => __( 'Float', 'code125-admin' )
					),
					'slug' => array(
						'values' => $sidebars ,
						'default' => 'left',
						'desc' => __( 'Sidebar', 'code125-admin' )
					)
				)
			),
			
			# title
			'title' => array(
				'name' => 'title',
				'type' => 'wrap',
				'atts' => array(
					'title' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Title', 'code125-admin' )
					),'icon' => array(
						'values' => $new_icons,
						'default' => 'icon arrow',
						'desc' => __( 'Button icon', 'code125-admin' )
					)
				),
				'usage' => '[title title="Title"] ',
				'desc' => __( 'Title Shortcode', 'code125-admin' ),
				'content_off' => 'off'
			),
		
			# categories
			'categories' => array(
				'name' => 'categories',
				'type' => 'wrap',
				'atts' => array(
					'type' => array(
						'values' => array(
								'post' => 'Post',
								'recipe' => 'Recipe'
						),
						'default' => 'post',
						'desc' => __( 'Type', 'code125-admin' )
					)
				),
				'usage' => '[title title="Title"] ',
				'desc' => __( 'Title Shortcode', 'code125-admin' ),
				'content_off' => 'off'
			),

			# authors
			'authors' => array(
				'name' => 'authors',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[title title="Title"] ',
				'desc' => __( 'Title Shortcode', 'code125-admin' ),
				'content_off' => 'off'
			),
			# posts_list
			'posts_list' => array(
				'name' => 'posts_list',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[title title="Title"] ',
				'desc' => __( 'Title Shortcode', 'code125-admin' ),
				'content_off' => 'off'
			),
			# comments
			'comments' => array(
				'name' => 'comments',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[title title="Title"] ',
				'desc' => __( 'Title Shortcode', 'code125-admin' ),
				'content_off' => 'off'
			),
						
			# dropcap
			'dropcap' => array(
				'name' => 'dropcap',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[dropcap] Tab Letter [/dropcap]',
				'content' => __( 'L', 'code125-admin' ),
				'desc' => ''
			),
			# dropcap2
			'dropcap2' => array(
				'name' => 'dropcap2',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[dropcap2] Tab Letter [/dropcap2]',
				'content' => __( 'L', 'code125-admin' ),
				'desc' => ''
			),
			# image
			'image' => array(
				'name' => 'image',
				'type' => 'wrap',
				'atts' => array(
					'width' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Width, in px, just write the number', 'code125-admin' )
					),
					'height' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Height, in px, just write the number', 'code125-admin' )
					),
					'src' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Image Source', 'code125-admin' )
					),
					'caption' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Image Caption', 'code125-admin' )
					),
					'float' => array(
						'values' => array(
								'left' => 'Left',
								'right' => 'Right',
								'none' => 'None'
						),
						'default' => 'none',
						'desc' => __( 'Float', 'code125-admin' )
					)
			
				),
				'desc' =>''
			),
			# fancybox
			'fancybox' => array(
				'name' => 'fancybox',
				'type' => 'wrap',
				'atts' => array(
						'w' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Width, in px, just write the number', 'code125-admin' )
						),
						'h' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Height, in px, just write the number', 'code125-admin' )
						),
						'src' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Image Source', 'code125-admin' )
						),
						'caption' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Image Caption', 'code125-admin' )
						)),
				'desc' => ''
			),
			
			# ul
			'ul' => array(
				'name' => 'ul',
				'type' => 'wrap',
				'atts' => array(
					'float' => array(
						'values' => array(
								'left' => 'Left',
								'right' => 'Right',
								'none' => 'None'
						),
						'default' => 'none',
						'desc' => __( 'Li Float', 'code125-admin' )
					)
				),
				'usage' => '[ul] [li icon="phone"] li content [/li] [/ul]',
				'desc' => '',
				'content' => '',
				'child' => 'li'
			),
			# li
			'li' => array(
				'name' => 'li',
				'type' => 'wrap',
				'atts' => array(
					'icon' => array(
						'values' => $new_icons,
						'default' => 'icon-ok',
						'desc' => __( 'Icon', 'code125-admin' )
					),
						
					
				),
				'usage' => '[li title="icon"] li content [/li]',
				'content' => __( 'li content', 'code125-admin' )
			),
			
			
			# input
			'input' => array(
				'name' => 'input',
				'type' => 'wrap',
				'atts' => array(
					'placeholder' => array(
						'values' => array(),
						'default' => '',
						'desc' => __( 'Placeholder text', 'code125-admin' )
					),
					'id' => array(
						'values' => array(),
						'default' => '',
						'desc' => __( 'ID for input', 'code125-admin' )
					),
					'icon' => array(
						'values' =>$new_icons,
						'default' => 'none',
						'desc' => __( 'Icon', 'code125-admin' )
					)
				)
			),
			
			# textarea
			'textarea' => array(
				'name' => 'textarea',
				'type' => 'wrap',
				'atts' => array(
					'placeholder' => array(
						'values' => array(),
						'default' => '',
						'desc' => __( 'Placeholder text', 'code125-admin' )
					),
					'id' => array(
						'values' => array(),
						'default' => '',
						'desc' => __( 'ID for texarea', 'code125-admin' )
					)
				)
			),
			
			
			# button
			'button' => array(
				'name' => 'button',
				'type' => 'wrap',
				'atts' => array(
						'color' => array(
							'values' => array(
									'default-color' => 'Default',
									'btn-primary' => 'Primary',
									'btn-info' => 'Info',
									'btn-success' => 'Success',
									'btn-warning' => 'Warning',
									'btn-danger' => 'Danger',
									'btn-inverse' => 'Inverse'
							),
							'default' => 'blue',
							'desc' => __( 'Button Color', 'code125-admin' )
						),
						'size' => array(
							'values' => array(
									'btn-mini' => 'Mini',
									'btn-small' => 'Small',
									'default-size' => 'Default',
									'btn-large' => 'Large',
									'btn-block' => 'Default - float',
									'btn-large btn-block' => 'Large - Float'
							),
							'default' => 'default-size',
							'desc' => __( 'Button Size', 'code125-admin' )
						),
						'float' => array(
							'values' => array(
									'left' => 'Left',
									'right' => 'Right'
							),
							'default' => 'left',
							'desc' => __( 'Float', 'code125-admin' )
						),
						'text' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Button Text', 'code125-admin' )
						),
						'link' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Button Link', 'code125-admin' )
						)
				)
			),
			
			# button_2
			'button_2' => array(
				'name' => 'button_2',
				'type' => 'wrap',
				'atts' => array(
						'color' => array(
							'values' => array(),
							'default' => ot_get_option( 'primary_color' ),
							'desc' => __( 'Button Color', 'code125-admin' )
						),
						'size' => array(
							'values' => array(
									'button-mini' => 'Mini',
									'button-small' => 'Small',
									'button-med' => 'Med',
									'button-large' => 'Large'
							),
							'default' => 'button-med',
							'desc' => __( 'Button Size', 'code125-admin' )
						),
						'icon' => array(
							'values' => $new_icons,
							'default' => 'icon arrow',
							'desc' => __( 'Button icon', 'code125-admin' )
						),
						'float' => array(
							'values' => array(
									'left' => 'Left',
									'right' => 'Right',
									'none'=> 'None'
							),
							'default' => 'left',
							'desc' => __( 'Float', 'code125-admin' )
						),
						'text' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Button Text', 'code125-admin' )
						),
						'link' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Button Link', 'code125-admin' )
						),
						'id' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Button id', 'code125-admin' )
						)
				)
			),
			
			# box
			'box' => array(
				'name' => 'box',
				'type' => 'wrap',
				'atts' => array(
						'type' => array(
							'values' => array(
									'notice' => 'Notice',
									'info' => 'Info',
									'warning' => 'Warning',
									'success' => 'Success'
							),
							'default' => 'info',
							'desc' => __( 'Box Type', 'code125-admin' )
						),
						'title' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Box Title', 'code125-admin' )
						),
						'message' => array(
							'values' => array( ),
							'default' => '',
							'desc' => __( 'Box Message', 'code125-admin' )
						)
				)
			),
			
			# divider_space
			'divider_space' => array(
				'name' => 'divider_space',
				'type' => 'wrap',
				'atts' => array()
			),
			
			# divider
			'divider' => array(
				'name' => 'divider',
				'type' => 'wrap',
				'atts' => array()
			),
			
			# basic shortcodes - end
			'basic-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			
			'tabs-shortcodes-open' => array(
				'name' => __( 'Tabs shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			# tabgroup
			'tabgroup' => array(
				'name' => 'tabgroup',
				'type' => 'wrap',
				'atts' => array(
					
				),
				'usage' => '[tabgroup] [tab title="Tab name"] Tab content [/tab] [/tabgroup]',
				'desc' =>'',
				'child' => 'tab'
			),
			# tab
			'tab' => array(
				'name' => 'tab',
				'type' => 'wrap',
				'atts' => array(
				'title' => array(
					'values' => array( ),
					'default' => __( 'Title', 'code125-admin' ),
					'desc' => __( 'Tab title', 'code125-admin' )
				),
				'icon' => array(
					'values' => $new_icons,
					'default' => 'none',
					'desc' => __( 'Icon', 'code125-admin' )
				)
				),
				'usage' => '[tab title="Tab name"] Tab content [/tab]',
				'content' => __( 'Tab content', 'code125-admin' ),
				'desc' =>''
			),
			# fancy_tabgroup
			'fancy_tabgroup' => array(
				'name' => 'fancy_tabgroup',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[fancy_tabgroup] [fancy_tab title="Tab name"] Tab content [/fancy_tab] [/fancy_tabgroup]',
				'desc' =>'',
				'child' => 'fancy_tab'
			),
			# fancy_tab
			'fancy_tab' => array(
				'name' => 'fancy_tab',
				'type' => 'wrap',
				'atts' => array(
					'title' => array(
						'values' => array( ),
						'default' => __( 'Title', 'code125-admin' ),
						'desc' => __( 'Tab title', 'code125-admin' )
					),
					'icon' => array(
						'values' => $new_icons,
						'default' => 'none',
						'desc' => __( 'Icon', 'code125-admin' )
					) ),
				'usage' => '[fancy_tab title="Tab name"] Tab content [/fancy_tab]',
				'content' => __( 'Tab content', 'code125-admin' ),
				'desc' =>''
			),
						
			# accordiongroup
			'accordiongroup' => array(
				'name' => 'accordiongroup',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[accordiongroup] [accordion title="Tab name"] Tab content [/accordion] [/accordiongroup]',
				'desc' => '',
				'child' => 'accordion'
			),
			# accordion
			'accordion' => array(
				'name' => 'accordion',
				'type' => 'wrap',
				'atts' => array(
					'title' => array(
						'values' => array( ),
						'default' => __( 'Title', 'code125-admin' ),
						'desc' => __( 'Tab title', 'code125-admin' )
					)
					),
				'usage' => '[accordion title="Tab name"] Tab content [/accordion]',
				'content' => __( 'Tab content', 'code125-admin' ),
				'desc' => ''
			),
			# toggle
			'toggle' => array(
				'name' => 'toggle',
				'type' => 'wrap',
				'atts' => array(
					'title' => array(
						'values' => array( ),
						'default' => __( 'Title', 'code125-admin' ),
						'desc' => __( 'Tab title', 'code125-admin' )
					)),
				'usage' => '[toggle title="Tab name"] Tab content [/toggle]',
				'content' => __( 'Toggle content', 'code125-admin' ),
				'desc' => ''
			),
			# is_logged_in
			'is_logged_in' => array(
				'name' => 'is_logged_in',
				'type' => 'wrap',
				'atts' => array(),
				'content' => __( 'is_logged_in content', 'code125-admin' ),
				'desc' => ''
			),
			# is_logged_out
			'is_logged_out' => array(
				'name' => 'is_logged_out',
				'type' => 'wrap',
				'atts' => array(),
				'content' => __( 'is_logged_out content', 'code125-admin' ),
				'desc' => ''
			),
		
			
			# basic shortcodes - end
			'tabs-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			
			'slider-shortcodes-open' => array(
				'name' => __( 'Sliders shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			# slider
			'slider' => array(
				'name' => 'slider',
				'type' => 'wrap',
				'atts' => array(
					
				),
				'usage' => '[slider] [slide id=""]  [/slider]',
				'desc' =>'',
				'child' => 'slide'
			),
			# slide
			'slide' => array(
				'name' => 'slide',
				'type' => 'wrap',
				'atts' => array(
					'id' => array(
						'values' => $slides,
						'desc' => __( 'Slide', 'code125-admin' ),
						'default' => ''
					)
				),
				'usage' => '[slide id=""]',
				'desc' =>''
			),
						
			
			# flexslider
			'flexslider' => array(
				'name' => 'flexslider',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[flexslider] [flexslider_slide title="Tab name"] Tab content [/flexslider_slide] [/flexslider]',
				'desc' => '',
				'child' => 'flexslider_slide'
				
			),
			# flexslider_slide
			'flexslider_slide' => array(
				'name' => 'flexslider_slide',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[flexslider_slide title="Tab name"] Tab content [/flexslider_slide]',
				'content' => __( 'Tab content', 'code125-admin' ),
				'desc' => ''
			),			
			
			# posts_slider
			'posts_slider' => array(
				'name' => 'posts_slider',
				'type' => 'wrap',
				'atts' => array('style' => array(
					'values' => array(
							'detailed' => 'Detailed',
							'title' => 'Just Title'
					),
					'default' => 'detailed',
					'desc' => __( 'Slider Data', 'code125-admin' )
				)),
				'usage' => '[posts_2 number_of_posts="3"]',
				'desc' => __( 'posts_2.', 'code125-admin' ),
				'child' => 'posts_slide'
			),
			# posts_slide
			'posts_slide' => array(
				'name' => 'posts_slide',
				'type' => 'wrap',
				'atts' => array(
					'id' => array(
						'values' => array(),
						'desc' => __( 'Post ID', 'code125-admin' ),
						'default' => ''
					)
				),
				'usage' => '[posts_slide id=""]',
				'desc' =>''
			),
			# posts_slider_auto
			'posts_slider_auto' => array(
				'name' => 'posts_slider_auto',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'style' => array(
							'values' => array(
									'detailed' => 'Detailed',
									'title' => 'Just Title'
							),
							'default' => 'title',
							'desc' => __( 'Slider Data', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Slides', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			
			# basic shortcodes - end
			'slider-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			
			
			
			
			
			
			'page-shortcodes-open' => array(
				'name' => __( 'Page Elements shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			
			# contact_form
			'contact_form' => array(
				'name' => 'contact_form',
				'type' => 'wrap',
				'atts' => array(
					'name' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Placeholder for name', 'code125-admin' )
					),
					'email' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Placeholder for email', 'code125-admin' )
					),
					'message' => array(
						'values' => array( ),
						'default' => '',
						'desc' => __( 'Placeholder for message', 'code125-admin' )
					),
					'send' => array(
						'values' => array( ),
						'default' => 'Send',
						'desc' => __( 'Text for send', 'code125-admin' )
					)
					),
				'usage' => '[contact_form]',
				'desc' => __( 'contact_form.', 'code125-admin' ),
				
			),
			# review_box
			'review_box' => array(
				'name' => 'review_box',
				'type' => 'wrap',
				'atts' => array(),
				'usage' => '[review_box]',
				'desc' =>  'review_box.' ,
				
			),
			
			
			
			# basic shortcodes - end
			'page-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			
			
			'posts-shortcodes-open' => array(
				'name' => __( 'Posts shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
					
			# posts
			'posts' => array(
				'name' => 'posts',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),

			# posts_2
			'posts_2' => array(
				'name' => 'posts_2',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# posts_3
			'posts_3' => array(
				'name' => 'posts_3',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# posts_4
			'posts_4' => array(
				'name' => 'posts_4',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10',
									'11' => '11',
									'12' => '12',
									'13' => '13',
									'14' => '14',
									'15' => '15',
									'16' => '16'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# posts_5
			'posts_5' => array(
				'name' => 'posts_5',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(),
							'default' => '15',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'size' => array(
							'values' => array(
									'large' => 'Large',
									'small' => 'Small'
							),
							'default' => 'large',
							'desc' => __( 'Metro Size', 'code125-admin' )
						)
				)
			),
			# items
			'items' => array(
				'name' => 'items',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# items_2
			'items_2' => array(
				'name' => 'items_2',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# items_3
			'items_3' => array(
				'name' => 'items_3',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# items_4
			'items_4' => array(
				'name' => 'items_4',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9'
							),
							'default' => '5',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# items_5
			'items_5' => array(
				'name' => 'items_5',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(),
							'default' => '15',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						)
						,
						'paging' => array(
							'values' => array(
									'false' => 'False',
									'true' => 'True'
							),
							'default' => 'false',
							'desc' => __( 'Paging Bool', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'size' => array(
							'values' => array(
									'large' => 'Large',
									'small' => 'Small'
							),
							'default' => 'large',
							'desc' => __( 'Metro Size', 'code125-admin' )
						)
				)
			),
			
			# author_box
			'author_box' => array(
				'name' => 'author_box',
				'type' => 'wrap',
				'atts' => array(
						'id' => array(
							'values' => $users ,
							'default' => '',
							'desc' => __( 'Author', 'code125-admin' )
						)
				)
			),
			# list_box
			'list_box' => array(
				'name' => 'list_box',
				'type' => 'wrap',
				'atts' => array(
				)
			),
			
			# compare
			'compare' => array(
				'name' => 'compare',
				'type' => 'wrap',
				'atts' => array(
						'col' => array(
							'values' => array(
									'yes' => 'Yes',
									'no' => 'No'
							),
							'default' => 'yes',
							'desc' => __( 'Right Column', 'code125-admin' )
						),
						'type' => array(
							'values' => array(
									'post' => 'Post',
									'item' => 'Item'
							),
							'default' => 'post',
							'desc' => __( 'Post Type', 'code125-admin' )
						),
						'id_1' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Article 1', 'code125-admin' )
						),
						'id_2' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Article 2', 'code125-admin' )
						),
						'id_3' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Article 3', 'code125-admin' )
						),
						'id_4' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Article 4', 'code125-admin' )
						)
				)
			),
			# compare_box_item
			'compare_box_item' => array(
				'name' => 'compare_box_item',
				'type' => 'wrap',
				'atts' => array(
						'col' => array(
							'values' => array(
									'yes' => 'Yes',
									'no' => 'No'
							),
							'default' => 'yes',
							'desc' => __( 'Right Column', 'code125-admin' )
						),
						'number_of_posts' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4'
							) ,
							'default' => '',
							'desc' => __( 'Number of Items to Compare', 'code125-admin' )
						),
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Category', 'code125-admin' )
						)
				)
			),
			# compare_box_post
			'compare_box_post' => array(
				'name' => 'compare_box_post',
				'type' => 'wrap',
				'atts' => array(
						'col' => array(
							'values' => array(
									'yes' => 'Yes',
									'no' => 'No'
							),
							'default' => 'yes',
							'desc' => __( 'Right Column', 'code125-admin' )
						),
						'number_of_posts' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4'
							) ,
							'default' => '',
							'desc' => __( 'Number of Items to Compare', 'code125-admin' )
						),
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Category', 'code125-admin' )
						)
				)
			),
			
			
			
			# category
			'category' => array(
				'name' => 'category',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# category_list
			'category_list' => array(
				'name' => 'category_list',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
				)
			),
			
			#category_thumb_list
			'category_thumb_list' => array(
				'name' => 'category_thumb_list',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
			# category_style_3
			'category_style_3' => array(
				'name' => 'category_style_3',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'1' => '1',
									'3' => '3',
									'5' => '5',
									'7' => '7',
									'9' => '9',
							),
							'default' => '5',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
				)
			),
			# category_style_4
			'category_style_4' => array(
				'name' => 'category_style_4',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			#category_style_5
			'category_style_5' => array(
				'name' => 'category_style_5',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
			
			#category_style_6
			'category_style_6' => array(
				'name' => 'category_style_6',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(),
							'default' => '5',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
									
			# news_in_photos
			'news_in_photos' => array(
				'name' => 'news_in_photos',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'numberposts' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10',
									'11' => '11',
									'12' => '12',
									'13' => '13',
									'14' => '14',
									'15' => '15',
									'16' => '16',
									'17' => '17',
									'18' => '18'
							),
							'default' => '12',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# latest_news
			'latest_news' => array(
				'name' => 'latest_news',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'numberposts' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10',
									'11' => '11',
									'12' => '12',
									'13' => '13',
									'14' => '14',
									'15' => '15',
									'16' => '16',
									'17' => '17',
									'18' => '18'
							),
							'default' => '12',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				),
				'usage' => '[latest_news number_of_posts="3"]',
				'desc' => __( 'Latest News.', 'code125-admin' ),
				'content_off' => 'off'
			),
			
			
			
			# 5col_posts_fullwidth
			'5col_posts_fullwidth' => array(
				'name' => '5col_posts_fullwidth',
				'type' => 'wrap',
				'atts' => array(
						'type' => array(
							'values' => array(
									'post' => 'Post'
							),
							'default' => 'post',
							'desc' => __( 'Type', 'code125-admin' )
						),
						'title' => array(
							'values' => array(),
							'default' => 'Latest Projects',
							'desc' => __( 'Title', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			
			# 4col_posts
			'4col_posts' => array(
				'name' => '4col_posts',
				'type' => 'wrap',
				'atts' => array(
						'type' => array(
							'values' => array(
									'post' => 'Post'
							),
							'default' => 'post',
							'desc' => __( 'Type', 'code125-admin' )
						),
						'title' => array(
							'values' => array(),
							'default' => 'Latest Projects',
							'desc' => __( 'Title', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),

			# latest_posts
			'latest_posts' => array(
				'name' => 'latest_posts',
				'type' => 'wrap',
				'atts' => array(
						'title' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Title', 'code125-admin' )
						)
				)
			),
					
			'posts-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			'items-shortcodes-open' => array(
				'name' => __( 'Items', 'code125-admin' ),
				'type' => 'opengroup'
			),
			# category_item
			'category_item' => array(
				'name' => 'category_item',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			# category_items_list
			'category_items_list' => array(
				'name' => 'category_items_list',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
				)
			),
			#category_thumb_list_item
			'category_thumb_list_item' => array(
				'name' => 'category_thumb_list_item',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
			# category_style_item_3
			'category_style_item_3' => array(
				'name' => 'category_style_item_3',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'1' => '1',
									'3' => '3',
									'5' => '5',
									'7' => '7',
									'9' => '9',
							),
							'default' => '5',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
				)
			),
			# category_style_item_4
			'category_style_item_4' => array(
				'name' => 'category_style_item_4',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				)
			),
			#category_style_item_5
			'category_style_item_5' => array(
				'name' => 'category_style_item_5',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10'
							),
							'default' => '4',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
			
			#category_style_item_6
			'category_style_item_6' => array(
				'name' => 'category_style_6',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats_only ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						),
						'posts_per_page' => array(
							'values' => array(),
							'default' => '5',
							'desc' => __( 'Number of Articles to Show', 'code125-admin' )
						)
						
				)
			),
					
			# latest_items
			'latest_items' => array(
				'name' => 'latest_items',
				'type' => 'wrap',
				'atts' => array(
						'category' => array(
							'values' => $items_cats ,
							'default' => '',
							'desc' => __( 'Categories', 'code125-admin' )
						),
						'numberposts' => array(
							'values' => array(
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',
									'7' => '7',
									'8' => '8',
									'9' => '9',
									'10' => '10',
									'11' => '11',
									'12' => '12',
									'13' => '13',
									'14' => '14',
									'15' => '15',
									'16' => '16',
									'17' => '17',
									'18' => '18'
							),
							'default' => '12',
							'desc' => __( 'Number of Posts Per page', 'code125-admin' )
						),
						'order' => array(
							'values' => array(
									'ASC' => 'Ascending',
									'DESC' => 'Descending'
							),
							'default' => 'DESC',
							'desc' => __( 'Order Direction', 'code125-admin' )
						),
						'orderby' => array(
							'values' => array(
									'none' => 'None',
									'id' => 'Post ID',
									'author' => 'Author',
									'title' => 'Title',
									'date' => 'Date Created',
									'modified' => 'Date Modified',
									'parent' => 'Post/Page Parent ID',
									'rand' => 'Random',
									'comment_count' => 'Number of Comments',
									'menu_order' => 'Page Order'
							),
							'default' => 'date',
							'desc' => __( 'Order By', 'code125-admin' )
						)
				),
				'usage' => '[latest_news number_of_posts="3"]',
				'desc' => __( 'Latest News.', 'code125-admin' ),
				'content_off' => 'off'
			),
			
			
			'items-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			'social-shortcodes-open' => array(
				'name' => __( 'Social & Media shortcodes', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			
			
			# social_box
			'social_box' => array(
				'name' => 'social_box',
				'type' => 'wrap',
				'atts' => array()
			),
			# twitter
			'twitter' => array(
				'name' => 'twitter',
				'type' => 'wrap',
				'atts' => array(
					'consumerkey' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Consumer key', 'code125-admin' )
					),
					'consumersecret' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Consumer Secret Key', 'code125-admin' )
					),
					'accesstoken' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Accesstoken', 'code125-admin' )
					),
					'accesstokensecret' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Accesstoken Secret', 'code125-admin' )
					),
					'cachetime' => array(
						'values' => array(),
						'default' => '1',
						'desc' => __( 'Cache time in Hours', 'code125-admin' )
					),
					'username' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Username', 'code125-admin' )
					),
					'count' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Number of Tweets "Max 10"', 'code125-admin' )
					)
				)
			),
			
			
			
			
			
			# flickr
			'flickr' => array(
				'name' => 'flickr',
				'type' => 'wrap',
				'atts' => array(
					'id' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The ID of the Photostream', 'code125-admin' )
					),
					'count' => array(
						'values' => array() ,
						'default' => '9',
						'desc' => __( 'Number of Images', 'code125-admin' )
					)
				)
			),
			
			# googlemap_side
			'googlemap_side' => array(
				'name' => 'googlemap_side',
				'type' => 'wrap',
				'atts' => array(
						'lat' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Latitude', 'code125-admin' )
						),
						'long' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Longtitude', 'code125-admin' )
						)						
						
				)
			),
			
			
			# googlemap
			'googlemap' => array(
				'name' => 'googlemap',
				'type' => 'wrap',
				'atts' => array(
						'lat' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Latitude', 'code125-admin' )
						),
						'lon' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Longtitude', 'code125-admin' )
						),
						'z' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Zoom "number from 1 with step 1"', 'code125-admin' )
						),
						'h' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Height', 'code125-admin' )
						),
						'w' => array(
							'values' => array() ,
							'default' => '',
							'desc' => __( 'Width', 'code125-admin' )
						)
						
						
				)
			),
			
			# youtube
			'youtube' => array(
				'name' => 'youtube',
				'type' => 'wrap',
				'atts' => array(
				
					'id' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The ID of the Video', 'code125-admin' )
					),
					'width' => array(
						'values' => array() ,
						'default' => '100%',
						'desc' => __( 'Width', 'code125-admin' )
					),
					'height' => array(
						'values' => array() ,
						'default' => '300px',
						'desc' => __( 'Height', 'code125-admin' )
					)
				)
			),
			
			# vimeo
			'vimeo' => array(
				'name' => 'vimeo',
				'type' => 'wrap',
				'atts' => array(
					'clip_id' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The ID of the Video', 'code125-admin' )
					),
					'width' => array(
						'values' => array() ,
						'default' => '100%',
						'desc' => __( 'Width', 'code125-admin' )
					),
					'height' => array(
						'values' => array() ,
						'default' => '300px',
						'desc' => __( 'Height', 'code125-admin' )
					)
				
				)
			),
			
			# dailymotion
			'dailymotion' => array(
				'name' => 'dailymotion',
				'type' => 'wrap',
				'atts' => array(
					'id' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The ID of the Video', 'code125-admin' )
					),
					'width' => array(
						'values' => array() ,
						'default' => '100%',
						'desc' => __( 'Width', 'code125-admin' )
					),
					'height' => array(
						'values' => array() ,
						'default' => '300px',
						'desc' => __( 'Height', 'code125-admin' )
					)
				)
			),
			
			# video
			'video' => array(
				'name' => 'video',
				'type' => 'wrap',
				'atts' => array(
					'src' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The Source of the Video', 'code125-admin' )
					),
					'width' => array(
						'values' => array() ,
						'default' => '100%',
						'desc' => __( 'Width', 'code125-admin' )
					),
					'height' => array(
						'values' => array() ,
						'default' => '300px',
						'desc' => __( 'Height', 'code125-admin' )
					)
				)
			),
			
			# video5
			'video5' => array(
				'name' => 'video5',
				'type' => 'wrap',
				'atts' => array(
					'src' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The Source of the Video', 'code125-admin' )
					),
					'width' => array(
						'values' => array() ,
						'default' => '100%',
						'desc' => __( 'Width', 'code125-admin' )
					),
					'height' => array(
						'values' => array() ,
						'default' => '300px',
						'desc' => __( 'Height', 'code125-admin' )
					)
				)
			),
			
			# audio
			'audio' => array(
				'name' => 'audio',
				'type' => 'wrap',
				'atts' => array(
					'src' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'The Source of the audio', 'code125-admin' )
					)
				
				
				)
			),
			# audio
			'soundcloud' => array(
				'name' => 'audio',
				'type' => 'wrap',
				'atts' => array(
					'id' => array(
						'values' => array() ,
						'default' => '',
						'desc' => __( 'Track ID', 'code125-admin' )
					)
				
				
				)
			),
			
			# basic shortcodes - end
			'social-shortcodes-close' => array(
				'type' => 'closegroup'
			),
			
			
			
			'ads-shortcodes-open' => array(
				'name' => __( 'Ads', 'code125-admin' ),
				'type' => 'opengroup'
			),
			
			# ad_728x90
			'ad_728x90' => array(
				'name' => 'ad_728x90',
				'type' => 'wrap',
				'atts' => array(),
				'content' => ' '
				
			),
			
			
			# ad_468x60
			'ad_468x60' => array(
				'name' => 'ad_468x60',
				'type' => 'wrap',
				'atts' => array(),
				'content' => ' '
				
			),
			
			# ad_300x250
			'ad_300x250' => array(
				'name' => 'ad_300x250',
				'type' => 'wrap',
				'atts' => array(),
				'content' => ' '
				
			),
			
			
			# basic shortcodes - end
			'ads-shortcodes-close' => array(
				'type' => 'closegroup'
			)
			
	);
	
	

		if ( $shortcode )
			return $shortcodes[$shortcode];
		else
			return $shortcodes;
	}

?>