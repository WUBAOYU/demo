<?php

/**
 * Shortcode: Columns
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */




function code125_1_12($atts, $content = null) {
    return '<div class="span1">' . do_shortcode($content) . '</div>';
}

function code125_2_12($atts, $content = null) {
    return '<div class="span2">' . do_shortcode($content) . '</div>';
}

function code125_3_12($atts, $content = null) {
    return '<div class="span3">' . do_shortcode($content) . '</div>';
}

function code125_4_12($atts, $content = null) {
    return '<div class="span4">' . do_shortcode($content) . '</div>';
}

function code125_5_12($atts, $content = null) {
    return '<div class="span5">' . do_shortcode($content) . '</div>';
}

function code125_6_12($atts, $content = null) {
    return '<div class="span6">' . do_shortcode($content) . '</div>';
}

function code125_7_12($atts, $content = null) {
    return '<div class="span7">' . do_shortcode($content) . '</div>';
}

function code125_8_12($atts, $content = null) {
    return '<div class="span8">' . do_shortcode($content) . '</div>';
}

function code125_9_12($atts, $content = null) {
    return '<div class="span9">' . do_shortcode($content) . '</div>';
}

function code125_10_12($atts, $content = null) {
    return '<div class="span10">' . do_shortcode($content) . '</div>';
}

function code125_11_12($atts, $content = null) {
    return '<div class="span11">' . do_shortcode($content) . '</div>';
}

function code125_12_12($atts, $content = null) {
    return '<div class="span12">' . do_shortcode($content) . '</div>';
}

function code125_row($atts, $content = null) {
    return '<div class="row">' . do_shortcode($content) . '</div>';
}

function code125_row_fluid($atts, $content = null) {
    return '<div class="row-fluid">' . do_shortcode($content) . '</div>';
}

function code125_text($atts, $content = null) {
    return   html_entity_decode (do_shortcode( html_entity_decode($content)) );
}



/**
 * Shortcode: tab
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */


function code125_tab($atts, $content) {
    $atts = shortcode_atts(array(
        'title' => 'Tab %d',
        'icon' => ''    ), $atts);

    $x = $GLOBALS['tab_count'];
    $GLOBALS['tabs'][$x] = array('title' => sprintf($atts['title'], $GLOBALS['tab_count']), 'content' => $content , 'icon' => $atts['icon']);

    $GLOBALS['tab_count']++;
}

	

/**
 * Shortcode: tabgroup
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_tabgroup($atts, $content) {
    $GLOBALS['tab_count'] = 0;
	unset($GLOBALS['tabs']);
    do_shortcode($content);

    if (is_array($GLOBALS['tabs'])) {
    	$counter = 1;
        $tabs ='';
        $panes = '';
        foreach ($GLOBALS['tabs'] as $tab) {
        	if($counter == 1){
            $tabs = $tabs .'<li class="first_li"><a class="'.$tab['icon'].'" href="#">' . $tab['title'] . '</a></li>';
            $panes = $panes . '<div class="custom_tabs_content clearfix">' . do_shortcode($tab['content']) . '</div>';
            }else{
            $tabs = $tabs . '<li><a class="'.$tab['icon'].'" href="#">' . $tab['title'] . '</a></li>';
            $panes = $panes . '<div class="custom_tabs_content clearfix">' . do_shortcode($tab['content']) . '</div>';
            }
            $counter++;
        }
        $return = '<ul class="custom_tabs">' .  $tabs . '</ul><div class="custom_tabs_wrap">' .  $panes . '</div>' . "\n";
    }
    return $return;
}



/**
 * Shortcode: fancy_tabgroup
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_fancy_tabgroup($atts, $content) {
    $GLOBALS['fancy_tab_count'] = 0;
	unset($GLOBALS['fancy_tabs']);
    do_shortcode($content);

    if (is_array($GLOBALS['fancy_tabs'])) {
        $tabs = '';
        $panes = '';
        foreach ($GLOBALS['fancy_tabs'] as $tab) {
            $tabs = $tabs . '<li><a class="'.$tab['icon'].'" href="#">' . $tab['title'] . '</a></li>';
            $panes = $panes . '<div class="custom_tabs2_content clearfix">' . do_shortcode($tab['content']) . '</div>';
        }
        $return = "\n" . '<div class="custom_tabs2_container"><div class="left_tabs"><ul class="custom_tabs2">' .  $tabs . '</ul></div><div class="custom_tabs2_wrap">' .  $panes . '</div></div>' . "\n";
    }
    return $return;
}

/**
 * Shortcode: fancy_tab
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_fancy_tab($atts, $content) {
    $atts = shortcode_atts(array('title' => 'Tab %d','icon'=>''), $atts);

    $x = $GLOBALS['fancy_tab_count'];
    $GLOBALS['fancy_tabs'][$x] = array('title' => sprintf($atts['title'], $GLOBALS['fancy_tab_count']), 'content' => $content , 'icon'=>$atts['icon']);

    $GLOBALS['fancy_tab_count']++;
}



/**
 * Shortcode: accordiongroup
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_accordiongroup($atts, $content) {
    $GLOBALS['accordion_count'] = 0;
    	unset($GLOBALS['accordion']);
        do_shortcode($content);
        $counter = 0;
        $tabs = '';
        if (is_array($GLOBALS['accordion'])) {
            foreach ($GLOBALS['accordion'] as $tab) {
                if ($counter == 0)
                    $tabs = $tabs . '<h2  class="current first"><span class="icon-plus-sign"></span>' . $tab['title'] . '</h2><div class="pane" style="display:block;">' . $tab['content'] . '</div>';
                else
                     $tabs = $tabs . '<h2><span class="icon-plus-sign"></span>' . $tab['title'] . '</h2><div class="pane" style="display:none">' . $tab['content'] . '</div>';
                $counter++;
            }
            $return = "\n" . '<!-- the accordion tabs --><div class="accordion">' . $tabs . '</div>' . "\n";
        }
        return $return;
}

/**
 * Shortcode: accordion
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_accordion($atts, $content) {
    $atts = shortcode_atts(array('title' => 'Tab %d'), $atts);
    
        $x = $GLOBALS['accordion_count'];
        $GLOBALS['accordion'][$x] = array('title' => sprintf($atts['title'], $GLOBALS['accordion_count']), 'content' => $content);
    
        $GLOBALS['accordion_count']++;
}
/**
 * Shortcode: toggle
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_toggle($atts, $content = null) {
    $atts = shortcode_atts(array('title' => 'Click To Open'), $atts);
    
    
    $data = '<div class="toggle"><h3 class="clearfix"><span class="icon-plus-sign"></span><a href="#">'.$atts['title'].'</a></h3><div class="content">'.do_shortcode($content).'</div></div>';
    
    return $data;
}


/**
 * Shortcode: dropcap
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_dropcap($atts, $content) {
    $return = '<span class="dropcaps">' . $content . '</span>';
    return $return;
}


/**
 * Shortcode: dropcap2
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_dropcap2($atts, $content) {
    $return = '<span class="dropcaps color2">' . $content . '</span>';
    return $return;
}


/**
 * Shortcode: ul
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_ul($atts, $content) {
	$atts = shortcode_atts(array('float' => 'none'), $atts);
	
	if( $atts['float'] == 'left' ){
		$float = 'li_left_flaot';
	
	}elseif( $atts['float'] == 'right'  ){
		$float = 'li_right_flaot';
	
	}else {
		$float = '';
	}
	

    $GLOBALS['ul_count'] = 0;
	unset($GLOBALS['ul']);
    do_shortcode($content);
	$tabs = '';
    if (is_array($GLOBALS['ul'])) {
        foreach ($GLOBALS['ul'] as $tab) {
            $tabs = $tabs .  '<li><span class="'.$tab['icon'].'"></span>' . $tab['content'] . '</li>';
        }
        $return = "\n" . '<ul class="custom_ul ">' . $tabs . '</ul>' . "\n";
    }
    return $return;
}

/**
 * Shortcode: li
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_li($atts, $content) {
    $atts = shortcode_atts(array('icon' => 'phone'), $atts);

    $x = $GLOBALS['ul_count'];
    $GLOBALS['ul'][$x] = array('icon' => sprintf($atts['icon'], $GLOBALS['ul_count']), 'content' => $content);

    $GLOBALS['ul_count']++;
}

/**
 * Shortcode: input
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_input($atts, $content = null) {

    $atts = shortcode_atts(array( 'icon' => 'none',
    	'id'=>'',
        'placeholder' => ''), $atts);

	$data = '<input class="element-block  ' . $atts['icon'] . '" name="' . $atts['id'] . '" id="' . $atts['id'] . '" type="text" placeholder="' . $atts['placeholder'] . '" />';


    return $data;
}

/**
 * Shortcode: is_logged_in
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_is_logged_in($atts, $content = null) {

    $data = '';
    if(is_user_logged_in()){
    	$data = $data . do_shortcode($content);
    }
    return $data;
}

/**
 * Shortcode: is_logged_out
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_is_logged_out($atts, $content = null) {

    $data = '';
    if(!is_user_logged_in()){
    	$data = $data . do_shortcode($content);
    }
    return $data;
}

/**
 * Shortcode: textarea
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_textarea($atts, $content = null) {

    $atts = shortcode_atts(array( 'icon' => 'none message',
    	'id'=>'',
        'placeholder' => ''), $atts);

	$data = '<textarea class="element-block  ' . $atts['icon'] . '" name="' . $atts['id'] . '" id="' . $atts['id'] . '" type="text"  >' . $atts['placeholder'] . '</textarea>';


    return $data;
}


/**
 * Shortcode: button
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_button($atts, $content = null) {

    $atts = shortcode_atts(array( 'color' => 'default',
        'link' => '',
        'text' => '',
        'float' => '',
        'size'=>''), $atts);



    $data = '<a href="' . $atts['link'] . '" class="' . $atts['color'] . ' btn ' . $atts['float'] . ' '.$atts['size'].'">' . $atts['text'] . '</a>';

    return $data;
}

/**
 * Shortcode: button_2
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 
function code125_button_2($atts, $content = null) {

    $atts = shortcode_atts(array( 'color' => 'default',
        'link' => '',
        'text' => '',
        'float' => '',
        'size'=>'',
        'icon'=>'',
        'id'=>''), $atts);
        
	if( !isset($GLOBALS['button_count'])){
		$GLOBALS['button_count'] = 0;
	}
	$GLOBALS['button_count']++;
	
	$count = $GLOBALS['button_count'];
	
	
	$color_1= $atts['color'];
	$color_0 = '#' . hexLighter(substr($atts['color'],1), 50);
	$color_2 = '#' . hexDarker(substr($atts['color'],1), 5);
	$color_3 = '#' . hexDarker(substr($atts['color'],1), 10);
	$color_4 = '#' . hexDarker(substr($atts['color'],1), 20);
	
	$data ='<style>.button_'.$count.'{ background-color: '.$color_1.';
	  background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, '.$color_1.'), color-stop(100%, '.$color_2.'));
	  background-image: -webkit-linear-gradient(top, '.$color_1.', '.$color_2.');
	  background-image: -moz-linear-gradient(top, '.$color_1.', '.$color_2.');
	  background-image: -ms-linear-gradient(top, '.$color_1.', '.$color_2.');
	  background-image: -o-linear-gradient(top, '.$color_1.', '.$color_2.');
	  background-image: linear-gradient(top, '.$color_1.', '.$color_2.');
	  border: 1px solid '.$color_4.';
	  box-shadow: inset 0 1px 0 0 '.$color_0.'; }
	.button_'.$count.':hover{background-color: '.$color_1.';
	background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, '.$color_2.'), color-stop(100%, '.$color_4.'));
	background-image: -webkit-linear-gradient(top, '.$color_2.', '.$color_3.');
	background-image: -moz-linear-gradient(top, '.$color_2.', '.$color_3.');
	background-image: -ms-linear-gradient(top, '.$color_2.', '.$color_3.');
	background-image: -o-linear-gradient(top, '.$color_2.', '.$color_3.');
	background-image: linear-gradient(top, '.$color_2.', '.$color_3.');
	box-shadow: inset 0 1px 0 0 '.$color_0.'; }
	</style>';
	
	
    $data = $data .'<a id="' . $atts['id'] . '" href="' . $atts['link'] . '" class="button  button_'.$count.' ' . $atts['float'] . ' '.$atts['size'].'">' . $atts['text'] . '<span class="'.$atts['icon'].'"></span></a>';

    return $data;
}

/**
 * Shortcode: posts_slider_auto
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_slider_auto($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'order' => '',
        'orderby' => '',
        'style' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
   
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish',
        'ignore_sticky_posts' => 1);


   query_posts($args);
     
     
     $data = '[posts_slider style="'.$atts['style'].'"]';
     
     while (have_posts()) : the_post();
     
			$data = $data . '[posts_slide id="'.get_the_ID().'"]';
			   	
   endwhile;
   
   
   	$data = $data . '[/posts_slider]';					    		
   
    wp_reset_query();
    return do_shortcode($data);
    
}


/**
 * Shortcode: posts
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    if ($atts['paging'] == 'true') {
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    } else {
        $paged = 1;
    }

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'paged' => $paged,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');

	query_posts($args);
   
     
     $counter = 1;
     $data = '';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/blog-style1.php');
   	
   endwhile;
   
   

    
    if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: items
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_items($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';
	
	
	if ($atts['paging'] == 'true') {
	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	} else {
	    $paged = 1;
	}


    if (isset($atts['category'])) {
        $args = array(
            'posts_per_page' => $atts['posts_per_page'],
            'offset' => 0,
            'paged' => $paged,
            'tax_query' => array(
            		array(
            			'taxonomy' => 'item_type',
            			'field' => 'id',
            			'terms' => $atts['category']
            		)
            	),
            'orderby' => $atts['orderby'],
            'order' => $atts['order'],
            'post_type' => 'item',
            'post_status' => 'publish');
    } else {
        $args = array(
            'posts_per_page' => $atts['posts_per_page'],
            'offset' => 0,
            'paged' => $paged,
            'orderby' => $atts['orderby'],
            'order' => $atts['order'],
            'post_type' => 'item',
            'post_status' => 'publish');
    }
    


	query_posts($args);
   
     
     $counter = 1;
     $data = '';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/item-style1.php');
   	
   endwhile;
   
   

    
    if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
    wp_reset_query();
    return $data;
    
}
/**
 * Shortcode: posts_2
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_2($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    if ($atts['paging'] == 'true') {
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    } else {
        $paged = 1;
    }

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'paged' => $paged,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');


   query_posts($args);
     
     
     $counter = 1;
     $data = '';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/blog-style2.php');
   	
   endwhile;
   
   

    
    if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
    wp_reset_query();
    return $data;
    
}
/**
 * Shortcode: items_2
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_items_2($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if ($atts['paging'] == 'true') {
    	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    	} else {
    	    $paged = 1;
    	}
    
    
        if (isset($atts['category'])) {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'tax_query' => array(
                		array(
                			'taxonomy' => 'item_type',
                			'field' => 'id',
                			'terms' => $atts['category']
                		)
                	),
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        } else {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        }


   query_posts($args);
     
     
     $counter = 1;
     $data = '';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/item-style2.php');
   	
   endwhile;
   
   

    
    if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: posts_3
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_3($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    if ($atts['paging'] == 'true') {
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    } else {
        $paged = 1;
    }

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'paged' => $paged,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');


   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-3col" class="clearfix">';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/blog-style3.php');
   	
   endwhile;
   
   $data = $data . '</div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: items_3
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_items_3($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if ($atts['paging'] == 'true') {
    	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    	} else {
    	    $paged = 1;
    	}
    
    
        if (isset($atts['category'])) {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'tax_query' => array(
                		array(
                			'taxonomy' => 'item_type',
                			'field' => 'id',
                			'terms' => $atts['category']
                		)
                	),
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        } else {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        }
    


   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-3col" class="clearfix">';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/item-style3.php');
   	
   endwhile;
   
   $data = $data . '</div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: posts_4
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_4($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    if ($atts['paging'] == 'true') {
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    } else {
        $paged = 1;
    }

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'paged' => $paged,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');


   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-4col" class="clearfix"><div class="row-fluid">';
     
     while (have_posts()) : the_post();
     		$id_link = get_post_thumbnail_id(get_the_ID());
     		
     		$image_url = wp_get_attachment_image_src( $id_link, 'mixed-size-4');
     		 if(is_array($image_url)){
     			$data = $data . '<div class="span3"><div class="float_left">';
				include(TEMPLATEPATH . '/blog-style4.php');
				$data = $data . '</div></div>';
			
				if($counter == 4 || $counter == 8 ){
					$data = $data . '</div><div class="row-fluid">';
				}
			
				$counter++;
			}
   	
   endwhile;
   
   $data = $data . '</div></div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: items_4
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_items_4($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if ($atts['paging'] == 'true') {
    	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    	} else {
    	    $paged = 1;
    	}
    
    
        if (isset($atts['category'])) {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'tax_query' => array(
                		array(
                			'taxonomy' => 'item_type',
                			'field' => 'id',
                			'terms' => $atts['category']
                		)
                	),
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        } else {
            $args = array(
                'posts_per_page' => $atts['posts_per_page'],
                'offset' => 0,
                'paged' => $paged,
                'orderby' => $atts['orderby'],
                'order' => $atts['order'],
                'post_type' => 'item',
                'post_status' => 'publish');
        }


   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-4col" class="clearfix"><div class="row-fluid">';
     
     while (have_posts()) : the_post();
     		$id_link = get_post_thumbnail_id(get_the_ID());
     		
     		$image_url = wp_get_attachment_image_src( $id_link, 'mixed-size-4');
     		 if(is_array($image_url)){
     			$data = $data . '<div class="span3"><div class="float_left">';
				include(TEMPLATEPATH . '/item-style4.php');
				$data = $data . '</div></div>';
			
				if($counter == 4 || $counter == 8 ){
					$data = $data . '</div><div class="row-fluid">';
				}
			
				$counter++;
			}
   	
   endwhile;
   
   $data = $data . '</div></div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}
/**
 * Shortcode: posts_5
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_5($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => '',
        'size' => 'large'), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    if ($atts['paging'] == 'true') {
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    } else {
        $paged = 1;
    }

    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'paged' => $paged,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');


   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-5" class="blog-5 '.$atts['size'].' clearfix">';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/blog-style5.php');
   	
   endwhile;
   
   $data = $data . '</div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: items_5
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_items_5($atts, $content = null) {


    shortcode_atts(array('category' => '',
        'posts_per_page' => '',
        'paging' => '',
        'order' => '',
        'orderby' => '',
        'size' => 'large'), $atts);
        
    if (!isset($atts['posts_per_page']))
        $atts['posts_per_page'] = 5;
    if (!isset($atts['paging']))
        $atts['paging'] = 'false';
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



   if ($atts['paging'] == 'true') {
   	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
   	} else {
   	    $paged = 1;
   	}
   
   
       if (isset($atts['category'])) {
           $args = array(
               'posts_per_page' => $atts['posts_per_page'],
               'offset' => 0,
               'paged' => $paged,
               'tax_query' => array(
               		array(
               			'taxonomy' => 'item_type',
               			'field' => 'id',
               			'terms' => $atts['category']
               		)
               	),
               'orderby' => $atts['orderby'],
               'order' => $atts['order'],
               'post_type' => 'item',
               'post_status' => 'publish');
       } else {
           $args = array(
               'posts_per_page' => $atts['posts_per_page'],
               'offset' => 0,
               'paged' => $paged,
               'orderby' => $atts['orderby'],
               'order' => $atts['order'],
               'post_type' => 'item',
               'post_status' => 'publish');
       }
   
   query_posts($args);
     
     
     $counter = 1;
    $data = '<div id="blog-5" class="blog-5 '.$atts['size'].' clearfix">';
     
     while (have_posts()) : the_post();
     
			include(TEMPLATEPATH . '/item-style5.php');
   	
   endwhile;
   
   $data = $data . '</div><div class="clearfix"></div>';
   
   if ($atts['paging'] == 'true') {
   	       ob_start();
           bones_page_navi();
           $page_navi = ob_get_contents();
           ob_end_clean();
   
           $data = $data . $page_navi;
        
    }
   
   
   
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: category
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => 4,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 '.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3><div class="row-fluid">';
     
     while (have_posts()) : the_post();
     
     				 ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				 $comments_number = ob_get_contents();
     				 ob_end_clean();
     				
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	$data = $data . '<div class="span6 thumb-wrap">';
     		 	if(is_array($image_url)){
     		 	$data = $data . get_thumb_hover(get_the_ID(),'featured-post',ot_get_option( 'hover_view' ));
     		 	}
     		 	$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>';
     		 	
     		 	$data = $data . '</div>';
     		 	
     		 	
     		 
     		 }elseif ($counter_category == 2) {
     		 	$data = $data . '<div class="span6">';
     		      		 	
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 	
     		  }elseif ($counter_category == 4) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div></div></div>';
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: item
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_item($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => ''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => 4,
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 item-cat-'.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3><div class="row-fluid">';
     
     while (have_posts()) : the_post();
     
     				 ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	$data = $data . '<div class="span6 thumb-wrap">';
     		 	if(is_array($image_url)){
     		 	$data = $data . get_thumb_hover(get_the_ID(),'featured-post',ot_get_option( 'hover_view' ));
     		 	}
     		 	$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>';
     		 	
     		 	$data = $data . '</div>';
     		 	
     		 	
     		 
     		 }elseif ($counter_category == 2) {
     		 	$data = $data . '<div class="span6">';
     		      		 	
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 	
     		  }elseif ($counter_category == 4) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div></div></div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_list
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_list($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 '.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(150);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	if(is_array($image_url)){
     		 		$data = $data . '<div class="category-thumb thumb-wrap">';
     		 		if(is_array($image_url)){
     		 		$data = $data . get_thumb_hover(get_the_ID(),'featured-post',ot_get_option( 'hover_view' ));
     		 		}
     		 		$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p></div>';
     		 	}else {
     		 		$data = $data . '<div class="category-thumb"><h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p></div>';
     		 	}
     		 	
     		 	
     		 	
     		 
     		}elseif ($counter_category == $atts['posts_per_page']) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: category_items_list
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_items_list($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
   $args = array(
       'posts_per_page' => $atts['posts_per_page'],
       'offset' => 0,
       'tax_query' => array(
       		array(
       			'taxonomy' => 'item_type',
       			'field' => 'id',
       			'terms' => $cats        		)
       	),
       'orderby' => $atts['orderby'],
       'order' => $atts['order'],
       'post_type' => 'item',
       'post_status' => 'publish');
       
       
	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 item-cat-'.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(150);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				 
     				     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	if(is_array($image_url)){
     		 		$data = $data . '<div class="category-thumb thumb-wrap">';
     		 		if(is_array($image_url)){
     		 		$data = $data . get_thumb_hover(get_the_ID(),'featured-post',ot_get_option( 'hover_view' ));
     		 		}
     		 		$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p></div>';
     		 	}else {
     		 		$data = $data . '<div class="category-thumb"><h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p></div>';
     		 	}
     		 	
     		 	
     		 	
     		 
     		}elseif ($counter_category == $atts['posts_per_page']) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_thumb_list
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_thumb_list($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 '.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(150);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if ($counter_category == $atts['posts_per_page']) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: category_thumb_list_item
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_thumb_list_item($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_1 item-cat-'.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     				 
     		
     				 ob_start();
     				 the_post_thumbnail('featured-post');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(150);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if ($counter_category == $atts['posts_per_page']) {
     		  		if(is_array($image_url)){
     		  		$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  		
     		  		$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  		
     		  		$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  		}else {
     		  			$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  		}
     		  	
     		 }else {
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 }
     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: category_style_5
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_5($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
     $data = '<div class="category_style_5 '.$cat_array->slug.' clearfix" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		     include(TEMPLATEPATH . '/blog-style4.php');
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}

/**
 * Shortcode: category_style_item_5
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_item_5($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
     $data = '<div class="category_style_5 item-cat-'.$cat_array->slug.' clearfix" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		     include(TEMPLATEPATH . '/item-style4.php');
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_6
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_6($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
     $data = '<div class="category_style_6 '.$cat_array->slug.' clearfix" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3><div id="blog-5" class="blog-5 small clearfix">';
     
     while (have_posts()) : the_post();
     
     		     include(TEMPLATEPATH . '/blog-style5.php');
   endwhile;
   
   $data = $data . '</div></div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_item_6
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_item_6($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
     $data = '<div class="category_style_6 item-cat-'.$cat_array->slug.' clearfix" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3><div id="blog-5" class="blog-5 small clearfix">';
     
     while (have_posts()) : the_post();
     
     		     include(TEMPLATEPATH . '/item-style5.php');
   endwhile;
   
   $data = $data . '</div></div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_3
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_3($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';
	if(!isset($atts['posts_per_page'])){
		$atts['posts_per_page'] = 5;
	}


    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_3 '.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     		
     				 ob_start();
     				 the_post_thumbnail('portfolio-3-col');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				
     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				
     				 
     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	$data = $data . '<div class="row-fluid category-thumb">';
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="span6 thumb-wrap">';
     		 	
     		 
     		 	$data = $data . get_thumb_hover(get_the_ID(),'portfolio-3-col',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span6">';
     		 	}else {
     		 		$data = $data . '<div class="span12">';
     		 	}
     		 	$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>';
     		 	
     		 	$data = $data . '</div></div>';
     		 	
     		 	
     		 
     		 }elseif ($counter_category == 2) {
     		 	$data2 = '<div class="row-fluid"><div class="span6">';
     		 	
     		 	
     		 	if(is_array($image_url)){
     		 	$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data2 = $data2 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data2 = $data2 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 	
     		  
     		  }elseif ($counter_category == 3) {
     		  	$data3 = '</div><div class="span6">';
     		  	
     		  	
     		  	if(is_array($image_url)){
     		  	$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  	
     		  	$data3 = $data3 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  	
     		  	$data3 = $data3 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  	}else {
     		  		$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  	}
     		  	
     		  	
     		   
     		   }elseif ($counter_category%2 == 0) {
     		  	
     		  	if(is_array($image_url)){
     		  	$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  	
     		  	$data2 = $data2 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  	
     		  	$data2 = $data2 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  	}else {
     		  		$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  	}
     		  	
     		  	
     		   }elseif ($counter_category%2 == 1) {
     		   	
     		   	if(is_array($image_url)){
     		   	$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		   	
     		   	$data3 = $data3 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		   	
     		   	$data3 = $data3 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		   	}else {
     		   		$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		   	}
     		   	
     		   	
     		   }
     		   
     		  
     		  
     		  
     
   		$counter_category++;
   endwhile;
   if(isset($data3)){
   		$data3 = $data3 . '</div>';
   		
   		$data  = $data . $data2 . $data3;
   }
   
   $data = $data . '</div></div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_item_3
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_item_3($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>'',
        'posts_per_page'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';
	if(!isset($atts['posts_per_page'])){
		$atts['posts_per_page'] = 5;
	}


    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_3 item-cat-'.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     		
     				 ob_start();
     				 the_post_thumbnail('portfolio-3-col');
     				 $the_post_thumbnail = ob_get_contents();
     				 ob_end_clean();
     				 
     				 ob_start();
     				 the_post_thumbnail('gallery-thumb');
     				 $the_post_thumbnail2 = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				
     				
     				
     				 
     				 
     				 $id_link = get_post_thumbnail_id();
     				 
     				 $image_url = wp_get_attachment_image_src( $id_link, "full"); 
     				 
     		 
     		 if($counter_category == 1){
     		 	$data = $data . '<div class="row-fluid category-thumb">';
     		 	if(is_array($image_url)){
     		 	$data = $data . '<div class="span6 thumb-wrap">';
     		 	
     		 
     		 	$data = $data . get_thumb_hover(get_the_ID(),'portfolio-3-col',ot_get_option( 'hover_view' ));
     		 	
     		 	$data = $data . '</div><div class="span6">';
     		 	}else {
     		 		$data = $data . '<div class="span12">';
     		 	}
     		 	$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">'.$the_title.'</a></h2><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>';
     		 	
     		 	$data = $data . '</div></div>';
     		 	
     		 	
     		 
     		 }elseif ($counter_category == 2) {
     		 	$data2 = '<div class="row-fluid"><div class="span6">';
     		 	
     		 	
     		 	if(is_array($image_url)){
     		 	$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		 	
     		 	$data2 = $data2 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		 	
     		 	$data2 = $data2 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		 	}else {
     		 		$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		 	}
     		 	
     		 	
     		  
     		  }elseif ($counter_category == 3) {
     		  	$data3 = '</div><div class="span6">';
     		  	
     		  	
     		  	if(is_array($image_url)){
     		  	$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  	
     		  	$data3 = $data3 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  	
     		  	$data3 = $data3 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  	}else {
     		  		$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  	}
     		  	
     		  	
     		   
     		   }elseif ($counter_category%2 == 0) {
     		  	
     		  	if(is_array($image_url)){
     		  	$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		  	
     		  	$data2 = $data2 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		  	
     		  	$data2 = $data2 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		  	}else {
     		  		$data2 = $data2 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		  	}
     		  	
     		  	
     		   }elseif ($counter_category%2 == 1) {
     		   	
     		   	if(is_array($image_url)){
     		   	$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
     		   	
     		   	$data3 = $data3 . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
     		   	
     		   	$data3 = $data3 . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
     		   	}else {
     		   		$data3 = $data3 . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';	
     		   	}
     		   	
     		   	
     		   }
     		   
     		  
     		  
     		  
     
   		$counter_category++;
   endwhile;
   if(isset($data3)){
   		$data3 = $data3 . '</div>';
   		
   		$data  = $data . $data2 . $data3;
   }
   
   $data = $data . '</div></div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_4
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_4($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => 5,
        'cat' => $cats,
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'post',
        'post_status' => 'publish');
	$cat_array = get_category($cats);

   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_4 clearfix '.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_' . $cats ).'"></span> <a href="'.get_category_link($cats).'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     		
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				$id_link = get_post_thumbnail_id(get_the_ID());
     				
     				$image_url = wp_get_attachment_image_src( $id_link, 'mixed-size-4');
     				
     				$image_url2 = wp_get_attachment_image_src( $id_link, 'mixed-size-2');
     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				
     				 
     				 
     				 $id_link = get_post_thumbnail_id();
     				  
     				 
     		 
     		 if($counter_category == 1){
     		 	if(is_array($image_url)){
     		 		$data = $data .'<div class="mini-post wide-thumb">';
     		 		$category = get_the_category(get_the_ID()); 
     		 		$data = $data .'<div class="dark-mini-wrap thumb-wrap '. $category[0]->slug .'"><a  href="'. get_permalink( get_the_ID() ).'"><img src="'. $image_url2[0] .'" alt="" /></a><p class="dark-mini"><a  href="'. get_permalink( get_the_ID() ).'">'. $the_title .'</a></p></div></div>';
     		 
     		 	}
     		 	
     		 	
     		 
     		 }else{
     		 	if(is_array($image_url)){
     		 			$data = $data .'<div class="mini-post mini-post'.$counter_category.'">';
     		 			$category = get_the_category(get_the_ID()); 
     		 			$data = $data .'<div class="dark-mini-wrap thumb-wrap '. $category[0]->slug .'"><a  href="'. get_permalink( get_the_ID() ).'"><img src="'. $image_url[0] .'" alt="" /></a><p class="dark-mini"><a  href="'. get_permalink( get_the_ID() ).'">'. $the_title .'</a></p></div></div>';
     		 	
     		 		}
     		 	
     		  
     		  }     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: category_style_item_4
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
*/
function code125_category_style_item_4($atts, $content = null) {

 shortcode_atts(array('category' => '',
        'order' => '',
        'orderby' => '',
        'icon'=>''), $atts);
        
    if (!isset($atts['order']))
        $atts['order'] = 'DESC';
    if (!isset($atts['orderby']))
        $atts['orderby'] = 'post_date';



    if (isset($atts['category'])) {
        $cats = $atts['category']; //explode(",", $atts['category']);
    } else {
        $cats = '';
    }
    
    $args = array(
        'posts_per_page' => $atts['posts_per_page'],
        'offset' => 0,
        'tax_query' => array(
        		array(
        			'taxonomy' => 'item_type',
        			'field' => 'id',
        			'terms' => $cats        		)
        	),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_type' => 'item',
        'post_status' => 'publish');
        
        
    	$cat_array = get_term($cats,'item_type');
		$category = get_term($cats,'item_type');
   query_posts($args);
     
     
      $counter_category = (int) 1;
     $data = '<div class="category_style_4 clearfix item-cat-'.$cat_array->slug.'" ><h3 class="title "><span class="'.get_option( 'category_icon_item_' . $cats ).'"></span> <a href="'.get_term_link(intval($cats),'item_type').'">'.$cat_array->name.'</a><span class="arrow"></span><a class="rss-icon icon-rss" href="'.home_url(). '/?feed=rss2&cat='.$cats.'"></a></h3>';
     
     while (have_posts()) : the_post();
     
     		ob_start();
     				 the_permalink();
     				 $permalink = ob_get_contents();
     				 ob_end_clean();
     		
     				 ob_start();
     				 the_title();
     				 $the_title = ob_get_contents();
     				 ob_end_clean();
     		
     		
     		
     				 ob_start();
     				 the_excerpt_max_charlength(160);
     				 $the_excerpt_max_charlength = ob_get_contents();
     				 ob_end_clean();
     				
     				$id_link = get_post_thumbnail_id(get_the_ID());
     				
     				$image_url = wp_get_attachment_image_src( $id_link, 'mixed-size-4');
     				
     				$image_url2 = wp_get_attachment_image_src( $id_link, 'mixed-size-2');
     				 
     				 ob_start();
     				 comments_number('0','1','%');
     				$comments_number = ob_get_contents();
     				ob_end_clean();
     				
     				
     				 
     				 
     				 $id_link = get_post_thumbnail_id();
     				  
     				 
     		 
     		 if($counter_category == 1){
     		 	if(is_array($image_url)){
     		 		$data = $data .'<div class="mini-post wide-thumb">';
     		 		
     		 		$data = $data .'<div class="dark-mini-wrap thumb-wrap '. $category->slug .'"><a  href="'. get_permalink( get_the_ID() ).'"><img src="'. $image_url2[0] .'" alt="" /></a><p class="dark-mini"><a  href="'. get_permalink( get_the_ID() ).'">'. $the_title .'</a></p></div></div>';
     		 
     		 	}
     		 	
     		 	
     		 
     		 }else{
     		 	if(is_array($image_url)){
     		 			$data = $data .'<div class="mini-post mini-post'.$counter_category.'">';
     		 			$data = $data .'<div class="dark-mini-wrap thumb-wrap '. $category->slug .'"><a  href="'. get_permalink( get_the_ID() ).'"><img src="'. $image_url[0] .'" alt="" /></a><p class="dark-mini"><a  href="'. get_permalink( get_the_ID() ).'">'. $the_title .'</a></p></div></div>';
     		 	
     		 		}
     		 	
     		  
     		  }     
   		$counter_category++;
   endwhile;
   
   $data = $data . '</div>';
    wp_reset_query();
    return $data;
    
} 

 
/**
 * Shortcode: news_in_photos
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_news_in_photos($atts,$content = null) {

$atts = shortcode_atts(
	array('orderby'=> 'date', 
		  'order'=>'DESC',
		  'numberposts' =>'Number Of News To Show',
		  'category' => ''), $atts);

if (isset($atts['category'])) {
    $cats = $atts['category']; //explode(",", $atts['category']);
} else {
    $cats = '';
}
global $post;

$args = array(
    'posts_per_page' => $atts['numberposts'],
    'cat' => $cats,
    'orderby' => $atts['orderby'],
    'order' => $atts['order'],
    'post_type' => 'post',
    'post_status' => 'publish',         // posts only
    'meta_query'=>'_thumbnail_id', // with thumbnail
    'exclude'=>$post->ID );


query_posts($args);
  
  
  $counter = 1;
  $data = '<div class="news_in_photo clearfix">';
  
  while (have_posts()) : the_post();
  
  
  
          ob_start();
          the_post_thumbnail('mixed-size-4');
          $the_post_thumbnail = ob_get_contents();
          ob_end_clean();
  			
  			
  		$id_link = get_post_thumbnail_id();
  		
  		$image_url = wp_get_attachment_image_src( $id_link, "full"); 
  			
  			if( $the_post_thumbnail!='' ){
  		
           		$data = $data . '<div class="news-photo thumb-wrap thumb'.$counter.'">';
           
           		$data = $data . get_thumb_hover(get_the_ID(),'mixed-size-4',ot_get_option( 'hover_view' ));
           
           		$data = $data . '</div>';   
           		
           		$counter++;     
           }
           
          if($counter ==$atts['numberposts'] ){
          	break;
          }
          
  endwhile;
  	$data = $data . '</div>'; 
          
          wp_reset_query();
          return $data;
	
}


/**
 * Shortcode: review_box
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_review_box($atts,$content = null) {

	global $post;
	$data = '<div class="review-wrap">' . get_reviewbox($post->ID) . '</div>';
    return $data;
	
}

/**
 * Shortcode: author_box
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_author_box($atts,$content = null) {
	$atts = shortcode_atts(
		array('id'=> ''), $atts);
	
	
	$user = get_userdata($atts['id']);
	
	$facebook_user = get_the_author_meta( 'facebook', $atts['id']);
	$twitter_user = get_the_author_meta( 'twitter', $atts['id']);
	$position_user = get_the_author_meta( 'position', $atts['id']);
	
	$google_plus_user = get_the_author_meta( 'google_plus', $atts['id']);
	$behance_user = get_the_author_meta( 'behance', $atts['id']);
	$dribble_user = get_the_author_meta( 'dribble', $atts['id']);
	
	$avatar = get_avatar( $atts['id'], '100', '', '<span class="icon-user"></span>' );
	
	$data =  '<div class="textwidget author_widget clearfix"><div class="row-fluid"><div class="span4"><a href="'.  get_author_posts_url($atts['id']) .'">'. $avatar .'</a></div><div class="span8"><h3><a href="'. get_author_posts_url($atts['id']).'">'. $user->display_name .'</a></h3><p>'. $position_user .'</p><ul class="social-icons clearfix">';
	
	if($facebook_user != ''){
		$data = $data . '<li><a href="http://www.facebook.com/people/@/'.$facebook_user.'" class="icon-facebook"></a></li>';
	}
	
	if($twitter_user != ''){
		$data = $data . '<li><a href="http://www.twitter.com/'.$twitter_user.'" class="icon-twitter"></a></li>';
	}
	
	if($google_plus_user != ''){
		$data = $data . '<li><a href="'.$google_plus_user.'" class="icon-google-plus"></a></li>';
	}
	
	if($behance_user != ''){
		$data = $data . '<li><a href="'.$behance_user.'" class="code125-social-behance"></a></li>';
	}
	
	if($dribble_user != ''){
		$data = $data . '<li><a href="'.$dribble_user.'" class="code125-social-dribble"></a></li>';
	}
	
	if($user->user_email != ''){
		$data = $data . '<li><a href="mailto:'.$user->user_email.'" class="icon-envelope-alt"></a></li>';
	}
	
	if($user->user_url != ''){
		$data = $data . '<li><a href="'.$user->user_url.'" class="icon-link"></a></li>';
	}
	
	$data = $data . '</li></ul></div></div>';
	
	$data = $data . '<p class="author_description"><span class="arrow-up"></span>'.$user->user_description.'</p>';
	
	$data = $data . '</div>';
	
	return $data;
	
}


/**
 * Shortcode: latest_news
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_latest_news($atts, $content = null) {


 
 $atts = shortcode_atts(
 	array('orderby'=> 'date', 
 		  'order'=>'DESC',
 		  'numberposts' =>'3',
 		  'category' => ''), $atts);
 
 if (isset($atts['category'])) {
     $cats = $atts['category']; //explode(",", $atts['category']);
 } else {
     $cats = '';
 }
 
 global $post;
  
 $args = array(
     'posts_per_page' => $atts['numberposts'],
     'cat' => $cats,
     'orderby' => $atts['orderby'],
     'order' => $atts['order'],
     'post_type' => 'post',
     'post_status' => 'publish',         // posts only
     'meta_query'=>'_thumbnail_id', // with thumbnail
     'exclude'=>$post->ID,
     'post__not_in' => get_option( 'sticky_posts' ) );
 
 
 query_posts($args);
  
 
  
 $data = '<div class="latest_news">';
  
  while (have_posts()) : the_post();
  
          ob_start();
          		 the_permalink();
          		 $permalink = ob_get_contents();
          		 ob_end_clean();
          
          		 ob_start();
          		 the_title();
          		 $the_title = ob_get_contents();
          		 ob_end_clean();
          
          		           
          		
          		 
          		 ob_start();
          		 the_post_thumbnail('gallery-thumb');
          		 $the_post_thumbnail2 = ob_get_contents();
          		 ob_end_clean();
          
          		 ob_start();
          		 the_excerpt_max_charlength(160);
          		 $the_excerpt_max_charlength = ob_get_contents();
          		 ob_end_clean();
          		
          		          		 
          		 ob_start();
          		 comments_number('0','1','%');
          		$comments_number = ob_get_contents();
          		ob_end_clean();
          		
          		
          		 
          		 $id_link = get_post_thumbnail_id();
          		 
          		 $image_url = wp_get_attachment_image_src( $id_link, "full");          
          
          
           if($the_post_thumbnail2 !=''){
          $data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
         
          $data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
          
          $data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
          }else {
          		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
          }
           
endwhile;

 $data = $data . '</div>';
wp_reset_query();

return $data;

}


/**
 * Shortcode: latest_items
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_latest_items($atts, $content = null) {


 
 $atts = shortcode_atts(
 	array('orderby'=> 'date', 
 		  'order'=>'DESC',
 		  'numberposts' =>'3',
 		  'category' => ''), $atts);
 
 
  global $post;  
 if (isset($atts['category']) && $atts['category']!='') {
     $args = array(
         'posts_per_page' => $atts['numberposts'],
         'tax_query' => array(
         		array(
         			'taxonomy' => 'item_type',
         			'field' => 'id',
         			'terms' => $atts['category']
         		)
         	),
         'orderby' => $atts['orderby'],
         'order' => $atts['order'],
         'post_type' => 'item');
 } else {
     $args = array(
         'posts_per_page' => $atts['numberposts'],
         'orderby' => $atts['orderby'],
         'order' => $atts['order'],
         'post_type' => 'item');
 }
 
 
 
 query_posts($args);
  
 
  
 $data = '<div class="latest_news">';
  
  while (have_posts()) : the_post();
  
          ob_start();
          		 the_permalink();
          		 $permalink = ob_get_contents();
          		 ob_end_clean();
          
          		 ob_start();
          		 the_title();
          		 $the_title = ob_get_contents();
          		 ob_end_clean();
          
          		           
          		
          		 
          		 ob_start();
          		 the_post_thumbnail('gallery-thumb');
          		 $the_post_thumbnail2 = ob_get_contents();
          		 ob_end_clean();
          
          		 ob_start();
          		 the_excerpt_max_charlength(160);
          		 $the_excerpt_max_charlength = ob_get_contents();
          		 ob_end_clean();
          		
          		    
          		
          		
          		 
          		 $id_link = get_post_thumbnail_id();
          		 
          		 $image_url = wp_get_attachment_image_src( $id_link, "full");          
          
          
           if($the_post_thumbnail2 !=''){
          $data = $data . '<div class="row-fluid category-thumb"><div class="span4 thumb-wrap">';
         
          $data = $data . get_thumb_hover(get_the_ID(),'gallery-thumb',ot_get_option( 'hover_view' ));
          
          $data = $data . '</div><div class="span8"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
          }else {
          		$data = $data . '<div class="row-fluid category-thumb"><div class="span12"><a class="post_title_thumb title" href="'.$permalink.'">'.$the_title.'</a><div class="clearfix"></div><ul class="meta-entry clearfix"><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul></div></div>';
          }
           
endwhile;

 $data = $data . '</div>';
wp_reset_query();

return $data;

}

/**
 * Shortcode: 5col_posts_fullwidth
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_5col_posts_fullwidth($atts, $content = null){

global $post;
$atts = shortcode_atts(
	array('type' => 'portfolio',
		  'orderby'=> 'date', 
		  'order'=>'DESC',
		  'title' =>'Latest Projects' ), $atts);


    $args = array(
    	'posts_per_page' => 5, /* you can change this to show more */
    	'post__not_in' => array($post->ID),
    	'post_type' => array( $atts['type'] ),
    	'order'=>$atts['order'],
    	'orderby' => $atts['orderby'] 
 	);
 	
 	$data ='<div class="shortcode_4col_posts shortcode_5col_posts" id="shortcode_4col_posts"><h3 class="title">'.$atts['title'].'<span class="arrow"></span></h3>';
 	
 	
 	$data = $data . '<div class="5cols_anmi_fullwidth"><ul class="slides_5col col_3_4">';
    $counter = 0;
     query_posts($args);
     if (have_posts()) : while (have_posts()) : the_post();
     
     ob_start();
     the_permalink();
     $permalink = ob_get_contents();
     ob_end_clean();
       
     ob_start();
     the_title();
     $the_title = ob_get_contents();
     ob_end_clean();
               
       
               ob_start();
               the_post_thumbnail('featured-post');
               $the_post_thumbnail = ob_get_contents();
               ob_end_clean();
       
       
              
     		  ob_start();
     		  the_excerpt_max_charlength(50);
     		  $the_excerpt_max_charlength = ob_get_contents();
     		  ob_end_clean();   
     	
     	
     	$id_link = get_post_thumbnail_id();
     	
     	$image_url = wp_get_attachment_image_src( $id_link, "full"); 
    	
    	if($the_post_thumbnail != ''){
    	
    	$data = $data . '<li><a class="data-original" href="'. $permalink .'" >' . get_the_title()  .'</a>'. $the_post_thumbnail.'</li>';
    	$counter++;
    	}
    	
    	if($counter == 10){
    		break;
    	}
    
    endwhile;
    endif;
   $data = $data . '</ul></div></div>';

wp_reset_query();

return $data;

}



/**
 * Shortcode: 4cols_posts
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_4col_posts($atts, $content = null){

global $post;
$atts = shortcode_atts(
	array('type' => 'portfolio',
		  'orderby'=> 'date', 
		  'order'=>'DESC',
		  'title' =>'Latest Projects' ), $atts);


    $args = array(
    	'posts_per_page' => 8, /* you can change this to show more */
    	'post__not_in' => array($post->ID),
    	'post_type' => array( $atts['type'] ),
    	'order'=>$atts['order'],
    	'orderby' => $atts['orderby'] 
 	);
 	
 	$data ='<div class="shortcode_4col_posts " id="shortcode_4col_posts"><h3 class="title">'.$atts['title'].'<span class="arrow"></span></h3>';
 	
 	
 	$data = $data . '<div class="4cols_anmi"><ul class="slides_4col col_3_4">';
    $counter = 0;
     query_posts($args);
     if (have_posts()) : while (have_posts()) : the_post();
     
     ob_start();
     the_permalink();
     $permalink = ob_get_contents();
     ob_end_clean();
       
     ob_start();
     the_title();
     $the_title = ob_get_contents();
     ob_end_clean();
               
       
               ob_start();
               the_post_thumbnail('slider-thumb');
               $the_post_thumbnail = ob_get_contents();
               ob_end_clean();
       
       
              
     		  ob_start();
     		  the_excerpt_max_charlength(50);
     		  $the_excerpt_max_charlength = ob_get_contents();
     		  ob_end_clean();   
     	
     	
     	$id_link = get_post_thumbnail_id();
     	
     	$image_url = wp_get_attachment_image_src( $id_link, "full"); 
    
    	if($the_post_thumbnail != ''){
    	
    	$data = $data . '<li><a class="data-original" href="'. $permalink .'" >' . get_the_title()  .'</a>'. $the_post_thumbnail.'</li>';
    	$counter++;
    	}
    	
    	if($counter == 8){
    		break;
    	}
    
    endwhile;
    endif;
   $data = $data . '</ul></div></div>';

wp_reset_query();

return $data;

}



/**
 * Shortcode: latest_posts
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_latest_posts($atts, $content = null) {


    shortcode_atts(array('title' => ''), $atts);
 
$data = '<section id="lastestfromblog" class="container clearfix"><h2 class="titles">'.$atts['title'].'</h2><div class="es-carousel-wrapper clearfix"><div class="es-carousel"><ul>';
      
   
    $args = array(
           'posts_per_page' => 8,
           'post_type' => 'post',
           'post_status' => 'publish');
   
   
      query_posts($args);
        
        
        
        while (have_posts()) : the_post();
        
                ob_start();
                the_permalink();
                $permalink = ob_get_contents();
                ob_end_clean();
        
                ob_start();
                the_title();
                $the_title = ob_get_contents();
                ob_end_clean();
        
                        		
        				ob_start();
        				the_author_posts_link();
        				$the_author_posts_link = ob_get_contents();
        				ob_end_clean();
        
                ob_start();
                the_title_attribute();
                $the_title_attribute = ob_get_contents();
                ob_end_clean();
        
                ob_start();
                the_post_thumbnail('featured-post');
                $the_post_thumbnail = ob_get_contents();
                ob_end_clean();
        
                ob_start();
                the_excerpt_max_charlength(60);
                $the_excerpt_max_charlength = ob_get_contents();
                ob_end_clean();
        
                        
                ob_start();
                comments_number(__('0 Comments','code125'),__('1 Comment','code125'),__('% Comments','code125') );
        		$comments_number = ob_get_contents();
        		ob_end_clean();
        		
        	
   
      
 $data = $data . '<li><a href="'.$permalink.'">'.$the_post_thumbnail.'</a><a href="'.$permalink.'"><h3>'.$the_title.'</h3></a><span class="deatils">'.$the_excerpt_max_charlength.' '.__('by','code125').' '.$the_author_posts_link.'</span><span class="date">'.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</span><span class="comment">'.$comments_number.'</span></li>';
        
        
    endwhile;
        
    $data =  $data .'</ul></div></div></section>';

    wp_reset_query();
    return $data;
    
}


/**
 * Shortcode: categories
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_categories($atts, $content = null) {
    $atts = shortcode_atts(array('type' => 'post'), $atts);
    
        	$args = array(
    		'show_option_all'    => '',
    		'orderby'            => 'name',
    		'order'              => 'ASC',
    		'style'              => 'list',
    		'show_count'         => 0,
    		'hide_empty'         => 1,
    		'use_desc_for_title' => 1,
    		'child_of'           => 0,
    		'feed'               => '',
    		'feed_type'          => '',
    		'feed_image'         => '',
    		'exclude'            => '',
    		'exclude_tree'       => '',
    		'include'            => '',
    		'hierarchical'       => 1,
    		'title_li'           => '',
    		'show_option_none'   => 'No categories',
    		'number'             => null,
    		'echo'               => 1,
    		'depth'              => 0,
    		'current_category'   => 0,
    		'pad_counts'         => 0,
    		'walker'             => null
    	);
    	ob_start();
    	wp_list_categories($args);
    	$wp_list_categories = ob_get_contents();
    	ob_end_clean();
    
    return '<ul class="categories_list">' . $wp_list_categories . '</ul>';
}


/**
 * Shortcode: authors
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_authors($atts, $content = null) {
    	ob_start();
    	wp_list_authors();
    	$wp_list_authors = ob_get_contents();
    	ob_end_clean();
    
    return '<ul class="authors_list">' . $wp_list_authors . '</ul>';
}
/**
 * Shortcode: comments
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_comments($atts, $content = null) {
    	
    	
    	$args = array(
    		'status' => 'approve',
    		'number' => '3',
    		'post_type' => 'post'
    	);
    	$comments = get_comments($args);
    	
    	$data ='';
    	foreach($comments as $comment) :
    		
    		$data = $data .  '<li class="clearfix">';
    		$data = $data .  get_avatar($comment->user_id);
    		$data = $data . '<a href="'.get_permalink($comment->comment_post_ID).'">' . substr($comment->comment_content, 0, 80). '</a>';
    		$data = $data .  '</li>';
    	endforeach;
    
    return '<ul class="comments_list">' . $data . '</ul>';
}

/**
 * Shortcode: posts_list
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_posts_list($atts, $content = null) {
    	$args = array( 'numberposts' => 7 );
    	$myposts = get_posts( $args );
    	$data = '';
    	foreach( $myposts as $post2 ) {
    		if( ot_get_option( 'rtl' ) == 'yes' || is_rtl() ){ 
    			$data = $data .'<li><a class="icon-circle-arrow-left" href="'. get_permalink( $post2->ID ).'"> '. $post2->post_title.'</a></li>';
    		}else {
    			$data = $data .'<li><a class="icon-circle-arrow-right" href="'. get_permalink( $post2->ID ).'"> '. $post2->post_title.'</a></li>';
    		}
    	} 
    	
    	
    
    return '<ul class="posts_list">' . $data . '</ul>';
}


 

/**
 * Shortcode: title
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_title($atts, $content = null) {
    $atts = shortcode_atts(array('title' => '','icon'=>''), $atts);
    if($atts['icon'] !='' && $atts['icon']!='none'){
    	$icon = '<span class="title-icon '.$atts['icon'].'"></span>';
    }else {
    	$icon = '';
    }
    return '<h3 class="title">' . $atts['title'] . $icon . '<span class="arrow"></span></h3>';
}



/**
 * Shortcode: ad_728x90
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_ad_728x90($atts, $content = null) {
    $atts = shortcode_atts(array('title' => ''), $atts);
   return '<div class="ad_728x90">' . html_entity_decode($content). '</div>';
}

/**
 * Shortcode: ad_468x60
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_ad_468x60($atts, $content = null) {
    $atts = shortcode_atts(array('title' => ''), $atts);
   return '<div class="ad_468x60">' . html_entity_decode($content). '</div>';
}

/**
 * Shortcode: ad_300x250
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_ad_300x250($atts, $content = null) {
    $atts = shortcode_atts(array('title' => ''), $atts);
   return '<div class="ad_300x250">' . html_entity_decode($content). '</div>';
}



/**
 * Shortcode: sidebar
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_sidebar($atts, $content = null) {
    $atts = shortcode_atts(array('slug' => ''), $atts);
    
    ob_start();
    dynamic_sidebar($atts['slug']);
    $sidebar = ob_get_contents();
    ob_end_clean();
    
     
    
    return '<div class="sidebar  clearfix" role="complementary">'.$sidebar.'</div>';
}



/**
 * Shortcode: slider
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_slider($atts, $content) {

    $GLOBALS['slides_count'] = 0;
    unset($GLOBALS['slide']);

    do_shortcode($content);
    $counter =1;
    if (is_array($GLOBALS['slide'])) {
        
        
        
        $counter = 0;
        $tabs = '';
        
        foreach ($GLOBALS['slide'] as $tab) {
        	query_posts('p=' . $tab['id'] . '&post_type=slides');
        	while (have_posts()) : the_post();
        		$meta_values = get_post_custom(get_the_ID());
        		
        		if( $meta_values['meta_slide_type'][0] == "type_1"){
        			
        			ob_start();
        					the_permalink();
        					 $permalink = ob_get_contents();
        					 ob_end_clean();
        			
        					 ob_start();
        					 the_title();
        					 $the_title = ob_get_contents();
        					 ob_end_clean();
        			
        					 $slider_size = ot_get_option('slider_size');
        					 
        					if($slider_size != '590'){
        					 ob_start();
        					 the_post_thumbnail('blog-post-thumb');
        					 $the_post_thumbnail = ob_get_contents();
        					 ob_end_clean();
        					 
        					 }else {
        					 	ob_start();
        					 	the_post_thumbnail('blog-slide-small');
        					 	$the_post_thumbnail = ob_get_contents();
        					 	ob_end_clean();
        					 }
        			
        			
        			
        			$slide = '<li>'.$the_post_thumbnail.'<div class="width_50_right hide"><a href="'.$permalink.'" class="author">'.$the_title.'</a><div class="slide_rest hide"><p>'.get_the_content().'</p>'.do_shortcode('[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" icon="icon-circle-arrow-right" text="'.__('Read More','code125').'" link="'.$meta_values['slides_readmore'][0].'"]').'</div></div></li>';
        			
        			
        			
        			
        			        			
        			$tabs = $tabs . $slide;
        		
        		}elseif ($meta_values['meta_slide_type'][0] == "type_2" ) {
        			
        			
        			if($meta_values['meta_video_type'][0] == 'vimeo'){
        					$video = do_shortcode(' [vimeo clip_id="'.$meta_values['meta_slide_video_link'][0].'" width="100%" height="398"] ');
        			}elseif ($meta_values['meta_video_type'][0] == 'youtube') {
        					$video =  do_shortcode(' [youtube id="'.$meta_values['meta_slide_video_link'][0].'" width="100%" height="398"] ');
        			}elseif ($meta_values['meta_video_type'][0] == 'dailymotion') {
        					$video = do_shortcode(' [dailymotion id="'.$meta_values['meta_slide_video_link'][0].'" width="100%" height="398"] ');
        			}
        			
        			$slide = '<li>'.$video.'</li>';
        			
        			
        			
        			$tabs = $tabs . $slide;
        			
        		}elseif ($meta_values['meta_slide_type'][0] == "type_3" ) {
        			
        			
        			
        			query_posts('p=' . $meta_values['meta_slide_post'][0] . '&post_type=post');
        			while (have_posts()) : the_post();
        						ob_start();
        						the_permalink();
        						 $permalink = ob_get_contents();
        						 ob_end_clean();
        				
        						 ob_start();
        						 the_title();
        						 $the_title = ob_get_contents();
        						 ob_end_clean();
        				
        						
        								ob_start();
        								the_author_posts_link();
        								$the_author_posts_link = ob_get_contents();
        								ob_end_clean();
        				
        						$slider_size = ot_get_option('slider_size');
        						 
        						if($slider_size != '590'){
        						 ob_start();
        						 the_post_thumbnail('blog-post-thumb');
        						 $the_post_thumbnail = ob_get_contents();
        						 ob_end_clean();
        						 
        						 }else {
        						 	ob_start();
        						 	the_post_thumbnail('blog-slide-small');
        						 	$the_post_thumbnail = ob_get_contents();
        						 	ob_end_clean();
        						 }
        				
        						 ob_start();
        						 the_excerpt_max_charlength(100);
        						 $the_excerpt_max_charlength = ob_get_contents();
        						 ob_end_clean();
        						
        						
        						
        						
        						 ob_start();
        						 the_category(' - ');
        						 $cat_echo_p = ob_get_contents();
        						 ob_end_clean();
        						 
        				$slide = '<li>'.$the_post_thumbnail.'<div class="width_50_right hide"><a href="'.$permalink.'" class="author">'.$the_title.'</a><div class="slide_rest hide"><div class="row-fluid"><div class="span6"><p class="thumb-cat-3"><span class="icon-tag"> </span> '.$cat_echo_p.'</p></div><div class="span6 thumb-like">'.getPostLikeLink(get_the_ID()).'</div></div>'.do_shortcode('[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" icon="icon-circle-arrow-right" text="'.__('Read More','code125').'" link="'.$permalink.'"]').'</div></div></li>';
        				
        				
        				
        				
        			endwhile;
        			wp_reset_query();
        				
        			
        			
        			
        			
        			
        			$tabs = $tabs . $slide;
        			
        			
        		}
        	
        	endwhile;
        	wp_reset_query();
        	$counter++;
        }
        $return = "\n" . '<div class="flexslider features clearfix"><ul class="slides clearfix">' .  $tabs . "\n" . '</ul></div>';
        
    }
    
    return $return;
}


/**
 * Shortcode: slide
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_slide($atts, $content) {
	
	$atts = shortcode_atts(array('id' => ''), $atts);
	
    $x = $GLOBALS['slides_count'];
    $GLOBALS['slide'][$x] = array('id' => $atts['id']);

    $GLOBALS['slides_count']++;
}

/**
 * Shortcode: flexslider
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_flexslider($atts, $content) {

    $GLOBALS['flexslider_count'] = 0;
   unset($GLOBALS['flexslider']);

    do_shortcode($content);
    if (is_array($GLOBALS['flexslider'])) {
        $tabs = '';
        foreach ($GLOBALS['flexslider'] as $tab) {
        	$tabs = $tabs . '<li>'.do_shortcode($tab['content']).'</li>';
        }
        $return = "\n" . '<div class="flexslider features clearfix"><ul class="slides clearfix">' .  $tabs . "\n" . '</ul></div>';
        
    }
    
     
    return $return;
}


/**
 * Shortcode: flexslider_slide
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_flexslider_slide($atts, $content) {
	
    $x = $GLOBALS['flexslider_count'];
    $GLOBALS['flexslider'][$x] = array('content' => $content);

    $GLOBALS['flexslider_count']++;
}



/**
 * Shortcode: posts_slider
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_slider($atts, $content) {
	$atts = shortcode_atts(array('style' => ''), $atts);
	
    $GLOBALS['posts_slider_count'] = 0;
   unset($GLOBALS['posts_slider']);
	
	$tabs = '';
    do_shortcode($content);
    if (is_array($GLOBALS['posts_slider'])) {
        foreach ($GLOBALS['posts_slider'] as $tab) {
        	$type = get_post_type($tab['id']);
        	if($type == 'post'){
        		query_posts('p=' . $tab['id'] . '&post_type=post');
        	}else {
        		query_posts('p=' . $tab['id'] . '&post_type=item');
        	}
        	
        	
        	while (have_posts()) : the_post();
        				ob_start();
        				the_permalink();
        				 $permalink = ob_get_contents();
        				 ob_end_clean();
        		
        				 ob_start();
        				 the_title();
        				 $the_title = ob_get_contents();
        				 ob_end_clean();
        		
        				        		
        				 $slider_size = ot_get_option('slider_size');
        				  
        				 if($slider_size != '590'){
        				  ob_start();
        				  the_post_thumbnail('blog-post-thumb');
        				  $the_post_thumbnail = ob_get_contents();
        				  ob_end_clean();
        				  
        				  }else {
        				  	ob_start();
        				  	the_post_thumbnail('blog-slide-small');
        				  	$the_post_thumbnail = ob_get_contents();
        				  	ob_end_clean();
        				  }
        		
        				 ob_start();
        				 the_excerpt_max_charlength(100);
        				 $the_excerpt_max_charlength = ob_get_contents();
        				 ob_end_clean();
        				if($type =='post'){
        				ob_start();
        				 comments_number( '0' , '1' , '%' );
        				$comments_number = ob_get_contents();
        				ob_end_clean();
        				
        				
        				
        				
        				 ob_start();
        				 the_category(' - ');
        				 $cat_echo_p = ob_get_contents();
        				 ob_end_clean();
        				}else {
        					$comments_number = '';
        					$cat_echo_p = '';
        					
        					ob_start();
        					the_author_posts_link();
        					$the_author_posts_link = ob_get_contents();
        					ob_end_clean();
        				}
        				 if($the_post_thumbnail!=''){
        				 if($atts['style'] == 'title'){
        				 		$slide = '<li>'.$the_post_thumbnail.'<div class="width_50_right bottom hide"><a href="'.$permalink.'" class="author">'.$the_title.'</a></div></li>';
        				 
        				 }else{
        		$slide = '<li>'.$the_post_thumbnail.'<div class="width_50_right hide"><a href="'.$permalink.'" class="author">'.$the_title.'</a><div class="slide_rest hide"><div class="row-fluid"><div class="span12"><ul class="meta-entry">';
        		if($type =='post'){
        		$slide = $slide .'<li><p><span class="icon-tag"> </span> '.$cat_echo_p.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .', '. get_the_time('Y').'</p></li><li><p><span class="icon-comment"> </span> '.$comments_number.'</p></li>';
        		}else {
        			$slide = $slide .'<li><p><span class="icon-user"> </span> '.$the_author_posts_link.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('j') .' '. get_the_time('M') .', '. get_the_time('Y').'</p></li>';
        		}
        		$slide = $slide .'<li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div></div></div><p>'.$the_excerpt_max_charlength.'</p>'.do_shortcode('[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" icon="icon-circle-arrow-right" text="'.__('Read More','code125').'" link="'.$permalink.'"]').'</div></div></li>';
        		}
        		
        		
        		
        		
        		$tabs = $tabs . $slide;
        		}
        		
        	endwhile;
        	wp_reset_query();
        }
        $return = "\n" . '<div class="flexslider s'.ot_get_option('slider_size').' features posts_slider clearfix"><ul class="slides clearfix">' .  $tabs . "\n" . '</ul></div>';
        
    }
    
     
    return $return;
}


/**
 * Shortcode: posts_slide
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_posts_slide($atts, $content) {
	$atts = shortcode_atts(array('id' => ''), $atts);
	
    $x = $GLOBALS['posts_slider_count'];
    $GLOBALS['posts_slider'][$x] = array('id' => $atts['id']);

    $GLOBALS['posts_slider_count']++;
}





/**
 * Shortcode: image
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_image($atts, $content = null) {

    $atts = shortcode_atts(array('width' => '',
        'height' => '',
        'caption' => '',
        'src' => '',
        'float' => 'left'), $atts);
    if ($atts['width']) {
        $width = 'width="' . $atts['width'] . '"';
    } else {
        $width = '';
    }
    if ($atts['height']) {
        $height = 'height="' . $atts['height'] . '"';
    } else {
        $height = '';
    }
    
    
    if ($atts['caption']) {
        $caption = '<p>' . $atts['height'] . '</p>';
    } else {
        $caption = '';
    }

    $data = '<div class="image_wrap_shortcode thumbnail '.$atts['float'].'"><img ' . $width . ' ' . $height . ' src="' . $atts['src'] . '"  />' . $caption . '</div>';

    return $data;
}

/**
 * Shortcode: video
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_video($atts, $content = null) {
    
    
    wp_enqueue_script( 'jquery_flowplayer' );
    
    $atts = shortcode_atts(array(
       'src' => '',
        'width' => 'auto',
        'height' => '400px'
            ),$atts);

    $src = $atts['src'];
    $width = $atts['width'];
    
    $height = $atts['height'];
	
	
	
    $output = '<a href="' . $src . '" style="display:block;width:' . $width . ';height:' . $height . ';margin:10px auto" id="player"></a>' . "\n";
    $output .= '<script type="text/javascript">
	flowplayer("player", "' . get_template_directory_uri() . '/library/includes/shortcodes/player/flowplayer-3.2.11.swf", {
        clip: {
               autoPlay: false,
               autoBuffering: true
}
});
</script>' . "\n";
    return $output;
}

/**
 * Shortcode: vimeo
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_vimeo($atts, $content = null) {
global $post;

if(is_home()){
	$meta_values = get_post_custom( ot_get_option( 'homepage' ) );
}else{
	$meta_values = get_post_custom($post->ID);
}

//Main Color
if( isset($meta_values['meta_custom_color'])  ){
	$primary_color = $meta_values['meta_custom_color'][0] ;
	if($primary_color == ""){
		$primary_color = ot_get_option( 'primary_color' );
	}
}else{
	$primary_color = ot_get_option( 'primary_color' );
}



    $atts = shortcode_atts(array(
                'clip_id' => '',
                'width' => '400',
                'height' => '225',
                'title' => '1',
                'byline' => '1',
                'portrait' => '1',
                'color' =>  substr($primary_color, 1),
                'html5' => '1'
                    ),$atts);

    $clip_id = $atts['clip_id'];
    $width = $atts['width'];
    $height = $atts['height'];
    $title = $atts['title'];
    $byline = $atts['byline'];
    $portrait = $atts['portrait'];
    $color = $atts['color'];
    $html5 = $atts['html5'];

    if (empty($clip_id) || !is_numeric($clip_id))
        return '<!-- Code125 Vimeo: Invalid clip_id -->';
    if ($height && !$atts['width'])
        $width = intval($height * 16 / 9);
    if (!$atts['height'] && $width)
        $height = intval($width * 9 / 16);

    return $html5 ?
            "<iframe  class='iframe_video' src='http://player.vimeo.com/video/$clip_id?title=$title&amp;byline=$byline&amp;portrait=$portrait&color=$color' width='$width' height='$height'  frameborder='0'></iframe>" :
            "<object  class='iframe_video' width='$width' height='$height'><param name='allowfullscreen' value='true' />" .
            "<param name='allowscriptaccess' value='always' />" .
            "<param name='movie' value='http://vimeo.com/moogaloop.swf?clip_id=$clip_id&amp;server=vimeo.com&amp;show_title=$title&amp;show_byline=$byline&amp;show_portrait=$portrait&amp;color=$color&amp;fullscreen=1' />" .
            "<embed src='http://vimeo.com/moogaloop.swf?clip_id=$clip_id&amp;server=vimeo.com&amp;show_title=$title&amp;show_byline=$byline&amp;show_portrait=$portrait&amp;color=$color&amp;fullscreen=1' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' width='$width' height='$height'></embed></object>";
}

/**
 * Shortcode: youtube
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_youtube($atts) {
    $atts = shortcode_atts(array(
        "id" => '',
        "width" => '475',
        "height" => '350'
            ),$atts);
    $id = $atts['id'];
    $width = $atts['width'];
    $height = $atts['height'];

    return '<iframe width="' . $width . '" height="' . $height . '" src="http://www.youtube.com/embed/' . $id . '" frameborder="0" allowfullscreen></iframe>';
}
/**
 * Shortcode: dailymotion
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_dailymotion($atts) {
    $atts = shortcode_atts(array(
        "id" => '',
        "width" => '475',
        "height" => '350'
            ),$atts);

    $id = $atts['id'];
    $width = $atts['width'];
    $height = $atts['height'];

    return '<iframe width="' . $width . '" height="' . $height . '" frameborder="0"  src="http://www.dailymotion.com/embed/video/' . $id . '" ></iframe>';
}
/**
 * Shortcode: video5
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
 function code125_video5($atts) {
    $atts = shortcode_atts(array(
        "src" => '',
        "width" => '',
        "height" => ''
            ),$atts);

    $src = $atts['src'];
    $width = $atts['width'];
    $height = $atts['height'];
    return '<video src="' . $src . '" width="' . $width . '" height="' . $height . '" controls autobuffer>';
}


function code125_audio( $atts, $content = null ) {
	extract(shortcode_atts(array(
	        "src" => '',
	        "autoplay" => 'false',
	        "preload"=> 'true',
	        "loop" => '',
	        "controls"=> ''
	    ), $atts));
	    return '<audio src="'.$src.'" preload="'.$preload.'" loop="'.$loop.'" controls="'.$controls.'" autobuffer ></audio>';
	
}



/**
 * Shortcode: contact_form
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_contact_form($atts, $content = null) {

$atts = shortcode_atts(array('name' => '', 'email'=>'', 'message'=>'', 'send'=>''), $atts);

$data = '<form id="contact-form" method="post" action="">';

$data = $data . '<div class="row-fluid">';

$data = $data . '<div class="span5">[input placeholder="'.$atts['name'].'" id="name" icon="icon name"]';
$data = $data . '[input placeholder="'.$atts['email'].'" id="email" icon="icon link"]</div>';
$data = $data . '<div class="span4">[textarea placeholder="'.$atts['message'].'" id="message" icon="icon message"]</div>';
$data = $data . '<div class="span3">[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" text="'.$atts['send'].'" id="contact_button_send" link="#" icon="icon send"]</div></div>';
  
 
$data = $data . '</form><div class="message_contact_true box success"><p>'.__('Sent ','code125').'<span class="message">'.__('Your Message was sent, Thank you.','code125').'</span></p></div><div class="message_contact_false box warning"><p>'.__('Failed ','code125').'<span class="message">'.__('Your Message was not sent, Please try again.','code125').'</span></p></div>';

return do_shortcode($data);
}



/**
 * Shortcode: fancybox
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_fancybox($atts, $content) {

    $atts = shortcode_atts(array('w' => '', 'h' => '', 'src' => '', 'caption' => ''), $atts);

    $data = '<a class="fancybox clearfix" href="' . $atts['src'] . '" title="' . $atts['caption'] . '">';
    $data = $data . '<img class="lightbox_thumb" src="' . $atts['src'] . '" width="' . $atts['w'] . 'px" height="' . $atts['h'] . 'px" />';
    $data = $data . '</a>';

    return $data;
}

/**
 * Shortcode: box
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_box($atts, $content) {

    $atts = shortcode_atts(array('type' => '', 'title' => '', 'message' => ''), $atts);

   $data = '<div class="box '.$atts['type'].'"><p>' . $atts['title'] . ':  <span class="message">' . $atts['message'] . '</span></p></div>';

    return $data;
}

/**
 * Shortcode: list_box
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_list_box($atts, $content) {
	$atts = shortcode_atts(array('col' => 'yes'), $atts);
	global $post;
	
	if(is_singular('post')){
		$type = 'post';
	}elseif (is_singular('item')) {
		$type = 'item';
	}
	
	$data = do_shortcode('[compare col="'.$atts['col'].'" type="'.$type.'" id_1="'.$post->ID.'"]');
	
		

    return $data;
}

/**
 * Shortcode: compare
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_compare($atts, $content) {

	$atts = shortcode_atts(array('id_1' => '','id_2' => '','id_3' => '','id_4' => '','col' => 'yes','type' => 'post'), $atts);
	$col_count = 1;
	for ($i = 1; $i < 5; $i++) {
		if(isset($atts['id_'.$i]) && $atts['id_'.$i]!=''){
			${"id_".$i} = $atts['id_1'];
			${"meta_values_".$i} = get_post_custom($atts['id_'.$i]);
			if($atts['type']=='post'){
				$catrgories = wp_get_post_categories( $atts['id_'.$i] );
				$list[]  = $catrgories;
			}else {
				$cats = wp_get_post_terms( $atts['id_'.$i],'item_type' );
				$catrgories=array();
				foreach ($cats as $key => $value) {
					$catrgories[]=$value->term_id;
				}
				$list[]  = $catrgories;
			}
			$col_count ++;
		}
	}
	
	
	if($atts['type'] =='post'){
		$prefix = '';
	}elseif ($atts['type'] =='item') {
		$prefix = '_item';
	}
	$article_meta_list = ot_get_option('custom_meta'.$prefix.'_all');
    if($col_count > 2){
   	 	$intersect = call_user_func_array('array_intersect',$list);
    }else {
    	$intersect = $catrgories;
    }

	
	
	if(is_array($article_meta_list) || count($intersect)!=0 ){
		
		if($atts['col']!='no'){
			$table_class = 'leftcol table_col_'.$col_count;
		}else {
			$col_count_1= $col_count -1;
			$table_class = 'leftcol_no table_col_'. $col_count_1;
		}
		
		$data = '<table class="table '.$table_class.' compare"><tbody>';
		$counter = 1;
		if(is_array($article_meta_list)){		
			foreach ($article_meta_list as $meta) {
				$data = $data . '<tr  class="row'.$counter.'">';
				
				if($atts['col']!='no'){
					$data = $data . '<td class="title" >';
					if($meta['title_show'] == 'icon_tooltip'){
						$data = $data . '<span title="'.$meta['title'].'" class="'.$meta['icon'].'"> </span>';
					}elseif ($meta['title_show'] == 'icon') {
						$data = $data . '<span class="'.$meta['icon'].'"> </span>';
					}elseif ($meta['title_show'] == 'text') {
						$data = $data . $meta['title'];
					}else {
						$data = $data . '';
					}
					$data = $data . '</td>';
				}
				
				
				for ($i = 1; $i < $col_count; $i++) {
					$meta_values = ${'meta_values_'.$i};
					if($meta['type'] == 'title'){
						$data = $data . '<td class="ctitle"><a href="'.get_permalink($atts['id_'.$i]).'" class="title">'.$meta_values['meta_list'.$prefix.'_all_'.$meta['slug']][0].'</a></td>';
					}else {
						$data = $data . '<td class="td'.$i.'">'.html_entity_decode (do_shortcode( html_entity_decode($meta_values['meta_list'.$prefix.'_all_'.$meta['slug']][0])) ).'</td>';
					}
				}
			
				
				$data = $data . '</tr>';
				$counter++;
			
			}
		}
		
		if(count($intersect)!=0 ){
			foreach ($intersect as $id ) {
				
				$article_meta_list = ot_get_option('custom_meta'.$prefix.'_' . $id);
				if(is_array($article_meta_list)){
				foreach ($article_meta_list as $meta) {
					$data = $data . '<tr  class="row'.$counter.'">';
					
					if($atts['col']!='no'){
						$data = $data . '<td class="title" >';
						if($meta['title_show'] == 'icon_tooltip'){
							$data = $data . '<span title="'.$meta['title'].'" class="'.$meta['icon'].'"> </span>';
						}elseif ($meta['title_show'] == 'icon') {
							$data = $data . '<span class="'.$meta['icon'].'"> </span>';
						}elseif ($meta['title_show'] == 'text') {
							$data = $data . $meta['title'];
						}else {
							$data = $data . '';
						}
						$data = $data . '</td>';
					}
					
					
					for ($i = 1; $i < $col_count; $i++) {
						$meta_values = ${'meta_values_'.$i};
						if($meta['type'] == 'title'){
							$data = $data . '<td class="ctitle"><a href="'.get_permalink($atts['id_'.$i]).'" class="title">'.$meta_values['meta_list'.$prefix.'_cat'.$id.'_'.$meta['slug']][0].'</a></td>';
						}else {
							$data = $data . '<td class="td'.$i.'">'.html_entity_decode (do_shortcode( html_entity_decode($meta_values['meta_list'.$prefix.'_cat'.$id.'_'.$meta['slug']][0])) ).'</td>';
						}
					}
				
					
					$data = $data . '</tr>';
					$counter++;
				
				}
				}
			}
		
		}
		
		
		
		$data = $data .'</tbody></table>';
		
	}	
    return $data;
}


/**
 * Shortcode: compare_box_item
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_compare_box_item($atts, $content) {

	$atts = shortcode_atts(array('number_of_posts' => '2','col' => 'yes','category' => ''), $atts);

	$data = '<div class="compare_box"><form method="post" action=""><div class="row-fluid"><div class="span10"><div class="row-fluid">';
	
	$span = 12/$atts['number_of_posts'];
	
	if(isset($atts['category']) && $atts['category'] !=''){
	
		$query = new WP_Query( array( 'post_type' => 'item', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish','tax_query' => array(
				array(
					'taxonomy' => 'item_type',
					'field' => 'id',
					'terms' => $atts['category']
				)
			) ) );
		
	}else {
		$query = new WP_Query( array( 'post_type' => 'item', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ) );
	}
	
	/* has posts */
	if ( $query->have_posts() ) {
	  while ( $query->have_posts() ) {
	    $query->the_post();
	    $items[get_the_ID()] = get_the_title();
	  } 
	}
	wp_reset_postdata();
	
	
	
	for ($i = 1; $i <= $atts['number_of_posts']; $i++) {
		$data = $data . '<div class="span'.$span.'">';
		
		$data = $data . '<select name="item_'.$i.'">';
		foreach ($items as $key => $value){
			$data = $data . '<option value="'. $key .'"'; 
		
			if(isset( $_POST['item_'.$i] )){ 
				if(  $key ==$_POST['item_'.$i]){ 
					$data = $data . 'selected="selected"'; 
				}
			} 
			$data = $data . '>'. $value .'</option>';
		}
		$data = $data . '</select></div>';
	}
	
	
	$data = $data . '</div></div><div class="span2"><input type="submit" name="wp-compare" id="wp-compare" class="button  button-primary right button-med" value="'. __('Compare','code125').'"></div></div></form></div>';
	
	
	if(isset( $_POST['item_1'] )){
		$shortcode = '[compare col="'.$atts['col'].'" type="item" id_1="'.$_POST['item_1'].'" ';
		if(isset( $_POST['item_2'] )){
			$shortcode = $shortcode . ' id_2="'.$_POST['item_2'].'" ';
		}
		if(isset( $_POST['item_3'] )){
			$shortcode = $shortcode . ' id_3="'.$_POST['item_3'].'" ';
		}
		if(isset( $_POST['item_4'] )){
			$shortcode = $shortcode . ' id_4="'.$_POST['item_4'].'" ';
		}
		
		$shortcode = $shortcode . '"]';
		
		$data = $data . do_shortcode('[divider_space]') . do_shortcode($shortcode);
	
	}
	
    return $data;
}

/**
 * Shortcode: compare_box_item
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_compare_box_post($atts, $content) {

	$atts = shortcode_atts(array('number_of_posts' => '2','col' => 'yes','category' => ''), $atts);

	$data = '<div class="compare_box"><form method="post" action=""><div class="row-fluid"><div class="span10"><div class="row-fluid">';
	
	$span = 12/$atts['number_of_posts'];
	
	$query = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish','cat' => $atts['category'] ) );
		
	
	
	/* has posts */
	if ( $query->have_posts() ) {
	  while ( $query->have_posts() ) {
	    $query->the_post();
	    $items[get_the_ID()] = get_the_title();
	  } 
	}
	wp_reset_postdata();
	
	
	
	for ($i = 1; $i <= $atts['number_of_posts']; $i++) {
		$data = $data . '<div class="span'.$span.'">';
		
		$data = $data . '<select name="item_'.$i.'">';
		foreach ($items as $key => $value){
			$data = $data . '<option value="'. $key .'"'; 
		
			if(isset( $_POST['item_'.$i] )){ 
				if(  $key ==$_POST['item_'.$i]){ 
					$data = $data . 'selected="selected"'; 
				}
			} 
			$data = $data . '>'. $value .'</option>';
		}
		$data = $data . '</select></div>';
	}
	
	
	$data = $data . '</div></div><div class="span2"><input type="submit" name="wp-compare" id="wp-compare" class="button  button-primary right button-med" value="'. __('Compare','code125').'"></div></div></form></div>';
	
	
	if(isset( $_POST['item_1'] )){
		$shortcode = '[compare col="'.$atts['col'].'" type="post" id_1="'.$_POST['item_1'].'" ';
		if(isset( $_POST['item_2'] )){
			$shortcode = $shortcode . ' id_2="'.$_POST['item_2'].'" ';
		}
		if(isset( $_POST['item_3'] )){
			$shortcode = $shortcode . ' id_3="'.$_POST['item_3'].'" ';
		}
		if(isset( $_POST['item_4'] )){
			$shortcode = $shortcode . ' id_4="'.$_POST['item_4'].'" ';
		}
		
		$shortcode = $shortcode . '"]';
		
		$data = $data . do_shortcode('[divider_space]') . do_shortcode($shortcode);
	
	}
	
    return $data;
}


/**
 * Shortcode: divider
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_divider($atts, $content = null) {
    return '<div class="divider_shortcode"></div>';
}

/**
 * Shortcode: divider_space
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_divider_space($atts, $content = null) {
    return '<div class="clearfix"></div><div class="divider_space"></div>';
}








/**
 * Shortcode: twitter
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_twitter($atts, $content = null) {
    
    
    $atts = shortcode_atts(array(
    	'consumerkey' => '',
    	'consumersecret' => '',
    	'accesstoken' => '',
    	'accesstokensecret' => '',
    	'cachetime' => '',
    	'username' => '',
    	'count' => '5'), $atts);


    //check if cache needs update
    	$tp_twitter_plugin_last_cache_time = get_option('tp_twitter_plugin_last_cache_time');
    	$diff = time() - $tp_twitter_plugin_last_cache_time;
    	$crt = $atts['cachetime'] * 3600;
    	
    	$data = '';
     //	yes, it needs update			
    	if($diff >= $crt || empty($tp_twitter_plugin_last_cache_time)){
    		
    		if(!require_once( get_template_directory() . '/library/includes/twitteroauth.php' )){ 
    			$data = $data . '<strong>Couldn\'t find twitteroauth.php!</strong>' ;
    			return;
    		}
    									  
    		$connection = getConnectionWithAccessToken($atts['consumerkey'], $atts['consumersecret'], $atts['accesstoken'], $atts['accesstokensecret']);
    		$tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$atts['username']."&count=10") or die('Couldn\'t retrieve tweets! Wrong username?');
    		
    									
    		if(!empty($tweets->errors)){
    			if($tweets->errors[0]->message == 'Invalid or expired token'){
    				$data = $data . '<strong>'.$tweets->errors[0]->message.'!</strong><br />You\'ll need to regenerate it <a href="https://dev.twitter.com/apps" target="_blank">here</a>!';
    			}else{
    				$data = $data . '<strong>'.$tweets->errors[0]->message.'</strong>' ;
    			}
    			return;
    		}
    		
    		for($i = 0;$i <= count($tweets); $i++){
    			if(!empty($tweets[$i])){
    				$tweets_array[$i]['created_at'] = $tweets[$i]->created_at;
    				$tweets_array[$i]['text'] = $tweets[$i]->text;			
    				$tweets_array[$i]['status_id'] = $tweets[$i]->id_str;			
    			}	
    		}							
    		
    		//save tweets to wp option 		
    			update_option('tp_twitter_plugin_tweets',serialize($tweets_array));							
    			update_option('tp_twitter_plugin_last_cache_time',time());
    			
    		$data = $data . '<!-- twitter cache has been updated! -->';
    	}
    	
    	
    						
    						
    						
    						$tp_twitter_plugin_tweets = maybe_unserialize(get_option('tp_twitter_plugin_tweets'));
    						if(!empty($tp_twitter_plugin_tweets)){
    							$data = $data . '<div class="tp_recent_tweets"><ul>';
    								$fctr = '1';
    								foreach($tp_twitter_plugin_tweets as $tweet){								
    									$data = $data . '<li><span class="icon-twitter"> </span> <span>'.convert_links($tweet['text']).'</span><br /><a class="twitter_time" target="_blank" href="http://twitter.com/'.$atts['username'].'/statuses/'.$tweet['status_id'].'">'.relative_time($tweet['created_at']).'</a></li>';
    									if($fctr == $atts['count']){ break; }
    									$fctr++;
    								}
    							
    							$data = $data . '</ul></div>';
    						}
	return $data;
}

add_shortcode('twitter', 'code125_twitter');



/**
 * Shortcode: flickr
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_flickr($atts, $content = null) {
	
	
	$atts = shortcode_atts(array('id' => '','count' =>'' ), $atts);
	
	$username = $atts['id'];
	
	$count = $atts['count'];
	
	$data = '<div class="flickr clearfix">'. parseFlickrFeed($username,$count) . '</div>';
	return $data;
	
}
function attr($s,$attrname) { // return html attribute
    preg_match_all('#\s*('.$attrname.')\s*=\s*["|\']([^"\']*)["|\']\s*#i', $s, $x);
    if (count($x)>=3) return $x[2][0]; else return "";
}
 
// id = id of the feed
// n = number of thumbs
function parseFlickrFeed($id,$n) {
    $url = "http://api.flickr.com/services/feeds/photos_public.gne?id={$id}&lang=it-it&format=rss_200";
    $s = file_get_contents($url);
    preg_match_all('#<item>(.*)</item>#Us', $s, $items);
    $out = "";
    for($i=0;$i<count($items[1]);$i++) {
        if($i>=$n) return $out;
        $item = $items[1][$i];
        preg_match_all('#<link>(.*)</link>#Us', $item, $temp);
        $link = $temp[1][0];
        preg_match_all('#<title>(.*)</title>#Us', $item, $temp);
        $title = $temp[1][0];
        preg_match_all('#<media:thumbnail([^>]*)>#Us', $item, $temp);
        $thumb = attr($temp[0][0],"url");
        $class_i = $i+1;
        if( $class_i % 3){
			$class='class=""';        
        }else{
        	$class='class="last_col"';
        }
        
        $out.="<a href='$link' $class target='_blank' title=\"".str_replace('"','',$title)."\"><img src='$thumb' alt=''/></a>";
    }
    return $out;
}


/**
 * Shortcode: googlemap_side
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_googlemap_side($atts, $content = null) {
	
	add_action('wp_head', 'code125_gmaps_header');
	
	$atts = shortcode_atts(array('long' => '','lat' =>'' ), $atts);
	
	$data = '<div class="googlemap_side clearfix"><div class="width_55">'.do_shortcode('[googlemap lat="'.$atts['lat'].'" lon="'.$atts['long'].'" w="100%" h="400" z="17" ]').'</div><div class="width_45"><div class="strips"><div class="shine_2">'.do_shortcode($content).'</div></div></div></div>';
	
	return $data;
	
}

/**
 * Shortcode: googlemap
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */

function code125_gmaps_header() {
    ?>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <style type="text/css">
        .entry-content img {max-width: 100000%; /* override */}
    </style> 
    <?php
}

function code125_googlemap($attr) {

    // default atts
    $attr = shortcode_atts(array(
        'lat' => '0',
        'lon' => '0',
        'id' => 'map',
        'z' => '1',
        'w' => '400',
        'h' => '300',
        'maptype' => 'ROADMAP',
        'address' => '',
        'kml' => '',
        'kmlautofit' => 'yes',
        'marker' => '',
        'markerimage' => '',
        'traffic' => 'no',
        'bike' => 'no',
        'fusion' => '',
        'start' => '',
        'end' => '',
        'infowindow' => '',
        'infowindowdefault' => 'yes',
        'directions' => '',
        'hidecontrols' => 'false',
        'scale' => 'false',
        'scrollwheel' => 'true'
            ), $attr);


    $returnme = '
    <div id="' . $attr['id'] . '" class="googlemap" style="width:' . $attr['w'] . 'px;height:' . $attr['h'] . 'px;"></div>
	';

    //directions panel
    if ($attr['start'] != '' && $attr['end'] != '') {
        $panelwidth = $attr['w'] - 20;
        $returnme .= '
		<div id="directionsPanel" style="width:' . $panelwidth . 'px;height:' . $attr['h'] . 'px;border:1px solid gray;padding:10px;overflow:auto;"></div><br>
		';
    }


    $returnme .= '<script type="text/javascript"> var latlng = new google.maps.LatLng(' . $attr['lat'] . ', ' . $attr['lon'] . ');
		var myOptions = {
			zoom: ' . $attr['z'] . ',
			center: latlng,
			scrollwheel: ' . $attr['scrollwheel'] . ',
			scaleControl: ' . $attr['scale'] . ',
			disableDefaultUI: ' . $attr['hidecontrols'] . ',
			mapTypeId: google.maps.MapTypeId.' . $attr['maptype'] . '
		};
		var ' . $attr['id'] . ' = new google.maps.Map(document.getElementById("' . $attr['id'] . '"),
		myOptions);
		';

    //kml
    if ($attr['kml'] != '') {
        if ($attr['kmlautofit'] == 'no') {
            $returnme .= '
				var kmlLayerOptions = {preserveViewport:true};
				';
        } else {
            $returnme .= '
				var kmlLayerOptions = {preserveViewport:false};
				';
        }
        $returnme .= '
			var kmllayer = new google.maps.KmlLayer(\'' . html_entity_decode($attr['kml']) . '\',kmlLayerOptions);
			kmllayer.setMap(' . $attr['id'] . ');
			';
    }

    //directions
    if ($attr['start'] != '' && $attr['end'] != '') {
        $returnme .= '
			var directionDisplay;
			var directionsService = new google.maps.DirectionsService();
		    directionsDisplay = new google.maps.DirectionsRenderer();
		    directionsDisplay.setMap(' . $attr['id'] . ');
    		directionsDisplay.setPanel(document.getElementById("directionsPanel"));

				var start = \'' . $attr['start'] . '\';
				var end = \'' . $attr['end'] . '\';
				var request = {
					origin:start, 
					destination:end,
					travelMode: google.maps.DirectionsTravelMode.DRIVING
				};
				directionsService.route(request, function(response, status) {
					if (status == google.maps.DirectionsStatus.OK) {
						directionsDisplay.setDirections(response);
					}
				});


			';
    }

    //traffic
    if ($attr['traffic'] == 'yes') {
        $returnme .= '
			var trafficLayer = new google.maps.TrafficLayer();
			trafficLayer.setMap(' . $attr['id'] . ');
			';
    }

    //bike
    if ($attr['bike'] == 'yes') {
        $returnme .= '			
			var bikeLayer = new google.maps.BicyclingLayer();
			bikeLayer.setMap(' . $attr['id'] . ');
			';
    }

    //fusion tables
    if ($attr['fusion'] != '') {
        $returnme .= '			
			var fusionLayer = new google.maps.FusionTablesLayer(' . $attr['fusion'] . ');
			fusionLayer.setMap(' . $attr['id'] . ');
			';
    }

    //address
    if ($attr['address'] != '') {
        $returnme .= '
		    var geocoder_' . $attr['id'] . ' = new google.maps.Geocoder();
			var address = \'' . $attr['address'] . '\';
			geocoder_' . $attr['id'] . '.geocode( { \'address\': address}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					' . $attr['id'] . '.setCenter(results[0].geometry.location);
					';

        if ($attr['marker'] != '') {
            //add custom image
            if ($attr['markerimage'] != '') {
                $returnme .= 'var image = "' . $attr['markerimage'] . '";';
            }
            $returnme .= '
						var marker = new google.maps.Marker({
							map: ' . $attr['id'] . ', 
							';
            if ($attr['markerimage'] != '') {
                $returnme .= 'icon: image,';
            }
            $returnme .= '
							position: ' . $attr['id'] . '.getCenter()
						});
						';

            //infowindow
            if ($attr['infowindow'] != '') {
                //first convert and decode html chars
                $thiscontent = htmlspecialchars_decode($attr['infowindow']);
                $returnme .= '
							var contentString = \'' . $thiscontent . '\';
							var infowindow = new google.maps.InfoWindow({
								content: contentString
							});
										
							google.maps.event.addListener(marker, \'click\', function() {
							  infowindow.open(' . $attr['id'] . ',marker);
							});
							';

                //infowindow default
                if ($attr['infowindowdefault'] == 'yes') {
                    $returnme .= '
									infowindow.open(' . $attr['id'] . ',marker);
								';
                }
            }
        }
        $returnme .= '
				} else {
				alert("Geocode was not successful for the following reason: " + status);
			}
			});
			';
    }

    //marker: show if address is not specified
    if ($attr['marker'] != '' && $attr['address'] == '') {
        //add custom image
        if ($attr['markerimage'] != '') {
            $returnme .= 'var image = "' . $attr['markerimage'] . '";';
        }

        $returnme .= '
				var marker = new google.maps.Marker({
				map: ' . $attr['id'] . ', 
				';
        if ($attr['markerimage'] != '') {
            $returnme .= 'icon: image,';
        }
        $returnme .= '
				position: ' . $attr['id'] . '.getCenter()
			});
			';

        //infowindow
        if ($attr['infowindow'] != '') {
            $returnme .= '
				var contentString = \'' . $attr['infowindow'] . '\';
				var infowindow = new google.maps.InfoWindow({
					content: contentString
				});
							
				google.maps.event.addListener(marker, \'click\', function() {
				  infowindow.open(' . $attr['id'] . ',marker);
				});
				';
            //infowindow default
            if ($attr['infowindowdefault'] == 'yes') {
                $returnme .= '
						infowindow.open(' . $attr['id'] . ',marker);
					';
            }
        }
    }

    $returnme .= '</script>';

    return $returnme;
}
/**
 * Shortcode: social_box
 *
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string Output html
 */
function code125_social_box($atts, $content = null) {

    global $wpdb;

    $data = '<div class="social_box_count clearfix row-fluid">';
    //Facebook
    $facebook_id = ot_get_option( 'facebook' );
    if ($facebook_id) {

        $fb_count = code125_fb_fan_count($facebook_id);
        if (is_numeric($facebook_id)) {
			$data = $data . '<div class="span3 count facebook_count"><a class="icon-facebook" href="https://www.facebook.com/profile.php?id=' . $facebook_id . '"></a><p>' . custom_number_format($fb_count) . '</p></div>' ;
            
        } else {            
            $data = $data . '<div class="span3 count facebook_count"><a class="icon-facebook" href="https://www.facebook.com/' . $facebook_id . '"></a><p>' . custom_number_format($fb_count) . '</p></div>' ;
            
        }
    }
    //twitter
    $twitter_id = ot_get_option( 'twitter' );
    if ($twitter_id) {
        $tw_count = code125_twitter_followers($twitter_id);
                
        $data = $data . '<div class="span3 count twitter_count"><a class="icon-twitter" href="https://www.twitter.com/' . $twitter_id . '"></a><p>' . custom_number_format($tw_count) . '</p></div>' ;
    }
    //RSS
    $rss_id = ot_get_option( 'rss' );
    if ($rss_id) {

        
        $data = $data . '<div class="span3 count rss_count"><a class="icon-rss" href="' . $rss_id . '"></a><p>Follow</p></div>' ;
      
    }
    
    $comments_count_box = ot_get_option( 'comments_count_box' );
    if($comments_count_box != 'no'){
    $numcomms = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = '1'");
    
	$data = $data . '<div class="span3 count comments_count"><a class=" icon-comment"></a><p>' . custom_number_format($numcomms) . '</p></div>' ;
     }
        $data = $data . '</div>';


    return $data;
}

function code125_twitter_followers($username) {
	
	
	
	
	$cache = get_transient('twitterfollowerscount' . $username);
	
	if ($cache) {
	    $count = get_option('twitterfollowerscount' . $username);
	    if($count ==0){
	    	$url = 'http://twitter.com/users/show/' . urlencode($username);
	    	$xml=file_get_contents($url);
	    	if (preg_match('/followers_count>(.*)</',$xml,$match)!=0) {
	    	$count = $match[1];
	    	}
	    	set_transient('twitterfollowerscount' . $username, 'true',  60 * 30);
	    	update_option('twitterfollowerscount' . $username, $count);
	    }
	} else {
		$url = 'http://twitter.com/users/show/' . urlencode($username);
		$xml=file_get_contents($url);
		if (preg_match('/followers_count>(.*)</',$xml,$match)!=0) {
		$count = $match[1];
		}
		set_transient('twitterfollowerscount' . $username, 'true',  60 * 30);
		update_option('twitterfollowerscount' . $username, $count);
	}
 return $count;
}

function code125_fb_fan_count($fb_id) {

    $count = 0;

    if (is_numeric($fb_id)) {
        $data = wp_remote_get('http://api.facebook.com/restserver.php?method=facebook.fql.query&query=SELECT%20fan_count%20FROM%20page%20WHERE%20page_id=' . $fb_id . '');
    } else {
        $data = wp_remote_get('http://api.facebook.com/restserver.php?method=facebook.fql.query&query=SELECT%20fan_count%20FROM%20page%20WHERE%20username="' . $fb_id . '"');
    }
    if (is_wp_error($data)) {
        return 'Error getting number';
    } else {
        $count = strip_tags($data['body']);
    }
    return $count;
}

function code125_fb_count($fb_user) {

    $url = 'https://feedburner.google.com/api/awareness/1.0/GetFeedData?uri=' . urlencode($fb_user);
    
    
    $result = wp_remote_retrieve_body(wp_remote_get($url));
	
	$data = json_decode($result);

$xml = new SimpleXMLElement(stripslashes($result));
			$status = $xml->attributes();
			
			if ($status == 'ok') {
				$count = $xml->feed->entry->attributes()->circulation;
			} else {
				$count = 0; // fallback
			}

    return $count;
}

function code125_fb_count_run($feed) {

    $fb_subs = code125_fb_count($feed);
    $fb_option = "code125_fb_sub_value";
    $fb_subscount = get_option($fb_option);
    if (is_null($fb_subs)) {
        return $fb_subscount;
    } else {
        update_option($fb_option, $fb_subs);
        return $fb_subs;
    }
}

function code125_fb_sub_value($feed) {

    return code125_fb_count_run($feed);
}


/* Register oEmbed provider
   -------------------------------------------------------------------------- */

wp_oembed_add_provider('#https?://(?:api\.)?soundcloud\.com/.*#i', 'http://soundcloud.com/oembed', true);


/* Register SoundCloud shortcode
   -------------------------------------------------------------------------- */



/**
 * SoundCloud shortcode handler
 * @param  {string|array}  $atts     The attributes passed to the shortcode like [soundcloud attr1="value" /].
 *                                   Is an empty string when no arguments are given.
 * @param  {string}        $content  The content between non-self closing [soundcloud]…[/soundcloud] tags.
 * @return {string}                  Widget embed code HTML
 */
function code125_soundcloud($atts, $content = null) {

  // Custom shortcode options
  $shortcode_options = array_merge(array('url' => trim($content)), is_array($atts) ? $atts : array());

  // Turn shortcode option "param" (param=value&param2=value) into array
  $shortcode_params = array();
  if (isset($shortcode_options['params'])) {
    parse_str(html_entity_decode($shortcode_options['params']), $shortcode_params);
  }
  $shortcode_options['params'] = $shortcode_params;

  // User preference options
  $plugin_options = array_filter(array(
    'iframe' => code125_soundcloud_get_option('player_iframe', true),
    'width'  => code125_soundcloud_get_option('player_width'),
    'height' =>  code125_soundcloud_url_has_tracklist($shortcode_options['url']) ? code125_soundcloud_get_option('player_height_multi') : code125_soundcloud_get_option('player_height'),
    'params' => array_filter(array(
      'auto_play'     => code125_soundcloud_get_option('auto_play'),
      'show_comments' => code125_soundcloud_get_option('show_comments'),
      'color'         => code125_soundcloud_get_option('color'),
      'theme_color'   => code125_soundcloud_get_option('theme_color'),
    )),
  ));
  // Needs to be an array
  if (!isset($plugin_options['params'])) { $plugin_options['params'] = array(); }

  // plugin options < shortcode options
  $options = array_merge(
    $plugin_options,
    $shortcode_options
  );

  // plugin params < shortcode params
  $options['params'] = array_merge(
    $plugin_options['params'],
    $shortcode_options['params']
  );

	if (isset($options['id'])) {
		$options['url'] = trim('http://api.soundcloud.com/tracks/'. $options['id']);
	}else{
  // The "url" option is required
  		if (!isset($options['url'])) {
    	   	return '';
    	} else {
    		$options['url'] = trim($options['url']);
  		}
  	}

  // Both "width" and "height" need to be integers
  if (isset($options['width']) && !preg_match('/^\d+$/', $options['width'])) {
    // set to 0 so oEmbed will use the default 100% and WordPress themes will leave it alone
    $options['width'] = 0;
  }
  if (isset($options['height']) && !preg_match('/^\d+$/', $options['height'])) { unset($options['height']); }

  // The "iframe" option must be true to load the iframe widget
  $iframe = code125_soundcloud_booleanize(true)
    // Default to flash widget for permalink urls (e.g. http://soundcloud.com/{username})
    // because HTML5 widget doesn’t support those yet
    ? preg_match('/api.soundcloud.com/i', $options['url'])
    : false;

  // Return html embed code
  if ($iframe) {
    return code125_soundcloud_iframe_widget($options);
  } else {
    return code125_soundcloud_flash_widget($options);
  }

}

/**
 * Plugin options getter
 * @param  {string|array}  $option   Option name
 * @param  {mixed}         $default  Default value
 * @return {mixed}                   Option value
 */
function code125_soundcloud_get_option($option, $default = false) {
  $value = get_option('code125_soundcloud_' . $option);
  return $value === '' ? $default : $value;
}

/**
 * Booleanize a value
 * @param  {boolean|string}  $value
 * @return {boolean}
 */
function code125_soundcloud_booleanize($value) {
  return is_bool($value) ? $value : $value === 'true' ? true : false;
}

/**
 * Decide if a url has a tracklist
 * @param  {string}   $url
 * @return {boolean}
 */
function code125_soundcloud_url_has_tracklist($url) {
  return preg_match('/^(.+?)\/(sets|groups|playlists)\/(.+?)$/', $url);
}

/**
 * Parameterize url
 * @param  {array}  $match  Matched regex
 * @return {string}          Parameterized url
 */
function code125_soundcloud_oembed_params_callback($match) {
  global $code125_soundcloud_oembed_params;

  // Convert URL to array
  $url = parse_url(urldecode($match[1]));
  // Convert URL query to array
  parse_str($url['query'], $query_array);
  // Build new query string
  $query = http_build_query(array_merge($query_array, $code125_soundcloud_oembed_params));

  return 'src="' . $url['scheme'] . '://' . $url['host'] . $url['path'] . '?' . $query;
}

/**
 * Iframe widget embed code
 * @param  {array}   $options  Parameters
 * @return {string}            Iframe embed code
 */
function code125_soundcloud_iframe_widget($options) {

  // Merge in "url" value
  $options['params'] = array_merge(array(
    'url' => $options['url']
  ), $options['params']);

  // Build URL
  $url = 'http://w.soundcloud.com/player?' . http_build_query($options['params']);
  // Set default width if not defined
  $width = isset($options['width']) && $options['width'] !== 0 ? $options['width'] : '100%';
  // Set default height if not defined
  $height = isset($options['height']) && $options['height'] !== 0 ? $options['height'] : (code125_soundcloud_url_has_tracklist($options['url']) ? '450' : '166');

  return sprintf('<iframe width="%s" height="%s" scrolling="no" frameborder="no" src="%s"></iframe>', $width, $height, $url);
}

/**
 * Legacy Flash widget embed code
 * @param  {array}   $options  Parameters
 * @return {string}            Flash embed code
 */
function code125_soundcloud_flash_widget($options) {

  // Merge in "url" value
  $options['params'] = array_merge(array(
    'url' => $options['url']
  ), $options['params']);

  // Build URL
  $url = 'http://player.soundcloud.com/player.swf?' . http_build_query($options['params']);
  // Set default width if not defined
  $width = isset($options['width']) && $options['width'] !== 0 ? $options['width'] : '100%';
  // Set default height if not defined
  $height = isset($options['height']) && $options['height'] !== 0 ? $options['height'] : (code125_soundcloud_url_has_tracklist($options['url']) ? '255' : '81');

  return preg_replace('/\s\s+/', "", sprintf('<object width="%s" height="%s">
                                <param name="movie" value="%s"></param>
                                <param name="allowscriptaccess" value="always"></param>
                                <embed width="%s" height="%s" src="%s" allowscriptaccess="always" type="application/x-shockwave-flash"></embed>
                              </object>', $width, $height, $url, $width, $height, $url));
}




?>