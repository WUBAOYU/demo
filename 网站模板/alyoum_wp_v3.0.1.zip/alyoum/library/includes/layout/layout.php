<?php

class C5_theme_layout {

    function __construct() {
        
    }

    function skin_exist($id) {
        if ($id == '') {
            return false;
        }
        $found = false;
        $skin_query = new WP_Query( 'p=' . $id . '&post_type=skin' );
        
        // The Loop
        if ( $skin_query->have_posts() ) {
        	$found = true;
        }
       // wp_reset_postdata();
        return $found;
    }
    
    
    function get_color_from_skin($skin_id) {
    	return get_post_meta($skin_id, 'primary_color', true);
    }

    function get_current_skin_id() {

		if (is_category() || is_tax()) {
            $obj = get_queried_object();
            $term_id = $obj->term_id;
            $tax = $obj->taxonomy;

            $value = get_option('c5_term_meta_' . $tax . '_' . $term_id . '_' . 'skin');
            if ($this->skin_exist($value)) {
                return $value;
            }
            $value = ot_get_option('skin_default_category');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_tag()) {
            $obj = get_queried_object();
            $term_id = $obj->term_id;
            $tax = $obj->taxonomy;

            $value = get_option('c5_term_meta_' . $tax . '_' . $term_id . '_' . 'skin');
            if ($this->skin_exist($value)) {
                return $value;
            }
            $value = ot_get_option('skin_default_tag');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_single()) {
            global $post;
            $value = get_post_meta($post->ID, 'posts_skin', true);
            if ($this->skin_exist($value)) {
                return $value;
            }

            $type = get_post_type($post->ID);
            if ($type == 'post') {
                $use_parent = ot_get_option('posts_styling');
            } else {
                $custom_posts = ot_get_option('custom_posts', array());
                if ($custom_posts) {
                    foreach ($custom_posts as $custom_post) {
                        if ($type == $custom_post['slug']) {
                            $use_parent = $custom_post['posts_styling'];
                            break;
                        }
                    }
                }
            }
            if ($use_parent == 'on') {
                $tax = c5_get_post_tax($post->ID);
                $category_follow = get_post_meta($post->ID, 'category_follow', true);
                if ($category_follow != '') {
                    $value = get_option('c5_term_meta_' . $tax . '_' . $category_follow . '_' . 'article_skin');
                    if ($this->skin_exist($value)) {
                        return $value;
                    }
                }
                $terms = wp_get_post_terms($post->ID, $tax);
                if (count($terms) != 0) {
                    foreach ($terms as $term) {
                        $value = get_option('c5_term_meta_' . $tax . '_' . $term->term_id . '_' . 'article_skin');
                        if ($this->skin_exist($value)) {
                            return $value;
                        }
                    }
                }
            }
            if ($type != 'post') {
                $custom_posts = ot_get_option('custom_posts', array());
                if ($custom_posts) {
                    foreach ($custom_posts as $custom_post) {
                        if ($custom_post['slug'] == $type) {
                            $value = $custom_post['skin_default'];
                            if ($this->skin_exist($value)) {
                                return $value;
                            }
                        }
                    }
                }
            }

            $value = ot_get_option('skin_default_article');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_search()) {
            $value = ot_get_option('skin_default_search');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_author()) {
            $obj = get_queried_object();

            $value = get_the_author_meta('c5_term_meta_user_skin', $obj->ID);
            if ($this->skin_exist($value)) {
                return $value;
            }

            $value = ot_get_option('skin_default_author');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_404()) {
            $value = ot_get_option('skin_default_404');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_page()) {
            global $post;

            $value = get_post_meta($post->ID, 'skin_default', true);
            if ($this->skin_exist($value)) {
                return $value;
            }

            $value = ot_get_option('skin_default_page');
            if ($this->skin_exist($value)) {
                return $value;
            }
        } elseif (is_archive()) {
            $value = ot_get_option('skin_default_archive');
            if ($this->skin_exist($value)) {
                return $value;
            }
        }


        $value = ot_get_option('skin_default');

        return $value;
    }
    
    function template_exist($id) {
    	if($id != ''){
    		return true;
    	}
    	return false;
    }
    
    function get_current_template_id() {
    
    		if (is_category() || is_tax()) {
                $obj = get_queried_object();
                $term_id = $obj->term_id;
                $tax = $obj->taxonomy;
    
                $value = get_option('c5_term_meta_' . $tax . '_' . $term_id . '_' . 'template');
                if ($this->template_exist($value)) {
                    return $value;
                }
                $value = ot_get_option('cat_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            } elseif (is_tag()) {
                $obj = get_queried_object();
                $term_id = $obj->term_id;
                $tax = $obj->taxonomy;
    
                $value = get_option('c5_term_meta_' . $tax . '_' . $term_id . '_' . 'template');
                if ($this->template_exist($value)) {
                    return $value;
                }
                $value = ot_get_option('tag_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            
            } elseif (is_search()) {
                $value = ot_get_option('search_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            } elseif (is_author()) {
                $obj = get_queried_object();
    
                $value = get_the_author_meta('c5_term_meta_user_template', $obj->ID);
                if ($this->template_exist($value)) {
                    return $value;
                }
    
                $value = ot_get_option('author_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            } elseif (is_404()) {
                $value = ot_get_option('404_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            } elseif (is_archive()) {
                $value = ot_get_option('archive_template');
                if ($this->template_exist($value)) {
                    return $value;
                }
            }
    
    
            $value = ot_get_option('default_template');
    
            return $value;
        }

    function get_current_skin() {

        global $c5_skindata;
        global $c5_skinid;

        $skin_id = $this->get_current_skin_id();
        $c5_skinid = $skin_id;
        $c5_skindata_defaults = get_option('c5_skin_defaults');
        if (!is_array($c5_skindata_defaults)) {
            $skin_obj = new C5_skin();
            $c5_skindata_defaults = get_option('c5_skin_defaults');
        }
        if ($skin_id != '') {
            $meta_values = get_post_custom($skin_id);
            $c5_skindata = array();
            foreach ($c5_skindata_defaults as $name => $value) {
                if (isset($meta_values[$name][0]) && $meta_values[$name][0] != '') {
                    if ($value[0] == 'background') {
                        $c5_skindata[$name] = unserialize($meta_values[$name][0]);
                    } else {
                        $c5_skindata[$name] = $meta_values[$name][0];
                    }
                } else {
                    $c5_skindata[$name] = $value[1];
                }
            }
        } else {
            foreach ($c5_skindata_defaults as $name => $value) {
                $c5_skindata[$name] = $value[1];
            }
        }


        $this->get_current_header($c5_skindata['header_default']);
        $this->get_current_footer($c5_skindata['footer_default']);
		
		
		if(isset($_POST['c5-preview-color']) && $_POST['c5-preview-color']!=''){
			$c5_skindata['primary_color'] = $_POST['c5-preview-color'];
			$c5_skindata['title_color'] = $_POST['c5-preview-color'];
		}
		
		if(isset($_POST['c5-layout-mode']) && $_POST['c5-layout-mode']!=''){
			$c5_skindata['layout_width']  = $_POST['c5-layout-mode'];
		}
		
		if(isset($_POST['c5-menu-mode']) && $_POST['c5-menu-mode']!=''){
			$c5_headerdata['header_menu_position'] = $_POST['c5-menu-mode'];
		}
		
		
		
        $layout_width = explode('-', $c5_skindata['layout_width']);
        
        
        $template_id = $this->get_current_template_id();
        
        $c5_skindata['template_id'] = $template_id;

        $GLOBALS['c5-main-width'] = $layout_width[0];
    }

    function get_current_header($header_id) {
        global $c5_headerdata;
        $c5_headerdata_defaults = get_option('c5_header_defaults');
        if (!is_array($c5_headerdata_defaults)) {
            $skin_obj = new C5_header();
            $c5_headerdata_defaults = get_option('c5_header_defaults');
        }
        if ($header_id != '') {
            $meta_values = get_post_custom($header_id);
            $c5_headerdata = array();

            foreach ($c5_headerdata_defaults as $name => $value) {
                if (isset($meta_values[$name][0]) && $meta_values[$name][0] != '') {
                    if ($value[0] == 'background') {
                        $c5_headerdata[$name] = unserialize($meta_values[$name][0]);
                    } else {
                        $c5_headerdata[$name] = $meta_values[$name][0];
                    }
                } else {
                    $c5_headerdata[$name] = $value[1];
                }
            }
        } else {
            foreach ($c5_headerdata_defaults as $name => $value) {
                $c5_headerdata[$name] = $value[1];
            }
        }
    }

    function get_current_footer($footer_id) {
        global $c5_footerdata;
        $c5_footer_defaults = get_option('c5_footer_defaults');
        if (!is_array($c5_footer_defaults)) {
            $skin_obj = new C5_footer();
            $c5_footer_defaults = get_option('c5_footer_defaults');
        }

        if ($footer_id != '') {
            $meta_values = get_post_custom($footer_id);
            $c5_footerdata = array();

            foreach ($c5_footer_defaults as $name => $value) {
                if (isset($meta_values[$name][0]) && $meta_values[$name][0] != '') {
                    if ($value[0] == 'background') {
                        $c5_footerdata[$name] = unserialize($meta_values[$name][0]);
                    } else {
                        $c5_footerdata[$name] = $meta_values[$name][0];
                    }
                } else {
                    $c5_footerdata[$name] = $value[1];
                }
            }
        } else {
            foreach ($c5_footer_defaults as $name => $value) {
                $c5_footerdata[$name] = $value[1];
            }
        }
    }

    function build_layout($source) {
        global $c5_skindata;
        global $c5_headerdata;
        ?>
        <div id="content">

            <div id="inner-content" class="c5-main-row clearfix">
            	<?php 
            	$layout = explode('-', $c5_skindata['layout_width']);
            	$total_width = $layout[0];
            	$GLOBALS['c5_total_width'] = $total_width;
            	
            	
            	
            	unset($layout[0]);
            	
            	
            	$padding = 30;
            	
            	$width = 0;
            	$big = 300;
            	$small = 160;
            	
            	foreach ($layout as $value) {
            		if ($value == 'S') {
            			$width = $width + $small + $padding;
            		}elseif($value == 'B') {
            			$width = $width + $big + $padding;
            		}
            	}
            	
            	$main_content = $total_width - $width;
            	
            	$GLOBALS['c5_content_width'] = $main_content;
            	
            	
            	

            	
            	foreach ($layout as $value) {
            		if($value == 'C'){
            			
            			
            			
            			$GLOBALS['c5_content_width'] = $main_content;
            			
            			$device = new C5AB_Mobile_Detect();
            			
            			if( $device->isMobile() && !$device->isTablet()){
            				$GLOBALS['c5_content_width'] = 420;
            			}
            			
            			if( $device->isTablet()){
            				$GLOBALS['c5_content_width']  = 708;
            			}
            			$this->get_breaking_news();
            			
            			$this->get_main_content($source);
            		}elseif ($value == 'S') {
            			?>
            			
            			<div id="small-sidebar" class="c5-single-element c5-sidebar-small-<?php echo $c5_skindata['layout_width'] ?>">
            				<?php
            				
            				if($c5_headerdata['header_menu_position'] == 'side'){
            					echo do_shortcode('[c5ab_menu location="'.$c5_headerdata['header_menu'].'" responsive="on" style="sidebar" bg_mode="light" ]');
            				
            				}
            				$GLOBALS['c5_content_width'] = 160;
            				 $this->get_sidebar($c5_skindata['small_sidebar']); ?>
            			</div>
            			<?php
            		}elseif($value == 'B') {
            			?>
            			
            			<div id="big-sidebar" class="c5-single-element c5-sidebar-big-<?php echo $c5_skindata['layout_width'] ?>">
            				<?php 
            				$GLOBALS['c5_content_width'] = 300;
            				$this->get_sidebar($c5_skindata['big_sidebar']); ?>
            			</div>
            			<?php
            		}
            	}
            	 ?>

            </div>

        </div>
        <?php
    }
    
    function get_sidebar($sidebar) {
    	?>
    	<div id="sidebar-<?php echo $sidebar ?>" class="c5-sidebar-wrap clearfix">
    	<?php
    	if ( is_active_sidebar( $sidebar ) ){
    		dynamic_sidebar( $sidebar );
    	}
    	?>
    	</div>
    	<?php
    }
    
    function get_main_content($source) {
    	
    	switch ($source) {
			case 'home':
				get_template_part( 'library/includes/templates/template-index');
				break;
			case 'page':
				get_template_part( 'library/includes/templates/template-page');
				break;
			case 'woocommerce':
				get_template_part( 'library/includes/templates/template-woocommerce');
				break;
			case 'single':
				get_template_part( 'library/includes/templates/template-single');
				break;
			case '404':
				get_template_part( 'library/includes/templates/template-404');
				break;
		
		}
    	
    }
    
    function get_breaking_news() {
    	global $c5_headerdata;
    	global $c5_skindata;
    	if($c5_headerdata['breaking_enable'] =='off' ){
    		return;
    	}
    	?>
    	
    	<div id="breaking-bar" class="c5-single-element c5-breaking-<?php echo $c5_skindata['layout_width'] ?>">
    		<div class="c5-breaking-wrap">
    			<?php
    			$layout  = explode('-', $c5_skindata['layout_width']);
    			
    			if(in_array('S', $layout)){
    				echo '<span class="fa fa-align-justify c5-sidebar-controller c5-small-controller c5-controller-'.$c5_skindata['layout_width'].'"></span>';
    			}
    			 $this->breaking_news();
    			 $this->nav_buttons();
    			
    			if(in_array('B', $layout)){
    				echo '<span class="fa fa-align-justify c5-sidebar-controller c5-big-controller c5-controller-'.$c5_skindata['layout_width'].'"></span>';
    			}?>
    		</div>
    		
    	</div>
    	<?php
    }
    
    function breaking_news() {
    	global $c5_headerdata;
    	
    	if($c5_headerdata['breaking_title']!=''){
    		echo '<p class="breaking-title">'.$c5_headerdata['breaking_title'].'</p>';
    	
    	
    	
    	}
    	if( is_array(unserialize($c5_headerdata['breaking_custom']) ) ){
    		$data = unserialize($c5_headerdata['breaking_custom']);
    		echo '<ul id="c5-webTicker">';
    		foreach ($data as $news) {
    			echo '<li>'.$news['title'].'</li>';
    		}
    		echo '</ul>';
    		return;
    	
    	}
    	$post_obj = new C5_post();
    	$atts = array(
    		'post_type'=>$c5_headerdata['breaking_post_type'],
    		'posts'=>$c5_headerdata['breaking_posts'],
    		'tag'=>$c5_headerdata['breaking_tag'],
    		'author'=>$c5_headerdata['breaking_author'],
    		'posts_per_page'=>$c5_headerdata['breaking_posts_per_page'],
    		'follow'=>$c5_headerdata['breaking_follow'],
    		'paging'=>'off',
    		'orderby'=>$c5_headerdata['breaking_orderby'],
    		'order'=>$c5_headerdata['breaking_order'],
    	);
    	
    	// The arguments
    	$args= $post_obj->handle_atts($atts);
    	// The Query
    	
    	$the_query = new WP_Query( $args );
    	
    	// The Loop
    	if ( $the_query->have_posts() ) {
    	        echo '<ul id="c5-webTicker">';
    		while ( $the_query->have_posts() ) {
    			$the_query->the_post();
    			echo '<li>';
    			
    			$tax = c5_get_post_tax(get_the_ID());
    			
    			$category_id = $post_obj->get_dominaiting_category();
    			if ($category_id) {
    			    $value = get_option('c5_term_meta_' . $tax . '_' . $category_id . '_skin');
    			    $icon = get_option('c5_term_meta_' . $tax . '_' . $category_id . '_icon');
    			    $color = '';
    			    if($this->skin_exist($value)){
    			    	$color = $this->get_color_from_skin($value);
    			    	$color = ' style="color:'.$color.';" ';
    			    }
    			    $term = get_term( $category_id, $tax );
    			    
    			    echo '<a class="c5-cat" href="'. get_term_link( intval($term->term_id), $tax ).'" '.$color.'><span class="'.$icon.'"></span>'.$term->name.'</a>';
    			}
    			
    			echo '<a href="'.get_permalink().'">' . get_the_title() . '</a></li>';
    		}
    	        echo '</ul>';
    	} else {
    		// no posts found
    	}
    	/* Restore original Post Data */
    	wp_reset_postdata();
    	
    	
    }
	
	
	function nav_buttons() {
		?>
			<div class="c5-breaking-nav">
				<?php
				 $next_post = get_next_post();
				 if (!empty( $next_post )):
				  ?>
				  <p class="shuffle-article"><a href="<?php echo get_permalink( $next_post->ID ); ?>" title="<?php _e('Next: ','code125') ?><?php echo $next_post->post_title; ?>" class="fa fa-angle-right"></a></p>
				   <?php endif; 
				    ?>
				<?php
				 $rand_posts = get_posts('numberposts=1&orderby=rand');
				 foreach( $rand_posts as $post3 ) :
				 ?>
				    <p class="shuffle-article"><a href="<?php echo get_permalink($post3->ID); ?>" title="<?php _e('Random Article','code125'); ?>" class="fa fa-random"></a></p>
				 <?php endforeach; ?>
				<?php
				$next_post = get_previous_post();
				if (!empty( $next_post )):
				 ?>
				 <p class="shuffle-article"><a href="<?php echo get_permalink( $next_post->ID ); ?>" title="<?php _e('Previous: ','code125') ?><?php echo $next_post->post_title; ?>" class="fa fa-angle-left"></a></p>
				<?php endif; 
				 ?>
			</div>
		<?php
	}
}
?>