<?php 

class C5_social_share_count {
	
	
	public $config = array(
		'services' => array(
			'facebook' => array('url' => "https://graph.facebook.com/fql?q=%s", 'params' => 'SELECT url,normalized_url,share_count,like_count,comment_count,total_count,click_count FROM link_stat WHERE url = "%s"'),
			'twitter' => array('url' => "http://urls.api.twitter.com/1/urls/count.json?url=%s"),
			'linkedin' => array('url' => "http://www.linkedin.com/countserv/count/share?url=%s"),
			'google' => array('url' => "https://clients6.google.com/rpc")
		)
	);
	
	public $wp_options = array(
		'services' => array('facebook' => 1, 'twitter' => 1, 'linkedin' => 1, 'google' => 1),
		'sync_frequency' => 3600, // - Frequency (in seconds) of update the social count; Defaults to one check per hour
		'active_sync' => 0, // - Whether the sync is active ( 1 or 0 ). Defaults to inactive
		'debug' => 1
	); 
	
	
	function __construct() {
		
	}
	
	
	
	
	function process(){	
		
		
		$services = $this->wp_options[ 'services' ];
		$debug = $this->wp_options[ 'debug' ];
		
		// The arguments
		$args= array(
			'post_type'=> 'any',
			'posts_per_page'=>-1
		
		);
		// The Query
		$the_query = new WP_Query( $args );
		
		// The Loop
		if ( $the_query->have_posts() ) {
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				$total_count = 0;
				foreach( $services as $service_name => $enabled ) {
					if( $enabled ) {
						$count = $this->get_count( get_permalink(), $service_name );
						$total_count =  $total_count + $count;
						if($debug == 0) {
							$this->update_post_meta( get_the_ID(), $service_name, $count );
						}
					}
				}
				
				$this->update_post_meta( get_the_ID(), 'c5_total_share', $total_count );
				$comment_count = $this->get_comment_count( get_permalink());
				$this->update_post_meta( get_the_ID(), 'c5_fb_comments_count', $comment_count );
			}
		}
		/* Restore original Post Data */
		wp_reset_postdata();
		
	}
	
	
	
	function get_comment_count($url) {
		$data  = json_decode(file_get_contents('https://graph.facebook.com/?ids=' . urlencode($url)));
		return $data->$url->comments;
		
	}
	
	
	
	
	function get_count( $permalink, $service ) 
	{
		
		if( $service === 'google' ) {
			return $this->do_curl( $permalink, $service );
		} else {
			// If there are extra params in the url, append them to the permalink first
			if( isset( $this->config['services'][$service]["params"] ) ) {
				$permalink = sprintf( $this->config['services'][$service]["params"], $permalink );
			}
			$url = sprintf( $this->config['services'][$service]["url"], urlencode ( $permalink ) );
			return $this->do_curl( $url, $service );
		}
	}
	
	
	function do_curl($url, $service) 
	{
		$social_count = 0;
		
		// Google+ is an special, hack-ish case
		if( $service == 'google' ) 
		{
			// GET +1s. Credits to Tom Anthony: http://www.tomanthony.co.uk/blog/google_plus_one_button_seo_count_api/
		    $curl = curl_init();
		    curl_setopt( $curl, CURLOPT_URL, "https://clients6.google.com/rpc" );
		    curl_setopt( $curl, CURLOPT_POST, 1 );
		    curl_setopt( $curl, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"' . $url . '","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]' );
		    curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
		    curl_setopt( $curl, CURLOPT_HTTPHEADER, array( 'Content-type: application/json' ) );
		    $curl_results = curl_exec ( $curl );
		    curl_close ( $curl );
		 
		    $json = json_decode($curl_results, true);
		    $social_count = intval( $json[0]['result']['metadata']['globalCounts']['count'] );
	    	
		} else {
		    $ch = curl_init();
		    curl_setopt ($ch, CURLOPT_URL, $url);
		    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
			$return = curl_exec( $ch );
		
			if( curl_errno( $ch ) ) { 
		        $error = print_r( curl_error( $ch ), true );
		        // TODO: Notify curl errors via email or log files 
			} else {
				switch( $service ) {
					case 'facebook':
						$return = json_decode( $return, true );
						$social_count = ( isset( $return['data'][0]['total_count'] ) ) ? $return['data'][0]['total_count'] : 0;
						// TODO: Better handling of errors	
						if( isset( $return['error'] ) ) { 
							log( "Error ".$return["code"]." (".$return["type"].") - ".$return["message"] );
						}
					break;
					
					case 'twitter':
						$return = json_decode( $return, true );
						$social_count = ( isset($return['count'] ) ) ? $return['count'] : 0;
					break;
					
					case 'linkedin':
						$return = json_decode( str_replace( 'IN.Tags.Share.handleCount(', '', str_replace( ');', '', $return ) ), true );
						$social_count = ( isset( $return['count'] ) ) ? $return['count'] : 0;
					break;
				}
			}
		}
		return intval( $social_count );
	}
	
	
	function update_post_meta( $post_id, $service, $count ) 
	{
		$key = 'c5_sc_'.$service;
		$old_count = get_post_meta( $post_id, $key, true);
		// Check if the previous value is smaller. If it is, do not update, it's probably an error from the cURL call to the API
		if($count<0){
			$count = 0;
		}
		if( $count > $old_count ) {
			update_post_meta( $post_id, ''.$service, $count );
		}
	}
	
}


add_action( 'wp',  'c5_sc_setup_schedule' );
/**
 * On an early action hook, check if the hook is scheduled - if not, schedule it.
 */
function c5_sc_setup_schedule() {
	if ( ! wp_next_scheduled( 'c5_sc_hourly_event' ) ) {
		wp_schedule_event( time(), 'hourly', 'c5_sc_hourly_event');
	}
}


add_action( 'c5_sc_hourly_event', 'c5_sc_do_this_hourly' );
/**
 * On the scheduled action hook, run a function.
 */
function c5_sc_do_this_hourly() {
	// do something every hour
	
	$sc_obj = new C5_social_share_count();
	
	$sc_obj->process();
}


 ?>