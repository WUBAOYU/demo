<?php

class C5_Article {

    function related_posts() {
        $post_obj = new C5_post();
        $settings_obj = new C5_theme_options();
        global $post;
        
        echo '<div class="c5-related-wrap clearfix">';
        $code = '[c5ab_title apperance="title-style-1" title="' . __('Related Articles', 'code125') . '" font_size="20" font_weight="300" transform="normal" class="" icon="fa fa-tags" link="" id="" ]';
        echo do_shortcode($code);

        $related_type = $settings_obj->get_meta_option('related_type');
        if ($GLOBALS['c5_content_width'] < 700) {
            $post_count = 3;
        } else {
            $post_count = 4;
        }
        $span = 12 / $post_count;
        $args = array(
            'post__not_in' => array($post->ID),
            'posts_per_page' => $post_count, // Number of related posts that will be shown.  
            'ignore_sticky_posts' => 1
        );
        if ($related_type == 'tags') {
            $tags = wp_get_post_tags($post->ID);

            if ($tags) {
                $tag_ids = array();
                foreach ($tags as $individual_tag) {
                    $tag_ids[] = $individual_tag->term_id;
                }
                $args['tag__in'] = $tag_ids;
            } else {
                $args['orderby'] = 'rand';
            }
        } elseif ($related_type == 'category') {
            $tax = c5_get_post_tax(get_the_ID());
            $cat = $post_obj->get_dominaiting_category();
            if ($tax = 'category') {
                $args['cat'] = $cat;
            } else {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => $tax,
                        'field' => 'id',
                        'terms' => $cat
                    )
                );
            }
        } else {
            $args['orderby'] = 'rand';
        }

        // The Query
        $the_query = new WP_Query($args);

        // The Loop
        if ($the_query->have_posts()) {
            $return = '<div class="row">';
            while ($the_query->have_posts()) {
                $the_query->the_post();

                $return .= '<div class="col-sm-' . $span . '">' . $post_obj->get_post_boxes() . '</div>';
            }
            $return .= '</div>';
            echo $return;
        }
        wp_reset_postdata();
        echo '</div>';
    }
    
    function comment_form() {
    	comments_template();
    	
    	
    	                $commenter = wp_get_current_commenter();
    	                $req = get_option('require_name_email');
    	                $aria_req = ( $req ? " aria-required='true'" : '' );
    	                $fields = array(
    	                    'author' => '<input id="author" name="author" class="element-block " type="text" value="' .
    	                    esc_attr($commenter['comment_author']) . '" size="30" tabindex="1" ' . $aria_req . ' placeholder="' . __('Name:', 'code125') . '"  />',
    	                    'email' => '<input id="email" name="email" class="element-block" type="text" value="' . esc_attr($commenter['comment_author_email']) . '" size="30" tabindex="2" ' . $aria_req . ' placeholder="' . __('Email:', 'code125') . '" />' .
    	                    '</label>',
    	                    'url' => '<input id="url" name="url" type="text" class="element-block " value="' . esc_attr($commenter['comment_author_url']) . '" size="30" tabindex="3"  placeholder="' . __('Website:', 'code125') . '" />' .
    	                    '</label >'
    	                );
    	
    	
    	
    	                $defaults = array(
    	                    'fields' => apply_filters('comment_form_default_fields', $fields),
    	                    'id_form' => 'commentform',
    	                    'id_submit' => 'submit',
    	                    'title_reply' => '<h3 class="title">' . __('POST A COMMENT.', 'code125') . '<span class="arrow"></span></h3>',
    	                    'comment_notes_after' => '',
    	                    'title_reply_to' => __('Leave a Reply to %s', 'code125'),
    	                    'cancel_reply_link' => __('Cancel reply', 'code125'),
    	                    'label_submit' => __('Post comment.', 'code125'),
    	                    'comment_field' => '<textarea id="comment"  placeholder="' . __('Message..', 'code125') . '" name="comment"  class="element-block  " tabindex="4" aria-required="true"></textarea>',
    	                    'comment_notes_before' => ''
    	                );
    	
    	                comment_form($defaults);
    }
    
    function facebook_comment_form() {
    	$settings_obj = new C5_theme_options();
    	$code = '[c5ab_title apperance="title-style-1" title="' . __('Facebook Comments', 'code125') . '" font_size="20" font_weight="300" transform="normal" class="" icon="fa fa-facebook" link="" id="" ]';
    	echo do_shortcode($code);
    	$facebook_color = $settings_obj->get_meta_option('facebook_color');
    	?>
    	<div class="fb-comments" data-href="<?php the_permalink(); ?>" data-width="<?php echo $GLOBALS['c5_content_width'] ?>" data-num-posts="5" data-colorscheme="<?php echo $facebook_color ?>"></div>
    	<?php
    }

}
?>