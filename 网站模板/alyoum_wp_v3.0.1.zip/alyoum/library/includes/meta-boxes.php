<?php
/**
 * Initialize the meta boxes. 
 */
add_action( 'admin_init', 'c5_custom_meta_boxes' );

/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types
 * in demo-theme-options.php.
 *
 * @return    void
 *
 * @access    private
 * @since     2.0
 */
function c5_custom_meta_boxes() {
  
   
   
   $args =array('show_ui'=> true);
  
  
   $post_types_no_page = array();
   $output = 'objects'; // names or objects
   
   $post_types = get_post_types( $args, $output );
   
   $exlude_array_no_page = array(
   		'attachment',
   		'skin',
   		'header',
   		'footer',
   		'page'
   );
   
   foreach ( $post_types  as $key => $post_type ) {
   	
   	if(!in_array($key,  $exlude_array_no_page) ){
   		$post_types_no_page[] = $key;
   	}
   }
   		
 
  
  $article_meta_array = array();
  $counter = 1;
  
  
  
  
  $stylings = array(
    'id'          => 'meta_styling',
    'title'       => 'Styling Settings',
    'desc'        => '',
    'pages'       => array('page'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
          'label' => 'Choose Page Skin',
          'id' => 'skin_default',
          'type' => 'custom-post-type-select',
          'desc' => 'Choose The Skin.',
          'std' => '',
          'rows' => '',
          'post_type' => 'skin',
          'taxonomy' => '',
          'class' => ''
      ),
      array(
        'label'       => 'Enable BreadCrumb',
        'id'          => 'breadcrumb',
        'type'        => 'on_off',
        'desc'        => 'Enable/Disable BreadCrumb for this Page',
        'std'         => 'on',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Enable Comments',
        'id'          => 'enable_comments',
        'type'        => 'on_off',
        'desc'        => 'Enable/Disable Comments for this Page',
        'std'         => 'off',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Login Required',
        'id'          => 'login_required',
        'type'        => 'on_off',
        'desc'        => 'Make this page Login Required',
        'std'         => 'off',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      
     )
  );
  
  $stylings2 = array(
    'id'          => 'meta_styling',
    'title'       => 'Styling Settings',
    'desc'        => '',
    'pages'       => $post_types_no_page,
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
          'label' => 'Choose The default Skin',
          'id' => 'posts_skin',
          'type' => 'custom-post-type-select',
          'desc' => 'Choose The Skin.',
          'std' => '',
          'rows' => '',
          'post_type' => 'skin',
          'taxonomy' => '',
          'class' => ''
      )
     )
  );
  
  $use_parent = ot_get_option('posts_styling');
  if ( isset($_GET['post']) && $use_parent=='on') {
  	
  	$id =$_GET['post'];
  	$post_type = get_post_type($id);
  	$tax = c5_get_post_tax($id);
  	$terms = wp_get_post_terms($id, $tax);
  	if(count($terms) != 0){
  		$options = array();
  		foreach ($terms as $term) {
  			$options[] = array(
  			  'label'       => $term->name,
  			  'value'       => $term->term_id
  			);
  		}
  		$cats = array(
  		  'id'          => 'category_styling',
  		  'title'       => 'Category Settings',
  		  'desc'        => '',
  		  'pages'       => $post_types_no_page,
  		  'context'     => 'normal',
  		  'priority'    => 'high',
  		  'fields'      => array(
  		    array(
  		        'label' => 'Choose Dominating Category',
  		        'id' => 'category_follow',
  		        'type' => 'select',
  		        'desc' => 'Choose Dominating Category for this post, the Article will follow this category in its styling settings.',
  		        'choices' => $options,
  		        'std' => '',
  		        'rows' => '',
  		        'post_type' => '',
  		        'taxonomy' => '',
  		        'class' => ''
  		    )
  		   )
  		);
  		  ot_register_meta_box( $cats );
  		
  	}
  }
  
  
  $meta_gallery_slider = array(
    'id'          => 'meta_gallery_slider',
    'title'       => 'Post Format Settings',
    'desc'        => '',
    'pages'       => $post_types_no_page,
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Enable Featured Media',
        'id'          => 'featured_media',
        'type'        => 'select',
        'desc'        => 'Enable/Disable Featured Media for this Article',
        'choices'     => array(
          array(
            'label'       => 'Default',
            'value'       => ''
          ),
          array(
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array(
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Video / Audio url',
        'id'          => 'meta_attachment',
        'type'        => 'text',
        'desc'        => 'Video url, we support "Youtube, Vimeo and Dailymotion" or Audio url we support "Audio and Soundcloud"',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
  	)
  );
  
  $meta_metro = array(
    'id'          => 'meta_metro',
    'title'       => 'Metro  Settings',
    'desc'        => '',
    'pages'       =>  $post_types_no_page,
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
     
  	array(
  	  'label'       => 'Metro View',
  	  'id'          => 'meta_metro',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro View of the Flip Card If you choosed Metro Elements.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Photo',
  	      'value'       => 'photo'
  	    ),
  	    array(
  	      'label'       => 'Details',
  	      'value'       => 'details'
  	    )
  	  ),
  	  'std'         => 'photo',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	),
  	array(
  	  'label'       => 'Metro View Size',
  	  'id'          => 'meta_metro_size',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro size of the element View.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Large',
  	      'value'       => 'large'
  	    ),
  	    array(
  	      'label'       => 'Medium',
  	      'value'       => 'medium'
  	    ),
  	    array(
  	      'label'       => 'Wide',
  	      'value'       => 'wide'
  	    ),
  	    array(
  	      'label'       => 'Tall',
  	      'value'       => 'tall'
  	    )
  	  ),
  	  'std'         => 'medium',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	),
  	)
  );

  
  
  
  
  
  $review = array(
    'id'          => 'meta_review',
    'title'       => 'Review Options',
    'desc'        => '',
    'pages'       => $post_types_no_page,
    'context'     => 'normal',
    'priority'    => 'low',
    'fields'      => array(
    array(
      'label'       => 'Reviews',
      'id'          => 'meta_reviews',
      'type'        => 'list-item',
      'desc'        => 'Add Reviews to your post.',
      'settings'    => array(
        array(
          'label'       => 'Rating Value',
          'id'          => 'rating',
          'type'        => 'numeric-slider',
          'desc'        => 'Add the rating Value From 0 to 100.',
          'std'         => '100',
          'min_max_step' => '0,100,1',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'class'       => ''
        )
        
      ),
      'std'         => '',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Rating Comment',
      'id'          => 'meta_review_comment',
      'type'        => 'textarea-simple',
      'desc'        => 'Comment about the Product you are reviewing.',
      'std'         => '',
      'rows'        => '5',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Review Type',
      'id'          => 'meta_review_type',
      'type'        => 'select',
      'desc'        => 'Select to Type of the review in this article?, Default: Stars.',
      'choices'     => array(
        array (
          'label'       => 'Stars',
          'value'       => 'stars'
        ),
       	array (
       	  'label'       => 'Percentage',
       	  'value'       => 'percentage'
       	),
       	array (
       	   'label'       => 'Points',
       	   'value'       => 'points'
        )
      ),
      'std'         => 'stars',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    )
    )
    ,
    'std'         => '',
    'rows'        => '',
    'post_type'   => '',
    'taxonomy'    => '',
    'class'       => ''
	
  
);







  
    
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
   
  ot_register_meta_box( $stylings );
  ot_register_meta_box( $stylings2 );
  ot_register_meta_box( $meta_metro );
  ot_register_meta_box( $meta_gallery_slider );
  
  
  
  
  
  
  

  

}
?>