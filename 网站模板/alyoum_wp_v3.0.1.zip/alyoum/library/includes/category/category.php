<?php 


class C5_terms {
	
	
	function __construct() {
		
		$this->hook();
	}
	
	function hook() {
		add_action ( 'edit_category_form_fields', array($this , 'edit_form'));
		add_action('edit_tag_form_fields' , array($this , 'edit_form'));
		
		
		//add_action ( 'edited_category', array($this , 'save_form'));
		add_action ( 'edited_terms', array($this , 'save_form'));
		
		add_action('show_user_profile', array($this, 'user_checboxes'));
		add_action('edit_user_profile', array($this, 'user_checboxes'));
		add_action('personal_options_update', array($this, 'user_save'));
		add_action('edit_user_profile_update', array($this, 'user_save'));
		
		
		add_action( 'admin_enqueue_scripts', array($this, 'css_load') );
		
	}
	
	function user_save($user_id) {
		if(!current_user_can('remove_users')){
			return;
		}
		if (!current_user_can('edit_user', $user_id)) {
		    return false;
		}
		update_user_meta($user_id, 'c5_term_meta_user_skin', $_POST['skin']  );
		update_user_meta($user_id, 'c5_term_meta_user_template', $_POST['template']  );
		update_user_meta($user_id, 'c5_term_meta_user_facebook', $_POST['facebook']  );
		update_user_meta($user_id, 'c5_term_meta_user_twitter', $_POST['twitter']  );
		update_user_meta($user_id, 'c5_term_meta_user_google_plus', $_POST['google_plus']  );
	}
	
	function user_checboxes($user) {
		if(!current_user_can('remove_users')){
			return;
		}
		
		?>
		<h3>AlYoum Theme related User Info</h3>
		<table class="form-table">
		<tr>
			<th><label for="facebook">Facebook username</label></th>
			<td><input type="text" name="facebook" id="facebook" value="<?php echo  get_the_author_meta('c5_term_meta_user_facebook', $user->ID)?>" class="regular-text"></td>
		</tr>
		<tr>
			<th><label for="twitter">Twitter username</label></th>
			<td><input type="text" name="twitter" id="twitter" value="<?php echo  get_the_author_meta('c5_term_meta_user_twitter', $user->ID)?>" class="regular-text"></td>
		</tr>
		<tr>
			<th><label for="google_plus">Google Plus username</label></th>
			<td><input type="text" name="google_plus" id="google_plus" value="<?php echo  get_the_author_meta('c5_term_meta_user_google_plus', $user->ID)?>" class="regular-text"></td>
		</tr>
		<?php
		
		$value = get_the_author_meta('c5_term_meta_user_skin', $user->ID);
		?>
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="skin">Skin:</label>
		    </th>
		    <td>
		    	<select name='skin' id='skin'>
		    		<?php  echo $this->get_skins($value); ?>
		    	</select>  
		     </td>
		</tr>
		<?php 
		$value = get_the_author_meta('c5_term_meta_user_template', $user->ID);
		 ?>
		
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="template">Template:</label>
		    </th>
		    <td>
		    	<select name='template' id='template'>
		    		<?php  echo $this->get_templates($value); ?>
		    	</select>  
		     </td>
		</tr>
		
		
		</table>
		<?php
		
		
	}
	
	function css_load($hook) {
	    if( 'edit-tags.php' != $hook )
	        return;
	     wp_enqueue_style( 'c5-admin-category-ui', C5_admin_UI_URL . 'css/category-admin-ui.css', false, '1.0.0' );
	     wp_enqueue_style( 'c5ab-font-awesome', C5BP_extra_uri . 'fonts/font-awesome-4.0.3/css/font-awesome.min.css');
	     wp_enqueue_script('c5ab-category-js', C5_admin_UI_URL . 'js/category-js.js', array(), '1.0', true);
	     
	}
	
	function save_form($term_id) {
		$array = array(
			'skin',
			'article_skin',
			'template',
			'icon'
		);
		if(isset($_POST['taxonomy'])){
			$tax = $_POST['taxonomy'];
			foreach ($array as  $value) {
				if(isset($_POST[$value])){
					update_option('c5_term_meta_' . $tax .'_'. $term_id .'_' . $value , $_POST[$value]);	
				}
			}
		}
	}
	
	function edit_form($term) {
		$tax = $_GET['taxonomy'];
		$term_id = $_GET['tag_ID'];
		$post_type = $_GET['post_type'];
		$value = get_option('c5_term_meta_' . $tax .'_'. $term_id .'_' . 'skin');
		?>
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="skin">Skin:</label>
		    </th>
		    <td>
		    	<select name='skin' id='skin'>
		    		<?php  echo $this->get_skins($value); ?>
		    	</select>  
		     </td>
		</tr>
		<?php
		
		if($tax != 'post_tag'){
		$value = get_option('c5_term_meta_' . $tax .'_'. $term_id .'_' . 'article_skin');
		?>
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="article_skin">Article Skin: </label>
		    </th>
		    <td>
		    	<select name='article_skin' id='article_skin'>
		    		<?php  echo $this->get_skins($value); ?>
		    	</select>  
		     </td>
		</tr>
		<?php
		}
		
		
		$value = get_option('c5_term_meta_' . $tax .'_'. $term_id .'_' . 'template');
		?>
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="template">Template:</label>
		    </th>
		    <td>
		    	<select name='template' id='template'>
		    		<?php  echo $this->get_templates($value); ?>
		    	</select>  
		     </td>
		</tr>
		<?php
		
		$value = get_option('c5_term_meta_' . $tax .'_'. $term_id .'_' . 'icon');
		?>
		<tr class="form-field">
		    <th scope="row" valign="top">
		    	<label for="icon">Icon:</label>
		    </th>
		    <td>
		    	<?php  echo $this->get_icons($value); ?>
		    	</td>
		</tr>
		<?php
	}
	
	function get_icons($value='') {
		$icons = new C5AB_ICONS();
		echo '<input type="hidden" name="icon" id="c5_icon" value="'.$value.'" />';
		echo '<ul class="c5-span-icons">';
		echo $icons->get_icons_spans($value);
		echo '</ul>';
		
	}
	
	function get_skins($value='') {
	    $skins = '';
		
		$selected = '';
		if($value == ''){
			$selected = 'selected="selected"';
		}
		$skins .= '<option value="" '.$selected.'>Default Skin</option>';
		
	    $query = new WP_Query(array('post_type' => 'skin', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish'));
	
	    /* has posts */
	    if ($query->have_posts()) {
	        while ($query->have_posts()) {
	            $query->the_post();
	            $selected = '';
	            $comp_value = get_the_ID();
	            if( $comp_value == $value){
	            	$selected = 'selected="selected"';
	            }
	            
	            $skins .= '<option value="'.$comp_value.'" '.$selected.'>'.get_the_title().'</option>';
	            
	        }
	    }
	    wp_reset_postdata();
	
	    return $skins;
	}
	
	function get_templates($value='') {
		$templates = '';
		$selected = '';
		if($value == ''){
			$selected = 'selected="selected"';
		}
		$skins .= '<option value="" '.$selected.'>Default Template</option>';
		
		foreach ($this->get_templates_list() as $key => $value2) {
			$selected = '';
			$comp_value = $key;
			if( $comp_value == $value){
				$selected = 'selected="selected"';
			}
			
			$skins .= '<option value="'.$comp_value.'" '.$selected.'>'.$value2.'</option>';
		}
		return $skins;
	}
	
	function update_templates_list() {
		$array = c5ab_get_option('post_types');
		$templates = array();
		if(is_array($array)){
			foreach($array as $type){
				$args = array(
					'post_type'=> $type,
					'posts_per_page'    => -1,
				);
				// The Query
				query_posts( $args );
				
				// The Loop
				while ( have_posts() ) : the_post();
				    $template = get_post_meta(get_the_ID(), 'c5ab_data', true);
				    if( is_array(@unserialize( base64_decode( $template) )) ){
				    	$templates[ get_the_ID() ] = get_the_title();
				    }
				endwhile;
				
				// Reset Query
				wp_reset_query();
			}
		}
		
		update_option('c5ab_templates' , $templates);
		
	}
	
	function get_templates_list() {
		$templates = get_option('c5ab_templates');
		if(!is_array($templates)){
			$this->update_templates_list();
			$templates = get_option('c5ab_templates');
		}
		return $templates;
		
	}
	
	
	
}

$term_obj = new C5_terms();

 ?>