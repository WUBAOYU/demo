<?php

class C5_post {

    function __construct() {
        
    }

    function hook() {

        add_action('wp_ajax_c5_get_full_post', array($this, 'quick_read'));
        add_action('wp_ajax_nopriv_c5_get_full_post', array($this, 'quick_read'));
    }

    function get_post_thumb_wide($atts) {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }

        $image_size = c5ab_generate_image_size($GLOBALS['c5_content_width'], round(0.5 * $GLOBALS['c5_content_width']), true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_tall_single ' . $class . ' clearfix"><div class="row">';



        if ($img_html != '') {
            $return .= '<div class="col-sm-6"><div class="c5-thumb-hover  clearfix">';

            if ($atts['show_hover'] != 'off') {
                $return .= '<div class="hover"><div class="half">';

                if ($atts['show_hover'] == 'view') {
                    $return .= '<span data-id="' . get_the_ID() . '" class="c5-view-article fa fa-eye"></span>';
                } elseif ($atts['show_hover'] == 'link') {
                    $return .= '<a href="' . get_permalink() . '" class="fa fa-link"></a>';
                }


                $return .= '</div></div>';
            }

            $return .= $img_html . '</div></div>';
        }

        $return .= '<div class="col-sm-6" ><div class="content ">';

        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);

        $return .= '<div class="clearfix" ></div>';

        $return .= '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength(200) . '</p>';

        $return .= '</div></div></div></article>';

        return $return;
    }

    function get_post_blog_1($atts) {

        $return = '';

        $class = '';
        $permalink = get_permalink();
        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }



        $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_blog_1_single ' . $class . ' clearfix">';
        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);



        $return .= $this->get_featured_media();

        $return .= '<div class="content ">';



        $return .= '<div class="clearfix" ></div>';

        $return .= '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength(600) . '</p>';
        $return .= '<div class="clearfix" ></div>';

        $return .= $this->get_read_more_button($permalink);

        $return .= '</div></article>';

        return $return;
    }

    function get_post_blog_3($atts) {

        $return = '';

        $class = '';
        $permalink = get_permalink();
        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }
        $test_width = $GLOBALS['c5_content_width'];

        if ($GLOBALS['c5_content_width'] < 700) {
            $GLOBALS['c5_content_width'] = floor(($GLOBALS['c5_content_width'] + 30) / 2);
        } elseif ($GLOBALS['c5_content_width'] < 1000) {
            $GLOBALS['c5_content_width'] = floor(($GLOBALS['c5_content_width'] + 30) / 3);
        } else {
            $GLOBALS['c5_content_width'] = floor(($GLOBALS['c5_content_width'] + 30) / 4);
        }


        $return .= '<article  class="c5ab_post_thumb element c5ab_posts_thumb_blog_3_single ' . $class . ' clearfix">';
        $return .= '<div class="c5-inner"><h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);



        $return .= $this->get_featured_media();

        $return .= '<div class="content ">';



        $return .= '<div class="clearfix" ></div>';

        $return .= '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength(200) . '</p>';
        $return .= '<div class="clearfix" ></div>';

        $return .= $this->get_read_more_button($permalink);

        $return .= '</div></div></article>';

        $GLOBALS['c5_content_width'] = $test_width;
        return $return;
    }

    function get_post_blog_2($atts) {

        $return = '';

        $class = '';
        $permalink = get_permalink();
        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }



        $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_blog_1_single ' . $class . ' clearfix">';

        $return .= '<div class="row">';

        $width = round(($GLOBALS['c5_content_width'] + 30) / 3 - 30);

        $image_size = c5ab_generate_image_size($width, $width, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);
        if ($img_html != '') {
            $return .= '<div class="col-sm-4"><div class="c5-thumb-hover  clearfix">';

            if ($atts['show_hover'] != 'off') {
                $return .= '<div class="hover"><div class="half">';

                if ($atts['show_hover'] == 'view') {
                    $return .= '<span data-id="' . get_the_ID() . '" class="c5-view-article fa fa-eye"></span>';
                } elseif ($atts['show_hover'] == 'link') {
                    $return .= '<a href="' . get_permalink() . '" class="fa fa-link"></a>';
                }


                $return .= '</div></div>';
            }

            $return .= '<a href="' . get_permalink() . '">' . $img_html . '</a>';

            $return .= '</div></div><div class="col-sm-8">';
        } else {
            $return .= '<div class="col-sm-12">';
        }

        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);



        $return .= '<div class="content ">';



        $return .= '<div class="clearfix" ></div>';

        $return .= '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength(200) . '</p>';

        $return .= '</div></div>';

        $return .= '</div></article>';

        return $return;
    }

    function get_post_titles($atts) {

        $return = '';




        $return .= '<article  class="c5ab_post_thumb element c5ab_posts_thumb_titles_single  clearfix">';
        if (is_rtl()) {
            $icon = 'fa fa-arrow-circle-o-left';
        } else {
            $icon = 'fa fa-arrow-circle-o-right';
        }

        $return .= '<span class="' . $icon . '"></span><a href="' . get_permalink() . '">' . get_the_title() . '</a>';

        $return .= '</article>';


        return $return;
    }

    function get_featured_media() {
        $data = '';
        $width = $GLOBALS['c5_content_width'];
        $height = round($width * 9 / 16);

        $min_height = $height + 60;
        $format = get_post_format();

        if ($format == 'gallery') {
            if (!is_single()) {
                $data.= '<div class="clearfix" style="min-height:' . $min_height . 'px;">' . get_post_gallery() . '</div>';
            }
        } elseif ($format == 'video') {
            $meta_attachment = get_post_meta(get_the_ID(), 'meta_attachment', true);
            $data .= do_shortcode('[c5ab_video url="' . $meta_attachment . '" width="100%" height="' . $height . '" ]');
        } elseif ($format == 'audio') {
            $meta_attachment = get_post_meta(get_the_ID(), 'meta_attachment', true);
            $data .= do_shortcode('[c5ab_audio url="' . $meta_attachment . '" ]');
        } else {
            if (is_single()) {
                $image_size = c5ab_generate_image_size($width, 99999, false);
            } else {
                $image_size = c5ab_generate_image_size($width, $height, true);
            }
            $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);
            if ($img_html != '') {
                $data .= '<div class="c5-thumb-hover  clearfix">';
                if (is_single()) {
                    $data .= $img_html;
                } else {
                    $data .= '<a href="' . get_permalink() . '">' . $img_html . '</a>';
                }

                $data .= '</div>';
            }
        }



        return $data;
    }

    function get_post_thumb_photos($atts, $size) {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }

        $image_size = c5ab_generate_image_size($size, $size, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);

        if ($img_html != '') {
            $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_photo_single ' . $class . ' clearfix">';
            $return .= '<div class="c5-thumb-hover  clearfix">';

            if ($atts['show_hover'] != 'off') {
                $return .= '<div class="hover"><div class="half">';

                if ($atts['show_hover'] == 'view') {
                    $return .= '<span data-id="' . get_the_ID() . '" class="c5-view-article fa fa-eye"></span>';
                } elseif ($atts['show_hover'] == 'link') {
                    $return .= '<a href="' . get_permalink() . '" class="fa fa-link"></a>';
                }


                $return .= '</div></div>';
            }

            $return .= $img_html . '</div>';

            $return .= '</article>';
        }


        return $return;
    }

    function get_post_thumb_tall($atts) {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }

        $image_size = c5ab_generate_image_size($GLOBALS['c5_content_width'], round(0.67 * $GLOBALS['c5_content_width']), true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_tall_single ' . $class . ' clearfix">';



        if ($img_html != '') {
            $return .= '<div class="c5-thumb-hover  clearfix">';

            if ($atts['show_hover'] != 'off') {
                $return .= '<div class="hover"><div class="half">';

                if ($atts['show_hover'] == 'view') {
                    $return .= '<span data-id="' . get_the_ID() . '" class="c5-view-article fa fa-eye"></span>';
                } elseif ($atts['show_hover'] == 'link') {
                    $return .= '<a href="' . get_permalink() . '" class="fa fa-link"></a>';
                }


                $return .= '</div></div>';
            }

            $return .= $img_html . '</div>';
        }

        $return .= '<div class="content ">';

        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);

        $return .= '<div class="clearfix" ></div>';

        $return .= '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength(200) . '</p>';

        $return .= '</div></article>';

        return $return;
    }

    function get_post_boxes_wide($atts) {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }
        if ($GLOBALS['c5_content_width'] > 480) {
            $width = round(($GLOBALS['c5_content_width'] + 30) * 2 / 3) - 30;
            $height = round(($GLOBALS['c5_content_width'] + 30) / 3) - 30;
        } else {
            $width = $GLOBALS['c5_content_width'];
            $height = $GLOBALS['c5_content_width'];
        }
        $image_size = c5ab_generate_image_size($width, $height, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class=" c5ab_posts_thumb_boxes_single ' . $class . ' clearfix">';

        $return .= '<div class="c5-boxes-thumb-hover  clearfix">';

        $return .= $img_html . '</div>';


        $return .= '<div class="box-content ">';

        $return .= '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';

        $return .= '</div></article>';

        return $return;
    }

    function get_post_boxes() {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }

        if ($GLOBALS['c5_content_width'] > 480) {
            $width = round(($GLOBALS['c5_content_width'] + 30) / 3) - 30;
        } else {
            $width = $GLOBALS['c5_content_width'];
        }


        $image_size = c5ab_generate_image_size($width, $width, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class=" c5ab_posts_thumb_boxes_single ' . $class . ' clearfix">';


        $return .= '<div class="c5-boxes-thumb-hover  clearfix">';

        $return .= $img_html . '</div>';


        $return .= '<div class="box-content ">';

        $return .= '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';

        $return .= '</div></article>';

        return $return;
    }

    function get_post_metro() {

        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }
        $element_id = $this->get_unique_id();

        $layout = get_post_meta(get_the_ID(), 'meta_metro', true);
        if ($layout == '') {
            $layout = 'photo';
        }
        $size = get_post_meta(get_the_ID(), 'meta_metro_size', true);
        if ($size == '') {
            $size = 'medium';
        }
        if ($GLOBALS['c5_content_width'] < 350) {
            $single_width = $GLOBALS['c5_content_width'];
        } elseif ($GLOBALS['c5_content_width'] < 700) {
            $single_width = floor($GLOBALS['c5_content_width'] / 3);
        } elseif ($GLOBALS['c5_content_width'] < 1000) {
            $single_width = floor($GLOBALS['c5_content_width'] / 4);
        } else {
            $single_width = floor($GLOBALS['c5_content_width'] / 5);
        }


        switch ($size) {
            case 'large':
                $width = 2 * $single_width;
                $height = 2 * $single_width;
                break;
            case 'medium':
                $width = $single_width;
                $height = $single_width;
                break;
            case 'wide':
                $width = 2 * $single_width;
                $height = $single_width;
                break;
            case 'tall':
                $width = $single_width;
                $height = 2 * $single_width;
                break;
        }


        $image_size = c5ab_generate_image_size($width, $height, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class="flip-post element ' . $size . ' ' . $class . '  flip-post-' . $element_id . ' c5ab_posts_thumb_metro_single clearfix">';
        $return .= '<style>.flip-post-' . $element_id . '{width:' . $width . 'px;height:' . $height . 'px;}</style>';
        $return .= '<div class="flip-wrap">';

        if ($layout == 'photo') {
            $return .= '<div class="post-front">' . $img_html . '</div>';
            $return .= '<div class="post-back post-data-bg"><div class="post-back-wrap">';

            $return .= '<a class="cat-link" href="' . get_term_link(intval($cat_id), $tax) . '"><span class="' . get_option('c5_term_meta_' . $tax . '_' . $cat_id . '_icon') . '"></span></a>';

            $return .= '<a class="title-link" href="' . get_permalink() . '">' . get_the_title() . '</a>';


            $return .= '</div></div>';
        } else {
            $return .= '<div class="post-front post-data-bg"><div class="post-back-wrap">';

            $return .= '<a class="cat-link" href="' . get_term_link(intval($cat_id), $tax) . '"><span class="' . get_option('c5_term_meta_' . $tax . '_' . $cat_id . '_icon') . '"></span></a>';



            $return .= '<a class="title-link" href="' . get_permalink() . '">' . get_the_title() . '</a>';
            $return .= '</div></div><div class="post-back">';
            $return .= '<a  href="' . get_permalink() . '">' . $img_html . '</a></div>';
        }



        $return .= '</div></article>';

        return $return;
    }

    function get_post_carousel() {

        $return = '';

        $class = '';
        $element_id = $this->get_unique_id();
        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }


        $layout = get_post_meta(get_the_ID(), 'meta_metro', true);
        if ($layout == '') {
            $layout = 'photo';
        }
        $size = 'medium';

        if ($GLOBALS['c5_content_width'] < 350) {
            $single_width = $GLOBALS['c5_content_width'];
        } elseif ($GLOBALS['c5_content_width'] < 700) {
            $single_width = floor($GLOBALS['c5_content_width'] / 3);
        } elseif ($GLOBALS['c5_content_width'] < 1000) {
            $single_width = floor($GLOBALS['c5_content_width'] / 4);
        } else {
            $single_width = floor($GLOBALS['c5_content_width'] / 5);
        }



        $width = $single_width;
        $height = $single_width;


        $image_size = c5ab_generate_image_size($width, $height, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);


        $return .= '<article  class="flip-post element ' . $size . ' ' . $class . '  flip-post-' . $element_id . ' c5ab_posts_thumb_metro_single clearfix">';
        $return .= '<style>.flip-post-' . $element_id . '{width:' . $width . 'px;height:' . $height . 'px;}</style>';
        $return .= '<div class="flip-wrap">';

        if ($layout == 'photo') {
            $return .= '<div class="post-front">' . $img_html . '</div>';
            $return .= '<div class="post-back post-data-bg"><div class="post-back-wrap">';

            $return .= '<a class="cat-link" href="' . get_term_link(intval($cat_id), $tax) . '"><span class="' . get_option('c5_term_meta_' . $tax . '_' . $cat_id . '_icon') . '"></span></a>';

            $return .= '<a class="title-link" href="' . get_permalink() . '">' . get_the_title() . '</a>';


            $return .= '</div></div>';
        } else {
            $return .= '<div class="post-front post-data-bg"><div class="post-back-wrap">';

            $return .= '<a class="cat-link" href="' . get_term_link(intval($cat_id), $tax) . '"><span class="' . get_option('c5_term_meta_' . $tax . '_' . $cat_id . '_icon') . '"></span></a>';



            $return .= '<a class="title-link" href="' . get_permalink() . '">' . get_the_title() . '</a>';
            $return .= '</div></div><div class="post-back">';
            $return .= '<a  href="' . get_permalink() . '">' . $img_html . '</a></div>';
        }



        $return .= '</div></article>';

        return $return;
    }

    function get_post_slide($atts) {
        $return = '';

        $return .= '<li>';
        $permalink = get_permalink();
        $image_size = c5ab_generate_image_size($GLOBALS['c5_content_width'], $atts['height'], true);


        $return .= get_the_post_thumbnail(get_the_ID(), $image_size);

        $return .= '<div class="content ">';

        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';

        $return .= '<div class="slide_rest  clearfix">';

        $return .= $this->get_metadata($atts);

        $return .= '<div class="clearfix" ></div>';

        $return .= $this->get_excerpt($atts, 200);

        $return .= '<div class="clearfix" ></div>';

        $return .= $this->get_read_more_button($permalink);

        $return .= '</div></div></li>';

        return $return;
    }

    function get_post_thumb($atts) {
        $return = '';

        $class = '';

        $cat_id = $this->get_dominaiting_category();
        if ($cat_id) {
            $tax = c5_get_post_tax(get_the_ID());
            $class = $tax . '-' . $cat_id;
        }

        $image_size = c5ab_generate_image_size(100, 100, true);
        $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);

        if ($img_html != '') {
            $class .= ' has-thumb';
        }

        $return .= '<article  class="c5ab_post_thumb c5ab_posts_thumb_single ' . $class . ' clearfix">';



        if ($img_html != '') {
            $return .= '<div class="c5-thumb-hover clearfix">';

            if ($atts['show_hover'] != 'off') {
                $return .= '<div class="hover"><div class="half">';

                if ($atts['show_hover'] == 'view') {
                    $return .= '<span data-id="' . get_the_ID() . '" class="c5-view-article fa fa-eye"></span>';
                } elseif ($atts['show_hover'] == 'link') {
                    $return .= '<a href="' . get_permalink() . '" class="fa fa-link"></a>';
                }


                $return .= '</div></div>';
            }

            $return .= $img_html . '</div>';
        }

        $return .= '<div class="content ">';

        $return .= '<h3 class=""><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';


        $return .= $this->get_metadata($atts);

        $return .= '<div class="clearfix" ></div>';

        $return .= '</div></article>';

        return $return;
    }

    function get_dominating_color() {
        $category_id = get_post_meta(get_the_ID(), 'category_follow', true);
        if ($category_id != '') {
            return $category_id;
        }

        $tax = c5_get_post_tax(get_the_ID());
        $terms = wp_get_post_terms(get_the_ID(), $tax);
        if (count($terms) != 0) {
            $category_id = $terms[0]->term_id;
        }
        if ($category_id != '') {
            $skin = get_option('c5_term_meta_' . $tax . '_' . $category_id . '_skin');
            $skin_obj = new C5_skin_functions();
            if ($skin_obj->skin_exist($skin)) {
                $color = $skin_obj->get_color_from_skin($skin);
                return $color;
            }
        }

        global $c5_skindata;
        if (isset($c5_skindata['primary_color'])) {
            return $c5_skindata['primary_color'];
        }
        return '';
    }

    function get_dominaiting_category() {
        $category_id = get_post_meta(get_the_ID(), 'category_follow', true);
        if ($category_id != '') {
            return $category_id;
        }

        $tax = c5_get_post_tax(get_the_ID());
        $terms = wp_get_post_terms(get_the_ID(), $tax);
        if (count($terms) != 0) {
            $category_id = $terms[0]->term_id;
            return $category_id;
        }
        return false;
    }

    function get_title($atts) {
        if ($atts['show_title'] != 'on') {
            return '';
        }
        $post_type = explode('#', $atts['post_type']);
        $code = '';
        if (count($post_type) == 3) {
            $term = get_term($post_type[2], $post_type[1]);
            //$code = '<h3 class="title '.$post_type[1] .'-'.$post_type[2].'"><a href="'.get_term_link(intval($term->term_id),$post_type[1]).'"><span class="'.get_option('c5_term_meta_' . $post_type[1] . '_' . $term->term_id . '_icon').'"></span>'.$term->name.'</a></h3>';

            $code = '[c5ab_title apperance="title-style-1" title="' . $term->name . '" font_size="20" font_weight="300" transform="normal" class="' . $post_type[1] . '-' . $post_type[2] . '" icon="' . get_option('c5_term_meta_' . $post_type[1] . '_' . $term->term_id . '_icon') . '" link="' . get_term_link(intval($term->term_id), $post_type[1]) . '" id="" ]';
        }

        return do_shortcode($code);
    }

    function show_meta($atts, $element) {
        if (isset($atts[$element]) && $atts[$element] != 'off') {
            return true;
        }
        return false;
    }

    function get_metadata($atts) {

        $meta_data = '<ul class="c5_meta_data  clearfix">';

        if ($this->show_meta($atts, 'show_cat')) {
            //Category
            $cats = $this->get_meta_categories();
            $meta_data .= '<li class="c5-meta-li-cat">' . $cats . '</li>';
        }

        if ($this->show_meta($atts, 'show_author')) {
            //Author
            $author = $this->get_meta_author();
            $meta_data .= '<li class="c5-meta-li-author">' . $author . '</li>';
        }

        if ($this->show_meta($atts, 'show_date')) {
            //Date
            $date = $this->get_meta_date($atts['show_date']);
            $meta_data .= '<li class="c5-meta-li-date">' . $date . '</li>';
        }

        if ($this->show_meta($atts, 'show_comment')) {
            //Comment
            $comment = $this->get_meta_comment_count();
            $meta_data .= '<li class="c5-meta-li-comment">' . $comment . '</li>';
        }

        if ($this->show_meta($atts, 'show_likes')) {
            //Likes
            $likes = $this->get_meta_likes_count();
            $meta_data .= '<li class="c5-meta-li-like">' . $likes . '</li>';
        }

        if ($this->show_meta($atts, 'show_views')) {
            //Views
            $views = $this->get_meta_views_count();
            $meta_data .= '<li class="c5-meta-li-views">' . $views . '</li>';
        }


        if ($this->show_meta($atts, 'show_social')) {
            //Social
            $social = $this->get_meta_social_count();
            $meta_data .= '<li class="c5-meta-li-social">' . $social . '</li>';
        }

        if ($this->show_meta($atts, 'show_rating')) {
            //Rating
            $rating = $this->get_meta_rating();
            $meta_data .= '<li class="c5-meta-li-rating">' . $rating . '</li>';
        }




        $meta_data .= '</ul>';


        return $meta_data;
    }

    function get_block_metadata() {
        $user_ID = get_the_author_meta('ID');
        $facebook_user = get_the_author_meta('c5_term_meta_user_facebook', $user_ID);
        $twitter_user = get_the_author_meta('c5_term_meta_user_twitter', $user_ID);
        $google_plus_user = get_the_author_meta('c5_term_meta_user_google_plus', $user_ID);
        $format = get_post_format();
        $settings_obj = new C5_theme_options();
        $meta_options = $settings_obj->get_meta_options();

        $data = '<div class="row">';

        $data .= '<div class="col-sm-5">';
        $data .= '<div class="c5-author-meta-wrap">';
        $data .= '<div class="c5-author-img">' . get_avatar($user_ID, '200', '', '<span class="fa fa-user"></span>') . '</div>';

        $data .= '<div class="c5-author-data"><a class="url fn" href="' . get_author_posts_url($user_ID) . '">' . get_the_author_meta('display_name') . '</a>';

        if ($twitter_user != '') {
            $data .= '<div class=""><a href="https://twitter.com/' . $twitter_user . '" class="twitter-follow-button" data-show-count="false" data-show-screen-name="false">Follow @' . $twitter_user . '</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div>';
        }

        if ($facebook_user != '') {
            $data .= '<div class="float_left_fb"><div class="fb-follow" data-href="http://www.facebook.com/' . $facebook_user . '" data-width="100px" data-height="24px" data-colorscheme="light" data-layout="button_count" data-show-faces="false"></div></div>';
        }

        if ($google_plus_user != '') {
            $data .= '<div class="float_left_gp">
            <div class="g-follow" data-annotation="bubble" data-height="20" data-href="http://plus.google.com/+' . $google_plus_user . '" data-rel="author"></div>
            
            </div>';
        }

        $data .= '</div>';

        $data .= '</div>';
        $data .= '</div>';

        $data .= '<div class="col-sm-5">';
        $data .= '<div class="c5-author-meta-wrap">';
        $data .= '<div class="c5-author-img">';
        //
        if (!post_password_required()) {
            if ($format == 'video') {
                $data .= '<span class="list-icon fa fa-video-camera"></span>';
            } elseif ($format == 'audio') {
                $data .= '<span class="list-icon fa fa-music"></span>';
            } elseif ($format == 'gallery') {
                $data .= '<span class="list-icon  fa fa-picture-o"></span>';
            } else {
                $image_size = c5ab_generate_image_size(320, 200, true);
                $the_post_thumbnail = get_the_post_thumbnail(get_the_ID(), $image_size);
                if ($the_post_thumbnail != '') {
                    $data .= '<span class="list-icon  fa fa-picture-o"></span>';
                } else {
                    $data .= '<span class="list-icon  fa fa-pencil"></span>';
                }
            }
        } else {
            $data .= '<span class="list-icon fa fa-lock"></span>';
        }
        $data .= '</div><div class="c5-author-data">';

        $c5_date_format = $settings_obj->get_meta_option('c5_date_format');
        $data .= $this->get_meta_date($c5_date_format);

        $data .= '<div class="clearfix"></div>';

        $data .= $this->get_meta_comment_count();

        $data .= '<div class="clearfix"></div>';

        $data .= $this->get_meta_categories();

        $data .= '<div class="clearfix"></div>';

        $data .= $this->get_meta_views_count();



        $data .= '</div></div>';


        $data .= '</div>';

        $data .= '<div class="col-sm-2">';

        $data .= '<div class="c5-likes-wrap">' . $this->get_meta_likes_count() . '</div>';

        $data .= '</div>';

        $data .= '</div>';


        return $data;
    }

    function custom_number_format($n) {

        $precision = 1;

        if ($n < 1000) {
            $n_format = round($n);
        } else if ($n < 1000000) {
            $n_format = round($n / 1000, $precision) . 'K';
        } else {
            $n_format = round($n / 1000000, $precision) . 'M';
        }

        return $n_format;
    }

    function get_read_more_button($permalink) {

        $color = $this->get_dominating_color();

        if ($color == '') {
            $color = '#d64a2b';
        }
        $icon = 'fa fa-angle-right';
        $align = 'right';
        if (is_rtl()) {
            $icon = 'fa fa-angle-left';
            $align = 'left';
        }
        $button = do_shortcode('[c5ab_button text="' . __('Read More', 'code125') . '" link="' . $permalink . '" icon="' . $icon . '" font_size="12" font_weight="300" button_class="" float="' . $align . '" button_text_color="#1f1f1f" button_text_hover_color="#f6f6f6" button_bg_color="#f6f6f6" button_bg_hover_color="' . $color . '" ]');

        return $button;
    }

    function get_excerpt($atts, $charlength = 600) {
        if ($this->show_meta($atts, 'show_excerpt')) {
            return '<p class="c5-excerpt">' . $this->get_the_excerpt_max_charlength($charlength) . '</p>';
        }
        return '';
    }

    function get_the_excerpt_max_charlength($charlength) {
        $excerpt = get_the_excerpt();
        $excerpt = strip_tags($excerpt);
        $data = '';
        $charlength++;

        if (mb_strlen($excerpt) > $charlength) {
            $subex = mb_substr($excerpt, 0, $charlength - 5);
            $exwords = explode(' ', $subex);
            $excut = - ( mb_strlen($exwords[count($exwords) - 1]) );
            if ($excut < 0) {
                $data .= mb_substr($subex, 0, $excut);
            } else {
                $data .= $subex;
            }
        } else {
            $data .= $excerpt;
        }

        return $data;
    }

    function get_pagination($atts, $the_query) {
        if ($atts['paging'] == 'off') {
            return;
        }

        $bignum = 999999999;
        if ($the_query->max_num_pages <= 1)
            return;

        $data = '<nav class="c5-pagination">';

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }


        $prev_text = '<span class="fa fa-chevron-left"></span>';
        $next_text = '<span class="fa fa-chevron-right"></span>';
        if (is_rtl()) {
            $prev_text = '<span class="fa fa-chevron-right"></span>';
            $next_text = '<span class="fa fa-chevron-left"></span>';
        }

        $data .= paginate_links(array(
            'base' => str_replace($bignum, '%#%', esc_url(get_pagenum_link($bignum))),
            'format' => '',
            'current' => $paged,
            'total' => $the_query->max_num_pages,
            'prev_text' => $prev_text,
            'next_text' => $next_text,
            'type' => 'list',
            'end_size' => 3,
            'mid_size' => 3
        ));

        $data .= '</nav>';
        return $data;
    }

    function get_meta_social_count() {

        $count = get_post_meta(get_the_ID(), 'c5_total_share', true);
        if ($count == '') {
            $count = 0;
        }

        $output = '<span class="fa fa-share"></span><span class="c5-social-count">' . $this->custom_number_format($count) . '</span>';
        return $output;
    }

    function get_meta_rating() {

        $meta_reviews = get_post_meta(get_the_ID(), 'meta_reviews', true);
        $total_count = 0;
        $rating = 0;
        if (is_array($meta_reviews)) {
            foreach ($meta_reviews as $review) {
                $rating = $rating + $review['rating'];
                $total_count++;
            }
        }
        if ($total_count > 0) {
            $count = round($rating / $total_count);
            $output = '<div class="c5-rating-view-wrap">' . c5_review_stars($count);



            $output .= '</div>';
            return $output;
        } else {
            return '';
        }
    }

    function get_meta_views_count() {

        $count = get_post_meta(get_the_ID(), 'post_views_count', true);
        if ($count == '') {
            $count = 0;
        }

        $output = '<span class="fa fa-eye"></span><span class="c5-views">' . $this->custom_number_format($count) . '</span>';
        return $output;
    }

    function get_meta_likes_count() {
        $vote_count = get_post_meta(get_the_ID(), "votes_count", true);
        if ($vote_count == '') {
            $vote_count = 0;
        }

        $output = '<span class="c5-post-like" data-post_id="' . get_the_ID() . '" title="' . __('like', 'code125') . '"><span class="fa fa-heart"></span><span class="count">' . $this->custom_number_format($vote_count) . '</span></span>';

        return $output;
    }

    function get_meta_comment_count() {
        $count = get_comments_number(get_the_ID());

        $fb_count = get_post_meta(get_the_ID(), 'c5_fb_comments_count', true);

        if ($fb_count == '') {
            $fb_count = 0;
        }
        $total = $count + $fb_count;

        if ($total == 0) {
            $comment = __('No Comment', 'code125');
        } elseif ($total == 1) {
            $comment = __('One Comment', 'code125');
        } else {
            $comment = $total . ' ' . __('Comments', 'code125');
        }

        return '<span class=""><span class="fa fa-comment"></span>' . $comment . '</span>';
    }

    function get_meta_date($choice) {
        $data = '';
        if ($choice == 'date_time') {
            $date = get_the_time(get_option('date_format') . ' ' . get_option('time_format'));
        } elseif ($choice == 'date') {
            $date = get_the_time(get_option('date_format'));
        } elseif ($choice == 'time') {
            $date = get_the_time(get_option('time_format'));
        } elseif ($choice == 'ago') {
            $date = sprintf(__('%s ago', 'code125'), human_time_diff(get_the_time('U'), current_time('timestamp')));
        } else {
            return '';
        }

        $return = '<time class="value updated" datetime="' . get_the_time('Y-m-d') . '"><span class="fa fa-calendar"></span>' . $date . '</time>';
        return $return;
    }

    function get_meta_author() {
        return '<a class="url fn" href="' . get_author_posts_url(get_the_author_meta('ID')) . '"><span class="fa fa-user"></span>' . get_the_author_meta('display_name') . '</a>';
    }

    function get_meta_categories() {
        $tax = c5_get_post_tax(get_the_ID());
        $terms = wp_get_post_terms(get_the_ID(), $tax);
        $data = '';
        if (count($terms) != 0) {
            foreach ($terms as $term) {
                $icon = get_option('c5_term_meta_' . $tax . '_' . $term->term_id . '_icon');
                if ($icon != '') {
                    $icon = '<span class="' . $icon . '"></span>';
                } else {
                    $icon = '<span class="fa fa-tag"></span>';
                }
                $data .= '<a href="' . get_term_link(intval($term->term_id), $tax) . '" class="c5-meta-cat c5-' . $tax . '-' . $term->term_id . '">' . $icon . $term->name . '</a>';
            }
        }
        return $data;
    }

    function handle_atts($atts) {

        $default_atts = array(
            'post_type' => 'post',
            'posts' => '',
            'tag' => '',
            'author' => '',
            'posts_per_page' => '10',
            'follow' => 'off',
            'paging' => 'off',
            'orderby' => 'date',
            'order' => 'DESC',
        );
        foreach ($default_atts as $key => $value) {
            if (!isset($atts[$key])) {
                $atts[$key] = $default_atts[$key];
            }
        }
        $args = array();

        $post_type = explode('#', $atts['post_type']);
        $args['post_type'] = $post_type[0];

        if ($atts['posts'] != '') {
            $args['post__in'] = explode(',', $atts['posts']);
            return $args;
        }


        if (isset($post_type[1])) {
            if ($post_type[1] == 'category') {
                $args['cat'] = $post_type[2];
            } else {
                $args['tax_query'] = array(
                    'taxonomy' => $post_type[1],
                    'field' => 'id',
                    'terms' => $post_type[2]
                );
            }
        }

        if ($atts['tag'] != '') {
            $args['tag_id'] = $atts['tag'];
        }
        if ($atts['author'] != '') {
            $args['author'] = $atts['author'];
        }


        if ($atts['follow'] == 'on') {

            if (is_archive() || is_search()) {
                unset($args['tax_query']);
                unset($args['tag']);
                unset($args['author']);
            }
            if (is_category()) {
                $obj = get_queried_object();

                $tax = get_taxonomy($obj->taxonomy);
                $args['post_type'] = $tax->object_type[0];


                $args['cat'] = $obj->term_id;
            } elseif (is_tax()) {
                $obj = get_queried_object();

                $tax = get_taxonomy($obj->taxonomy);
                $args['post_type'] = $tax->object_type[0];

                $args['tax_query'] = array(
                    'taxonomy' => $obj->taxonomy,
                    'field' => 'id',
                    'terms' => $obj->term_id
                );
            } elseif (is_tag()) {
                $obj = get_queried_object();

                $args['tag_id'] = $obj->term_id;
            } elseif (is_author()) {
                $obj = get_queried_object();
                $args['author'] = $obj->ID;
            } elseif (is_search()) {
                if (isset($_GET['s'])) {
                    $args['s'] = $_GET['s'];
                }

                if (isset($_GET['cat'])) {
                    if ($_GET['cat'] != '-1') {
                        $args['post_type'] = 'post';
                        $args['tax_query'] = array(
                            'taxonomy' => 'category',
                            'field' => 'id',
                            'terms' => $_GET['cat']
                        );
                    }
                }

                if (isset($_GET['tax'])) {

                    $tax = get_taxonomy($_GET['tax']);
                    $args['post_type'] = $tax->object_type[0];

                    if ($_GET['term'] != '-1') {
                        $args['tax_query'] = array(
                            'taxonomy' => $_GET['tax'],
                            'field' => 'id',
                            'terms' => $_GET['term']
                        );
                    }
                }
            } elseif (is_day()) {
                $args['date_query'] = array(
                    'year' => get_the_time('Y'),
                    'month' => get_the_time('n'),
                    'day' => get_the_time('j'),
                );
            } elseif (is_month()) {
                $args['date_query'] = array(
                    'year' => get_the_time('Y'),
                    'month' => get_the_time('n'),
                );
            } elseif (is_year()) {
                $args['date_query'] = array(
                    'year' => get_the_time('Y'),
                );
            }
        }


        $args['posts_per_page'] = $atts['posts_per_page'];

        if ($atts['paging'] == 'on') {
            if (get_query_var('paged')) {
                $paged = get_query_var('paged');
            } elseif (get_query_var('page')) {
                $paged = get_query_var('page');
            } else {
                $paged = 1;
            }
        } else {
            $paged = 1;
        }
        $args['offset'] = 0;
        $args['paged'] = $paged;

        //orderby
        $order_custom = array(
            'post_views_count',
            'votes_count',
            'rating_average',
            'total_share'
        );

        if (!in_array($atts['orderby'], $order_custom)) {
            $args['orderby'] = $atts['orderby'];
        } else {
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = $atts['orderby'];
        }


        $args['order'] = $atts['order'];

        return $args;
    }

    function get_authors_array($tag_id) {
        $array = array();
        $array[] = array(
            'label' => 'All Authors',
            'value' => ''
        );
        $blogusers = get_users();
        foreach ($blogusers as $user) {
            if (count_user_posts($user->ID) > 0) {
                $array[] = array(
                    'label' => $user->display_name,
                    'value' => $user->ID
                );
            }
        }

        $ret_array = array(
            'label' => 'Author',
            'id' => $tag_id,
            'type' => 'select',
            'desc' => 'Choose the Certain Authors',
            'std' => '',
            'choices' => $array,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_tags_array($tag_id) {

        $ret_array = array(
            'label' => 'Tag Select',
            'id' => $tag_id,
            'type' => 'tag-select',
            'desc' => 'Choose the tag to follow or leave blank',
            'std' => '',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_posts_input_array($tag_id) {

        $ret_array = array(
            'label' => 'Select Certain Posts',
            'id' => $tag_id,
            'type' => 'text',
            'desc' => 'Add Posts IDs seperated with comma ",", Example: 4,5,10',
            'std' => '',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_posts_per_page_array($tag_id, $std) {
        $ret_array = array(
            'label' => 'Number of Articles to show',
            'id' => $tag_id,
            'type' => 'numeric-slider',
            'desc' => 'Slide to select the Number of Articles to show',
            'std' => $std,
            'min_max_step' => '1,50,1',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_time_frame_array($tag_id, $default = '') {

        $time_frame = array(
            'all' => 'All the time',
            '_hour' => 'This hour',
            '_5min' => 'Now "5 minutes range"',
        );

        $array = array();
        foreach ($time_frame as $key => $value) {
            $array[] = array(
                'label' => $value,
                'value' => $key
            );
        }

        $ret_array = array(
            'label' => 'Select Timeframe',
            'id' => $tag_id,
            'type' => 'Select',
            'desc' => 'Select Timeframe to Show Articles in',
            'std' => $default,
            'choices' => $array,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_orderby_array($tag_id, $default = 'date') {

        $orderby = array(
            'none' => 'None',
            'id' => 'Post ID',
            'author' => 'Author',
            'title' => 'Title',
            'date' => 'Date Created',
            'modified' => 'Date Modified',
            'parent' => 'Post/Page Parent ID',
            'rand' => 'Random',
            'comment_count' => 'Number of Comments',
            'menu_order' => 'Page Order',
            'post_views_count' => 'Views Count',
            'votes_count' => 'Likes Count',
            'rating_average' => 'Rating Average',
            'total_share' => 'Social Total Share'
        );

        $array = array();
        foreach ($orderby as $key => $value) {
            $array[] = array(
                'label' => $value,
                'value' => $key
            );
        }

        $ret_array = array(
            'label' => 'Order By',
            'id' => $tag_id,
            'type' => 'Select',
            'desc' => 'Order by a certain parameter',
            'std' => $default,
            'choices' => $array,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_order_array($tag_id, $default = 'DESC') {

        $order = array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        );

        $array = array();
        foreach ($order as $key => $value) {
            $array[] = array(
                'label' => $value,
                'value' => $key
            );
        }

        $ret_array = array(
            'label' => 'Order',
            'id' => $tag_id,
            'type' => 'Select',
            'desc' => 'Order Direction',
            'std' => $default,
            'choices' => $array,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_follow_array($tag_id, $default = 'off') {


        $ret_array = array(
            'label' => 'Follow Current Page query',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Follow Current Page query, if you are in category page then the query will be about this category etc.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => ''
        );
        return $ret_array;
    }

    function get_category_array($tag_id) {

        $all_category = array();


        $args = array(
            'public' => true
        );
        $taxonomies = get_taxonomies($args);
        $all_categories = array();
        foreach ($taxonomies as $key) {
            if (!( $key == 'post_tag' || $key == 'post_format' )) {
                $categories = get_terms($key);
                foreach ($categories as $category) {
                    $taxonomy_data = get_taxonomy($category->taxonomy);
                    foreach ($taxonomy_data->object_type as $post_type) {
                        $obj = get_post_type_object($post_type);
                        if ($category->parent != 0) {
                            $parent_term = get_term($category->parent, $category->taxonomy);
                            $parent = $parent_term->term_taxonomy_id;
                        } else {
                            $parent = 0;
                        }

                        $all_categories[$category->term_taxonomy_id . '_' . $post_type] = array(
                            'id' => $category->term_id,
                            'label' => $category->name,
                            'parent' => $parent,
                            'post_name' => $obj->label,
                            'post_type' => $post_type,
                            'taxonomy' => $category->taxonomy
                        );
                    }
                }
            }
        }


        // this array contains all the childs
        $new_terms = array();

        foreach ($all_categories as $key => $term) {
            if ($term['parent'] != 0) {
                $new_terms[$key] = $term;
            }
        }
        $posts_local = array();
        foreach ($all_categories as $term) {
            if (!isset($posts_local[$term['post_name']])) {
                $posts_local[$term['post_name']] = $term['post_name'];
                $all_category[$term['post_type']] = $term['post_name'] . ' -> All Categories';
            }
            if ($term['parent'] == 0) {
                $all_category[$term['post_type'] . '#' . $term['taxonomy'] . '#' . $term['id']] = $term['post_name'] . ' -> ' . $term['label'];
                foreach ($new_terms as $new_term) {
                    if ($new_term['parent'] == $term['id']) {


                        $all_category[$term['post_type'] . '#' . $term['taxonomy'] . '#' . $new_term['id']] = $term['post_name'] . ' -> ' . $term['label'] . ' -> ' . $new_term['label'];
                    }
                }
            }
        }
        $return = array();
        foreach ($all_category as $key => $value) {
            $return[] = array(
                'label' => $value,
                'value' => $key
            );
        }


        $ret_array = array(
            'label' => 'Post Type & Category',
            'id' => $tag_id,
            'type' => 'Select',
            'desc' => 'Choose the Post type and Category',
            'std' => '',
            'choices' => $return,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => '',
        );
        return $ret_array;
    }

    function get_show_category_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Category',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Category.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_category c5_meta'
        );
        return $ret_array;
    }

    function get_show_author_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Author',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Author.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_author c5_meta'
        );
        return $ret_array;
    }

    function get_show_comments_count_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Comments Count',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Comments Count.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_comments_count c5_meta'
        );
        return $ret_array;
    }

    function get_show_likes_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Likes Count',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Likes Count.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_likes c5_meta'
        );
        return $ret_array;
    }

    function get_show_paging_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Enable Paging',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Enable Paging.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_paging'
        );
        return $ret_array;
    }

    function get_show_title_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Category/Post Type Title',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Category/Post Type Title.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_title'
        );
        return $ret_array;
    }

    function get_show_views_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Views Count',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Views Count.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_views c5_meta'
        );
        return $ret_array;
    }

    function get_show_rating_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Ratings',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Ratings "if included".',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_rating c5_meta'
        );
        return $ret_array;
    }

    function get_show_social_share_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Social Share Count',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Social Share Count.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_social c5_meta'
        );
        return $ret_array;
    }

    function get_show_excerpt_array($tag_id, $default = 'on') {


        $ret_array = array(
            'label' => 'Show Excerpt',
            'id' => $tag_id,
            'type' => 'on_off',
            'desc' => 'Show Excerpt.',
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_excerpt'
        );
        return $ret_array;
    }

    function get_show_date_array($tag_id, $default = 'date') {


        $ret_array = array(
            'label' => 'Show date/time in meta data',
            'id' => $tag_id,
            'type' => 'select',
            'desc' => 'Show date/time in meta data.',
            'choices' => array(
                array(
                    'label' => 'Date & Time',
                    'value' => 'date_time'
                ),
                array(
                    'label' => 'Only Date',
                    'value' => 'date'
                ),
                array(
                    'label' => 'Only Time',
                    'value' => 'time'
                ),
                array(
                    'label' => 'Ago Format',
                    'value' => 'ago'
                ),
                array(
                    'label' => 'Disable',
                    'value' => 'off'
                ),
            ),
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_show_date c5_meta'
        );
        return $ret_array;
    }

    function get_hover_icon_array($tag_id, $default = 'view') {


        $ret_array = array(
            'label' => 'Hover Icon',
            'id' => $tag_id,
            'type' => 'select',
            'desc' => 'Show Hover Icon.',
            'choices' => array(
                array(
                    'label' => 'Quick View',
                    'value' => 'view'
                ),
                array(
                    'label' => 'Link',
                    'value' => 'link'
                ),
                array(
                    'label' => 'Disable',
                    'value' => 'off'
                ),
            ),
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'class' => 'c5_hover_icons c5_meta'
        );
        return $ret_array;
    }

    function quick_read() {

        $type = get_post_type($_POST['post_id']);
        $args = array(
            'p' => $_POST['post_id'],
            'post_status' => 'publish',
            'post_type' => $type);


        query_posts($args);
        $data = '';
        while (have_posts()) : the_post();

            $image_size = c5ab_generate_image_size(320, 200, true);
            $img_html = get_the_post_thumbnail(get_the_ID(), $image_size);
            $data .= '<div class="row"><div class="col-sm-4">' . $img_html . '</div><div class="col-sm-8"><h2 class="c5-quick-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
            $permalink = get_permalink();
            $data .= '<div class="post-content clearfix">' . $this->get_the_excerpt_max_charlength(1000) . '</div>' . $this->get_read_more_button($permalink);

            $data .= '</div></div>';


        endwhile;

        wp_reset_postdata();
        echo $data;
        die();
    }

    function get_render_type_array($id, $default) {

        $tabs = array(
            'slider',
            'carousel',
            'blog_1',
            'blog_2',
            'blog_3',
            'boxes',
            'boxes-2',
            'boxes-plain',
            'metro',
            'flip',
            'photos',
            'thumb_tall',
            'thumb_wide_wide',
            'thumb_wide',
            'thumb',
            'thumb_2',
            'titles',
        );
        $tabs_array = array();
        foreach ($tabs as $value) {
            $tabs_array[] = array(
                'src' => C5BP_extra_uri . 'image/blogs/' . $value . '.png',
                'label' => '',
                'value' => $value,
                'class' => 'c5_posts_img'
            );
        }

        $return = array(
            'label' => 'Posts Apperance',
            'id' => $id,
            'type' => 'radio-image',
            'desc' => '',
            'choices' => $tabs_array,
            'std' => $default,
            'rows' => '',
            'post_type' => '',
            'taxonomy' => ''
        );

        return $return;
    }

    function get_unique_id() {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < 5; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

}

$ajax_call = new C5_post();

$ajax_call->hook();
?>