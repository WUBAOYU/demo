<?php 

class C5AB_posts extends C5_Widget {


	public  $_shortcode_name;
	public  $_shortcode_bool = true;
	public  $_options =array();
	
	function __construct() {
		
		$id_base = 'posts-widget';
		$this->_shortcode_name = 'c5ab_posts';
		$name = 'Posts ';
		$desc = 'Add Posts Feed to your page.';
		$classes = '';
		
		$this->self_construct($name, $id_base , $desc , $classes);
		if (!isset($GLOBALS['c5ab_posts_js_bool'])) {
			add_action('wp_footer', array($this, 'custom_js'), 300);
			$GLOBALS['c5ab_posts_js_bool'] = true;
		}
		
		
	}
	
	
	function shortcode($atts,$content) {
		
		if (!isset($GLOBALS['c5ab_posts_js'])) {
		    $GLOBALS['c5ab_posts_js'] = '';
		}
		
		
		$post_obj = new C5_post();
		
		$args = $post_obj->handle_atts($atts);
		
		$skin_obj = new C5_skin_functions();
		
		$slider_id = $this->get_unique_id();
		
		// The Query
		$the_query = new WP_Query( $args );
		$return = '';
		// The Loop
		if ( $the_query->have_posts() ) {
		        $return .= '<div class="c5ab_posts_'.$atts['render_type'].'  c5ab_posts_'.$atts['render_type'].'_' . $slider_id . '">';
		        
		        
		        $return .= $post_obj->get_title($atts);
		        if( $atts['render_type'] == 'slider'  || $atts['render_type'] == 'carousel'){
		        	$return .= '<ul class="c5ab_slides clearfix">';
		        }
		        
		        
		        if( $atts['render_type'] == 'metro' || $atts['render_type'] == 'blog_3' ){
		        	$return .=  '<div class="c5-flip-js clearfix">';
		        }
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				switch ($atts['render_type']) {
					case 'slider':
						$return .= $post_obj->get_post_slide($atts);
						break;
					case 'thumb_tall';
						if($the_query->current_post == 0){
							$return .= $post_obj->get_post_thumb_tall($atts);
						}else {
							$return .= $post_obj->get_post_thumb($atts);	
						}
						break;
					case 'thumb';
						$return .= $post_obj->get_post_thumb($atts);	
						break;
					case 'thumb_2';
						if($the_query->current_post%2 == 0){
							$return .= '<div class="row"><div class="col-sm-6">';
						
							$return .= $post_obj->get_post_thumb($atts);
						
							$return .= '</div>';
						}else {
							$return .= '<div class="col-sm-6" >';
							
							$return .= $post_obj->get_post_thumb($atts);
							
							$return .= '</div></div>';
						}
						
						
						if($the_query->current_post%2 == 0 && $the_query->current_post == ( $the_query->post_count - 1) ){
							$return .= '</div>' ;
						}	
						
						break;
					case 'photos';
						if($the_query->current_post == 0){
							$return .= $post_obj->get_post_thumb_photos($atts, 148);
						}else {
							$return .= $post_obj->get_post_thumb_photos($atts, 73);	
						}
						break;
					case 'thumb_wide';
						if($the_query->current_post == 0){
							$return .= '<div class="row"><div class="col-sm-6">';
							$return .= $post_obj->get_post_thumb_tall($atts);
							$return .= '</div><div class="col-sm-6" >';
						}else {
							$return .= $post_obj->get_post_thumb($atts);	
						}
						if($the_query->current_post == ( $the_query->post_count - 1) ){
							$return .= '</div></div>' ;
						}	
						break;
					case 'thumb_wide_wide';
						if($the_query->current_post == 0){
							$return .= $post_obj->get_post_thumb_wide($atts);
						}else {
							if($the_query->current_post%2 == 1){
								$return .= '<div class="row"><div class="col-sm-6">';
							
								$return .= $post_obj->get_post_thumb($atts);
							
								$return .= '</div>';
							}else {
								$return .= '<div class="col-sm-6" >';
								
								$return .= $post_obj->get_post_thumb($atts);
								
								$return .= '</div></div>';
							}
							if($the_query->current_post%2 == 1 && $the_query->current_post == ( $the_query->post_count - 1) ){
								$return .= '</div>' ;
							}	
						}
							
						break;
					case 'boxes';
						if($the_query->current_post == 0){
							$return .= '<div class="row">';
							$return .= '<div class="col-sm-8">'. $post_obj->get_post_boxes_wide($atts);
							$return .= '</div>';
						}elseif($the_query->current_post == 1){
							$return .= '<div class="col-sm-4">' .  $post_obj->get_post_boxes();
							
							$return .= '</div></div>';
						}else {
							$current = $the_query->current_post -2 ;
							if($current%3 == 0){
								$return .= '<div class="row">';
							}
							$return .= '<div class="col-sm-4">' . $post_obj->get_post_boxes() . '</div>';
							
							if($current%3 == 2){
								$return .= '</div>';
							}
							
							if($current%3 != 2 && $the_query->current_post == ( $the_query->post_count - 1) ){
								$return .= '</div>' ;
							}	
						}
							
						break;
					case  'boxes-2':
						$current = $the_query->current_post ;
						if ($GLOBALS['c5_content_width'] < 350) {
						    $count = 1;
						}elseif ($GLOBALS['c5_content_width'] < 700) {
						    $count = 3;
						} elseif ($GLOBALS['c5_content_width'] < 1000) {
						    $count = 4;
						} else {
						    $count = 5;
						}
						$span = 12/$count;
						$end = $count -1;
						$span_1 = $span -1;
						if($current%$count == 0){
							$return .= '<div class="row">';
						}
						$return .= '<div class="col-md-'.$span.' col-sm-'.$span_1.'">' . $post_obj->get_post_boxes() . '</div>';
						
						if($current%$count == $end){
							$return .= '</div>';
						}
						
						if( ( $current%$count != $end  ) && $the_query->current_post == ( $the_query->post_count - 1) ){
							$return .= '</div>' ;
						}
						break;
					case 'boxes-plain':
						$return .= $post_obj->get_post_boxes();
						break;
					case 'metro';
						$return .=  $post_obj->get_post_metro();
						break;
					case 'flip';
						$return .=  $post_obj->get_post_carousel();
						break;
					case 'carousel';
						$return .=  '<li>' . $post_obj->get_post_carousel( ) . '</li>';
						break;
					case 'blog_1';
						$return .=  $post_obj->get_post_blog_1($atts );
						break;
					case 'blog_2';
						$return .=  $post_obj->get_post_blog_2($atts );
						break;
					case 'blog_3';
						$return .=  $post_obj->get_post_blog_3($atts );
						break;
					case 'titles':
						$return .=  $post_obj->get_post_titles($atts );
						break;
				}
				
			}
				if( $atts['render_type'] == 'metro' ||  $atts['render_type'] == 'blog_3' ){
					$return .=  '</div>';
				}
				if( $atts['render_type'] == 'slider'  || $atts['render_type'] == 'carousel' ){
					$return .= '</ul>';
				}
				
				$return .= $post_obj->get_pagination($atts, $the_query);
		        $return .=  '</div>';
		        
		        
		       
		        
		}else {
			$return = '<article id="post-not-found" class="hentry clearfix">
			    <header class="article-header">
			        <h1>'. __('No Articles to show!', 'code125') .'</h1>
			    </header>
			    <section class="entry-content">
			        <p>'. __('No articles found to show on this page.', 'code125').'</p>
			    </section>
			</article>';
		}
		
		/* Restore original Post Data */
		wp_reset_postdata();
		
		
		if( $atts['render_type'] == 'slider' ){
			$GLOBALS['c5ab_posts_js'] .= '$(\'.c5ab_posts_slider_' . $slider_id . '\').flexslider({
		    	          animation: "slide",
		    	          selector: "ul.c5ab_slides > li"
		    	    }); '. "\n";
		}     
		if( $atts['render_type'] == 'metro' ){
			if ($GLOBALS['c5_content_width'] < 350) {
			    $single_width = $GLOBALS['c5_content_width'];
			}elseif ($GLOBALS['c5_content_width'] < 700) {
			    $single_width = floor($GLOBALS['c5_content_width'] / 3);
			} elseif ($GLOBALS['c5_content_width'] < 1000) {
			    $single_width = floor($GLOBALS['c5_content_width'] / 4);
			} else {
			    $single_width = floor($GLOBALS['c5_content_width'] / 5);
			}
			$GLOBALS['c5ab_posts_js'] .= '$(\'.c5ab_posts_metro_' . $slider_id . ' .c5-flip-js\').isotope({itemSelector:".element", masonry:{columnWidth:'.$single_width.'}}); '. "\n";
		}
		
		if( $atts['render_type'] == 'blog_3' ){
			if($GLOBALS['c5_content_width'] < 700){
				$single_width = floor(($GLOBALS['c5_content_width']+30)/2);
			}elseif($GLOBALS['c5_content_width'] < 1000){
				$single_width = floor(($GLOBALS['c5_content_width']+30)/3);
			}else {
				$single_width = floor(($GLOBALS['c5_content_width']+30)/4);
			}
			$GLOBALS['c5ab_posts_js'] .= '$(\'.c5ab_posts_blog_3_' . $slider_id . ' .c5-flip-js\').isotope({itemSelector:".element", masonry:{columnWidth:'.$single_width.'}}); '. "\n";
			
			$return .=  '<style>.c5ab_posts_blog_3_' . $slider_id . ' .c5ab_post_thumb{width:'.$single_width.'px}</style>';
			
		}
		
		if( $atts['render_type'] == 'carousel' ){
			if ($GLOBALS['c5_content_width'] < 350) {
			    $single_width = $GLOBALS['c5_content_width'];
			}elseif ($GLOBALS['c5_content_width'] < 700) {
			    $single_width = floor($GLOBALS['c5_content_width'] / 3);
			} elseif ($GLOBALS['c5_content_width'] < 1000) {
			    $single_width = floor($GLOBALS['c5_content_width'] / 4);
			} else {
			    $single_width = floor($GLOBALS['c5_content_width'] / 5);
			}
			$GLOBALS['c5ab_posts_js'] .= '$(\'.c5ab_posts_carousel_' . $slider_id . '\').flexslider({animation:"slide", animationLoop:false, selector:".c5ab_slides > li", itemWidth:'.$single_width.', itemMargin:0, controlNav:false, directionNav:true, move:1, slideshow:false}); ' . "\n";
		}
		
		        
		    return $return;
	}
	
	
	
	function custom_css() {
		
	}
	
	function custom_js() {
	    ?>
	    <script  type="text/javascript">
	        jQuery(document).ready(function($) {
			    <?php
			    if (isset($GLOBALS['c5ab_posts_js'])) {
			        echo $GLOBALS['c5ab_posts_js'];
			    }
			    ?>
	        });
	    </script>
	    <?php
	}
	
	
	
	function options() {
		
		$post_obj = new C5_post();
		$this->_options =array(
			
			$post_obj->get_render_type_array('render_type' , 'blog_1'),
			array(
			    'label' => 'Slider Height',
			    'id' => 'height',
			    'type' => 'numeric-slider',
			    'desc' => 'Slider Height in pixels.',
			    'std' => '400',
			    'min_max_step' => '200,600,1',
			    'rows' => '',
			    'post_type' => '',
			    'taxonomy' => '',
			    'class' => ''
			),
			$post_obj->get_follow_array('follow' , 'off'),
			$post_obj->get_posts_per_page_array('posts_per_page', '5'),
			$post_obj->get_category_array('post_type','post'),
			$post_obj->get_tags_array('tag',''),
			$post_obj->get_authors_array('author',''),
			$post_obj->get_orderby_array('orderby','date'),
			$post_obj->get_order_array('order','DESC'),
			$post_obj->get_posts_input_array('posts',''),
			$post_obj->get_show_paging_array('paging','off'),
			
			
			$post_obj->get_show_title_array('show_title','off'),
			
			$post_obj->get_show_excerpt_array('show_excerpt','on'),
			$post_obj->get_hover_icon_array('show_hover','link'),
			
			$post_obj->get_show_category_array('show_cat','on'),
			$post_obj->get_show_date_array('show_date','off'),
			$post_obj->get_show_author_array('show_author','off'),
			$post_obj->get_show_comments_count_array('show_comment','off'),
			$post_obj->get_show_likes_array('show_likes','on'),
			$post_obj->get_show_views_array('show_views','off'),
			$post_obj->get_show_social_share_array('show_social','on'),
			$post_obj->get_show_rating_array('show_rating','off'),
			 
		);
	}
	
	function admin_footer_js() {
		?>
		<script  type="text/javascript" id="c5_posts_apperance">
			jQuery(document).ready(function ($) {
			C5AB_POSTS_UI = {
			    init: function() {
			       $(document).on('click', '.c5-setting-wrap-render_type .option-tree-ui-radio-image', function(e) {
			            var render_type = $(this).parent().find('.option-tree-ui-radio ').val();
			            C5AB_POSTS_UI.show_hide_values_of(render_type);
			        });
			        
			        var render_type = C5AB_POSTS_UI.get_current_value();
			        C5AB_POSTS_UI.show_hide_values_of(render_type);
			
			    },
			    show_hide_values_of: function(render_type) {
					if(  render_type == 'carousel' ||  render_type == 'boxes'  ||  render_type == 'titles' ||  render_type == 'flip' || render_type == 'boxes-plain' || render_type == 'photos'){
						$('.c5-setting-wrap.c5_meta').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-height').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_excerpt').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-paging').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_title').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeOut();
						
					}else if( render_type == 'slider' ){
						$('.c5-setting-wrap.c5_meta').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-height').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-show_excerpt').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-paging').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_title').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeOut();
					}else if( render_type == 'blog_1' || render_type == 'blog_2' ||  render_type == 'blog_3' ){
						$('.c5-setting-wrap.c5_meta').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-height').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_excerpt').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-paging').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-show_title').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeOut();
					}else if(render_type == 'boxes-2' || render_type == 'metro'){
						$('.c5-setting-wrap.c5_meta').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-height').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_excerpt').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-paging').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-show_title').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeOut();
					}else {
						$('.c5-setting-wrap.c5_meta').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-height').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_excerpt').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-paging').fadeOut();
						$('.c5-setting-wrap.c5-setting-wrap-show_title').fadeIn();
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeIn();
					}
					
					if (render_type == 'photos') {
						$('.c5-setting-wrap.c5-setting-wrap-show_hover').fadeIn();
					}
			        
			
			    },
			    get_current_value: function() {
			        var render_type = '';
			        $('.c5-setting-wrap-render_type .option-tree-ui-radio-image').each(function() {
			            var k = $(this);
			            if ( k.hasClass('option-tree-ui-radio-image-selected')) {
			                render_type =  k.parent().find('.option-tree-ui-radio ').val();
			            }
			        });
			        return render_type;
			
			    },
			};
			C5AB_POSTS_UI.init();
			
			});
		</script>
		<?php
	}
	
	function css() {
	?>
	<style>
		
		
	</style>
	<?php
	}

}

add_action('widgets_init' , 'c5_register_blog_widget');

function c5_register_blog_widget() {
	
	register_widget( 'C5AB_posts' );	
}


 ?>