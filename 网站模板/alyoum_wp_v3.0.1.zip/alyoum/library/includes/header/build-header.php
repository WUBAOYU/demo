<?php

class C5_build_header {

    function __construct() {
        
    }

    function hook() {
        add_action('wp_head', array($this, 'custom_css'), 229);
        add_action('wp_footer', array($this, 'footer'), 300);
    }

    function custom_css() {
        global $c5_skindata;
        global $c5_headerdata;

        $heading_font = explode('#', $c5_skindata['heading_font']);
        $body_font = explode('#', $c5_skindata['body_font']);

        $obj_style = new C5AB_STYLE();
        $rgb = $obj_style->hex2rgb($c5_skindata['primary_color']);
        if(is_single()){
        	global $post;
        	$user_id = $post->post_author;
        	$google_plus_id=  get_the_author_meta('c5_term_meta_user_google_plus', $user_id);
        	if($google_plus_id!=''){  ?>
       			<link rel="author" href="http://www.google.com/+<?php echo $google_plus_id; ?>">
        <?php } } ?>
        <style>


            /** Primary Color**/

            .c5ab_social_icons a.fa:hover,
            .c5ab_social_icons a.fa:focus,
            .single_social_icon .dropdown-menu,
            .c5-breaking-wrap .c5-breaking-nav .shuffle-article:hover,
            .c5-breaking-wrap .breaking-title,
            
            .c5ab_posts_slider  .flex-control-paging li a.flex-active,
            #wp-calendar td#today,
            .c5ab_posts_thumb_boxes_single:hover .box-content,
            .flip-post .post-data-bg,
            .c5-pagination ul.page-numbers li span.current,
            .pagination a,
            .commentlist .comment-reply-link,
            .comment-form #submit,
            .rating-row .progress-bar-success,
            .c5ab_social_counter ul li a:hover,
            .c5-cat-info-warp:hover .c5-cat-icon,
            #c5-submit-contact,
            .c5-sidebar-controller,
            .top-menu-nav ul.menu-sc-nav > li.menu-item:hover > a{
                background-color: <?php echo $c5_skindata['primary_color'] ?>;
            }
            
            h3.title,
            h2.title.title-style-1,
            h3.widget-title{
            	background-color: <?php echo $c5_skindata['title_color'] ?>;
            }
            h3.widget-title::after,
            h3.title::after,
            h2.title.title-style-1::after{
                border-top: 7px solid  <?php echo $c5_skindata['title_color'] ?>;
            }
            
            
            
            .comment-form #submit:hover{
            	background-color: <?php echo $obj_style->hexDarker($c5_skindata['primary_color']) ?>;
            }
			.c5ab_social_counter ul li a:hover{
				border-color:<?php echo $c5_skindata['primary_color'] ?>;
			}
            .c5ab_post_thumb .hover,
            .c5ab_posts_thumb_boxes_single .box-content{
                background-color: <?php echo $c5_skindata['primary_color'] ?>;
                background-color: rgba(<?php echo $rgb[0] ?> , <?php echo $rgb[1] ?> , <?php echo $rgb[2] ?>, 0.8);
            }
            
            .navigation-shortcode.sidebar.top-menu-nav ul.menu-sc-nav>li.menu-item{
            	background-color: <?php echo $c5_skindata['side_menu_background'] ?>;
            }
            
           
            .post-password-form{
            	border-left: 5px solid <?php echo $c5_skindata['primary_color'] ?>;
            }
            a,
            ul.newsticker a.c5-cat,
            .c5ab_posts_slider ul li .content li a:hover,
            .c5ab_posts_slider ul li .content li:hover,
            .c5ab_post_thumb .content .c5_meta_data li:hover,
            .c5ab_post_thumb .content .c5_meta_data a:hover,
            .c5ab_post_thumb .content h3 a:hover,
            .c5-rating-box .c5-rating-wrap .fa,
            .c5-sitemap ul a:hover{
                color: <?php echo $c5_skindata['primary_color'] ?>;
            }
            a:hover{
                color: <?php echo $obj_style->hexDarker($c5_skindata['primary_color']) ?>;
            }

            #c5-below-logo{
                border-top: 4px solid <?php echo $c5_skindata['primary_color'] ?>;
            }
            #c5_bread_crumb .border{
                border-left: 4px solid <?php echo $c5_skindata['primary_color'] ?>;
            }


            /** text color **/

            .top-menu-nav ul.menu-sc-nav > li.menu-item > a{
                color: #57595a;
            }

            /** font sizes ***/

            .c5-breaking-wrap .breaking-title{
                font-size:<?php echo $c5_headerdata['breaking_news_title_fs'] ?>px;
            }
            .c5-breaking-wrap ul.newsticker li{
            	font-size:<?php echo $c5_headerdata['breaking_news_text_fs'] ?>px;
            }
            
            
            .mini.top-menu-nav ul.menu-sc-nav>li.menu-item>a{
            	font-size:<?php echo $c5_skindata['top_menu_fs'] ?>px;
            }
            
            .top-menu-nav ul.menu-sc-nav>li.menu-item>a{
            	font-size:<?php echo $c5_skindata['side_menu_fs'] ?>px;
            }
            
            h3.title,
            h2.title.title-style-1,
            h3.widget-title{
            	font-size:<?php echo $c5_skindata['title_fs'] ?>px;
            }
            
            
            .c5ab_posts_thumb_tall_single h3{
            	font-size:<?php echo $c5_skindata['article_title_fs'] ?>px;
            }
            
            .c5ab_posts_slider ul li .content h3{
            	font-size:<?php echo $c5_skindata['slider_title_fs'] ?>px;
            }
            
            
            
            
            
            

            
            /** Font **/
            body{
                <?php echo $this->format_background($c5_skindata['main_background']); ?>
                font-family: <?php echo $body_font[0] ?>,"Helvetica Neue", Helvetica, Arial, sans-serif ;
                font-size: <?php echo $c5_skindata['body_fs'] ?>px;
            }
            h1,h2,h3,h4,h5,h6,
            .top-menu-nav.default ul.menu-sc-nav > li.menu-item > a,
            .c5-today,
            .c5-breaking-wrap .breaking-title,
            ul.newsticker li,
            .navigation-shortcode.sidebar.top-menu-nav ul.menu-sc-nav > li.menu-item > a,
            #wp-calendar,
            .flip-post a.title-link,
            h2.title.title-style-1,
            .footer .widget_categories ul li,
            .c5ab_social_counter ul li a span.count,
            .services_wrapper .service-item .lower_half h5,
            .c5ab_slider ul li .content p.title {
                font-family: <?php echo $heading_font[0] ?>,"Helvetica Neue", Helvetica, Arial, sans-serif ;
            }

            <?php
            $taxonomies = get_taxonomies('', 'names');

            foreach ($taxonomies as $tax) {
                $terms = get_terms($tax);
                if (is_array($terms)) {
                    foreach ($terms as $term) {
                        $skin = get_option('c5_term_meta_' . $tax . '_' . $term->term_id . '_skin');
                        $skin_obj = new C5_skin_functions();
                        if ($skin_obj->skin_exist($skin)) {
                            $color = $skin_obj->get_color_from_skin($skin);
							$rgb_color =  $obj_style->hex2rgb($color);
                            $class_name = '.' . $tax . '-' . $term->term_id;
                            ?>
                            h3.title<?php echo $class_name ?>,
                            .c5ab_posts_thumb_boxes_single<?php echo $class_name ?>:hover .box-content,
                            .flip-post<?php echo $class_name ?> .post-data-bg,
                            h2.title.title-style-1<?php echo $class_name ?>{
                                background-color: <?php echo $color ?>;
                            }

                            .c5ab_post_thumb<?php echo $class_name ?> .c5_meta_data li:hover,
                            .c5ab_post_thumb<?php echo $class_name ?> .c5_meta_data li a:hover,
                            .c5ab_post_thumb<?php echo $class_name ?> h3 a:hover{
                                color: <?php echo $color ?>;
                            }
                            
                            .c5ab_post_thumb<?php echo $class_name ?> .hover,
                            .c5ab_posts_thumb_boxes_single<?php echo $class_name ?> .box-content{
                                background-color: <?php echo $color ?>;
                                background-color: rgba(<?php echo $rgb_color[0] ?> , <?php echo $rgb_color[1] ?> , <?php echo $rgb_color[2] ?>, 0.8);
                            }
                           

                            h3.widget-title<?php echo $class_name ?>::after,
                            h3.title<?php echo $class_name ?>::after,
                            h2.title.title-style-1<?php echo $class_name ?>::after {
                                border-top: 7px solid <?php echo $color ?>;
                            }
                            <?php
                        }
                    }
                }
            }
            ?>
		/***General Custom CSS**/
		<?php echo ot_get_option('custom_css'); ?>
		/***Skin Custom CSS**/
		<?php echo $c5_skindata['custom_css']; ?>
        </style>

		
        <?php
        
        echo ot_get_option('google_analytics');
    }
    
    function footer() {
    	 global $c5_skindata;
    	 ?>
    	 <script  type="text/javascript">
    	 	/***General Custom CSS**/
    	 	<?php echo ot_get_option('custom_js'); ?>
    	 	/***Skin Custom CSS**/
    	 	<?php echo $c5_skindata['custom_js']; ?>
    	 
    	 </script>
   		<?php
    }
    

    function format_background($array) {
        $data = '';
        if ($array['background-color'] != '') {
            $data .= 'background-color:' . $array['background-color'] . ';';
        }
        if ($array['background-position'] != '') {
            $data .= 'background-position:' . $array['background-position'] . ';';
        }
        if ($array['background-repeat'] != '') {
            $data .= 'background-repeat:' . $array['background-repeat'] . ';';
        }
        if ($array['background-attachment'] != '') {
            $data .= 'background-attachment:' . $array['background-attachment'] . ';';
        }
        if ($array['background-image'] != '') {
            $data .= 'background-image:url(\'' . $array['background-image'] . '\');';
        }
        return $data;
    }

    function head() {
        ?>
        <!doctype html>                                                                                                                             <!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->                                                                                                                                <!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->                                                                                                                                <!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
        <!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

            <head>
                <meta charset="utf-8">

                <?php // Google Chrome Frame for IE    ?>
                <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

                <title><?php
                    bloginfo('name');
                    echo ' | ';
                    if (is_front_page() || is_home()) {
                        bloginfo('description');
                    } else {
                        wp_title('');
                    }
                    ?></title>

                <?php // mobile meta (hooray!)  ?>
                <meta name="HandheldFriendly" content="True">
                <meta name="MobileOptimized" content="320">
                <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

                <?php // icons & favicons (for more: http://www.jonathantneal.com/blog/understand-the-favicon/)   ?>
                <?php
                $favicon = ot_get_option('favicon');
                ?>

                <?php $image_url = c5_generate_image(16, 16, $favicon, true); ?>
                <link rel="icon" href="<?php echo $image_url[0] ?>" sizes="16x16">
                <?php $image_url = c5_generate_image(32, 32, $favicon, true); ?>
                <link rel="icon" href="<?php echo $image_url[0] ?>" sizes="32x32">
                <?php $image_url = c5_generate_image(48, 48, $favicon, true); ?>
                <link rel="icon" href="<?php echo $image_url[0] ?>" sizes="48x48">
                <?php $image_url = c5_generate_image(64, 64, $favicon, true); ?>
                <link rel="icon" href="<?php echo $image_url[0] ?>" sizes="64x64">
                <?php $image_url = c5_generate_image(128, 128, $favicon, true); ?>
                <link rel="icon" href="<?php echo $image_url[0] ?>" sizes="128x128">

                <!--[if IE]>
                        <link rel="shortcut icon" href="<?php echo $image_url[0] ?>">
                <![endif]-->
                <?php // or, set /favicon.ico for IE10 win    ?>
                <meta name="msapplication-TileImage" content="<?php echo $image_url[0] ?>">

                <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">

                <?php // wordpress head functions   ?>
                <?php wp_head(); ?>
                <?php // end of wordpress head   ?>

                <?php // drop Google Analytics Here ?>
                <?php // end analytics   ?>

            </head>
            <?php
        }

        function floating() {
            global $c5_headerdata;
            global $c5_skindata;
            	if($c5_headerdata['floating_enable'] != 'on'){
            		return;
            	}
            	
            	
            	?>
            
            
            	
            	<div id="c5-floating-bar" class="clearfix light-mode">
            		<div class="c5-main-width c5-main-width-<?php echo $GLOBALS['c5-main-width']; ?> clearfix">
            		<?php 
            		
            		if ($c5_headerdata['floating_logo'] != '') {
            		     $image_url = c5_generate_image(9999, $c5_headerdata['floating_logo_height'], $c5_headerdata['floating_logo'], false);
            		
            		     $data = '<a class="clearfix c5-floating-logo"  style="margin-top:' . $c5_headerdata['floating_logo_margin'] . 'px" href="' . home_url() . '" rel="nofollow"><img alt="" src="' . $image_url[0] . '" width="' . $image_url[1] . '" height="' . $image_url[2] . '" /></a>';
            			echo $data;
            			
            		if ($c5_headerdata['floating_custom_content'] == '') {	
            				echo '<div class="c5-left">';
            				if(is_single()){
            					?>
            					<ul class="c5-ss-share clearfix">
            						
            						<li>
            							<?php 
            							global $post;
            							$social_count = get_post_meta($post->ID, 'c5_total_share',true);
            							if($social_count==''){
            								$social_count = 0;
            							}
            							 ?>
            							<span class="c5-total-share"><?php echo $social_count ?> <span><?php _e('Shares','code125') ?></span></span>
            						</li>
            						<li>
            							<a class="c5-ss-share-link fa fa-facebook" href="http://www.facebook.com/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" rel="nofollow"><?php _e('Share on Facebook', 'code125'); ?></a>
            						</li>
            						<li>
            							<a class="c5-ss-share-link fa fa-twitter" href="http://twitter.com/share?text=<?php echo urlencode(__('Check out this article: ','code125') . $post->post_title  .' - ' ) ?>" rel="nofollow" target="_blank"><?php _e('Share on Twitter', 'code125'); ?></a>
            						</li>
            						<li>
            							<a class="c5-ss-share-link fa fa-google-plus" href="http://plus.google.com/share?url=<?php echo urlencode(get_permalink()); ?>" rel="nofollow" target="_blank"><?php _e('Share on Google+', 'code125'); ?></a>
            						</li>
            					</ul>
            					<?php
            				}else {
            					if ($c5_headerdata['floating_menu_enable'] == 'on') {
            						echo(do_shortcode('[c5ab_menu location="' . $c5_headerdata['floating_top_menu'] . '" responsive="on" style="mini" bg_mode="light-mode" ]'));
            					}
            				}
            				echo '</div>';
            				if ($c5_headerdata['floating_social_enable'] == 'on') {
            					echo '<div class="c5-right">';
            						
            						$code = '';
            						$social_icons = ot_get_option('social_icons', array());
            						if ($social_icons) {
            						    $code .= '[c5ab_social_icons]';
            						    foreach ($social_icons as $social_icon) {
            						        $code .= '[c5ab_social_icon icon="' . $social_icon['icon'] . '" link="' . $social_icon['link'] . '" type="' . $social_icon['type'] . '" title="' . $social_icon['title'] . '" ]';
            						    }
            						    $code .= '[/c5ab_social_icons]';
            						}
            						echo(do_shortcode($code));
            					
            						echo '</div>';
            				}
            			}
            			
            		}else {
            			echo '<div class="c5-left">';
            			
            			echo do_shortcode($c5_headerdata['floating_custom_content']);
            			
            			echo '</div>';
            		}
            			
            		
            		 ?>
            		
            		
            		</div>
            	
            	</div>
            	
            	<?php
        }

        function below_logo() {
            global $c5_headerdata;
            global $c5_skindata;


            $layout = explode('-', $c5_skindata['layout_width']);
            if ($layout[1] != 'S' && $c5_headerdata['header_menu_position'] == 'side') {
                $c5_headerdata['header_menu_position'] = 'top';
            }

            if ($c5_headerdata['header_menu_position'] == 'top') {
                $data = '<div id="c5-below-logo"  class="clearfix">';

                $data .= '<div class="c5-left">' . do_shortcode('[c5ab_menu location="' . $c5_headerdata['header_menu'] . '" responsive="on" style="default" bg_mode="light" ]') . '</div>';
                if ($c5_headerdata['header_menu_today'] != 'off') {
                    $data .='<div class="c5-right"><span class="c5-today"><span class="fa fa-calendar"></span>' . date(get_option('date_format')) . '</span></div>';
                }
                $data .='</div>';

                echo $data;
            }
        }

        function top_bar() {
            global $c5_headerdata;
            global $c5_skindata;
            if ($c5_headerdata['top_enable'] != 'off') {

                $background_color = $c5_headerdata['top_background'];
                $style_obj = new C5AB_STYLE();
                $rgb = $style_obj->HTMLToRGB($background_color);
                $hsl = $style_obj->RGBToHSL($rgb);
                if ($hsl->lightness > 200) {
                    $background_mode = 'light-mode';
                } else {
                    $background_mode = 'dark-mode';
                }


                $border_color = 'border-top:4px solid ' . $c5_skindata['primary_color'] . '; ';

                echo '<style>
            		#header-top-bar,
            		#header-top-bar .mini.top-menu-nav ul.menu-sc-nav > li.menu-item ul.sub-menu{
            			background-color:' . $background_color . '; ' . $border_color . '
            		}
            	</style>
            	<div id="header-top-bar" class="clearfix ' . $background_mode . '">
            		<div class="c5-main-width c5-main-width-' . $GLOBALS['c5-main-width'] . ' clearfix">';
                if ($c5_headerdata['top_custom_content'] != '') {
                    echo do_shortcode($c5_headerdata['top_custom_content']);
                } else {
                    echo '<div class="c5-left">';
                    if ($c5_headerdata['top_menu_enable'] != 'off') {
                        echo(do_shortcode('[c5ab_menu location="' . $c5_headerdata['header_top_menu'] . '" responsive="on" style="mini" bg_mode="' . $background_mode . '" ]'));
                    } else {
                        echo do_shortcode($c5_headerdata['top_custom_content']);
                    }
                    echo '</div> <div class="c5-right">';

                    if ($c5_headerdata['top_social_enable'] != 'off') {
                        $code = '';
                        $social_icons = ot_get_option('social_icons', array());
                        if (is_array($social_icons)) {
                            $code .= '[c5ab_social_icons]';
                            foreach ($social_icons as $social_icon) {
                                $code .= '[c5ab_social_icon icon="' . $social_icon['icon'] . '" link="' . $social_icon['link'] . '" type="' . $social_icon['type'] . '" title="' . $social_icon['title'] . '" ]';
                            }
                            $code .= '[/c5ab_social_icons]';
                        }
                        echo(do_shortcode($code));
                    } else {
                        echo do_shortcode($c5_headerdata['top_custom_content']);
                    }

                    echo '</div>';
                }

                echo '</div> </div>';
            }
        }

        function main_content() {

            global $c5_headerdata;

            switch ($c5_headerdata['header_layout']) {
                case 'logo-left':
                    ?>
                    <div class="c5-left"><?php $this->get_current_logo(); ?></div>
                    <div class="c5-right"><?php echo do_shortcode($c5_headerdata['content_logo']) ?></div>
                    <?php
                    break;
                case 'logo-right':
                    ?>
                    <div class="c5-left"><?php echo do_shortcode($c5_headerdata['content_logo']) ?></div>
                    <div class="c5-right"><?php $this->get_current_logo(); ?></div>
                    <?php
                    break;
                case 'logo-custom':
                    $this->get_current_logo();
                    break;
            }
        }

        function get_current_logo() {
            global $c5_headerdata;
            if ($c5_headerdata['logo'] != '') {
                $image_url = c5_generate_image(9999, $c5_headerdata['logo_height'], $c5_headerdata['logo'], false);

                $data = '<a class="clearfix c5-bottom-30" id="logo" style="margin-top:' . $c5_headerdata['logo_margin'] . 'px" href="' . home_url() . '" rel="nofollow"><img alt="" src="' . $image_url[0] . '" width="' . $image_url[1] . '" height="' . $image_url[2] . '" /></a>';
            } else {
                $logo_url = ot_get_option('logo');
                if ($logo_url != '') {
                    $image_url = c5_generate_image(9999, ot_get_option('logo_height'), $logo_url, false);

                    $data = '<a class="clearfix c5-bottom-30" id="logo" style="margin-top:' . ot_get_option('logo_margin') . 'px" href="' . home_url() . '" rel="nofollow"><img alt="" src="' . $image_url[0] . '" width="' . $image_url[1] . '" height="' . $image_url[2] . '" /></a>';
                } else {
                    $data = '<a class="clearfix c5-bottom-30" id="logo" style="margin-top:' . ot_get_option('logo_margin') . 'px" href="' . home_url() . '" rel="nofollow"><img alt="" src="' . C5_URL . 'library/images/logo.png"  /></a>';
                }
            }

            echo $data;
        }

    }
    ?>