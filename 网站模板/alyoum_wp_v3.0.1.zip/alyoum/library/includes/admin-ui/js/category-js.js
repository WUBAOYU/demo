jQuery(document).ready(function ($) {


	$(document).on('click', '.c5_span_icon', function (e) {
		$('.c5_span_icon').removeClass('selected');
		$(this).addClass('selected');
		$('#c5_icon').val($(this).attr('data-class'));
	});

});