<?php 

class C5_admin_ui {
	
	function __construct() {
	
		define('C5_admin_UI_ROOT', C5_ROOT . 'library/includes/admin-ui/');
		define('C5_admin_UI_URL', C5_URL . 'library/includes/admin-ui/');
		
		
		add_action( 'admin_enqueue_scripts', array( $this , 'load_css' ) );
	}
	
	function load_css() {
	        wp_enqueue_style( 'c5-admin-ui', C5_admin_UI_URL . 'css/admin-ui.css', false, '1.0.0' );
	}
	
}

$admin_ui_obj = new C5_admin_ui();


 ?>