<?php
function filter_textarea_tinymce( $content, $field_id ) {
  
  /* only run the filter on the textarea with a field ID of my_textarea */
   if ( $field_id == 'content' ) {
    return false;
  }
   
  
  
  return $content;
  
}
add_filter( 'ot_tinymce', 'filter_textarea_tinymce', 10, 2 );


/**
 * Initialize the options before anything else. 
 */
add_action( 'admin_init', '_custom_theme_options', 1 );



/**
 * Theme Mode demo code of all the available option types.
 *
 * @return    void
 *
 * @access    private
 * @since     2.0
 */
function _custom_theme_options() {
  
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  include(TEMPLATEPATH . '/library/includes/admin/fonts.php'); 
  
  $google_fonts = get_google_fonts();
    
  foreach ($google_fonts as $font => $value) {
  	$font = array(
    	'label' => $value['label'],
        'value' => $value['value']
    );
    
    
    array_push($google_fonts, $font);
  }
  
  $icons = array(
  'none',
  'icon-glass',
  'icon-music',
  'icon-search',
  'icon-envelope',
  'icon-heart',
  'icon-star',
  'icon-star-empty',
  'icon-user',
  'icon-film',
  'icon-th-large',
  'icon-th',
  'icon-th-list',
  'icon-ok',
  'icon-remove',
  'icon-zoom-in',
  'icon-zoom-out',
  'icon-off',
  'icon-signal',
  'icon-cog',
  'icon-trash',
  'icon-home',
  'icon-file',
  'icon-time',
  'icon-road',
  'icon-download-alt',
  'icon-download',
  'icon-upload',
  'icon-inbox',
  'icon-play-circle',
  'icon-repeat',
  'icon-rotate-right',
  'icon-refresh',
  'icon-list-alt',
  'icon-lock',
  'icon-flag',
  'icon-headphones',
  'icon-volume-off',
  'icon-volume-down',
  'icon-volume-up',
  'icon-qrcode',
  'icon-barcode',
  'icon-tag',
  'icon-tags',
  'icon-book',
  'icon-bookmark',
  'icon-print',
  'icon-camera',
  'icon-font',
  'icon-bold',
  'icon-italic',
  'icon-text-height',
  'icon-text-width',
  'icon-align-left',
  'icon-align-center',
  'icon-align-right',
  'icon-align-justify',
  'icon-list',
  'icon-indent-left',
  'icon-indent-right',
  'icon-facetime-video',
  'icon-picture',
  'icon-pencil',
  'icon-map-marker',
  'icon-adjust',
  'icon-tint',
  'icon-edit',
  'icon-share',
  'icon-check',
  'icon-move',
  'icon-step-backward',
  'icon-fast-backward',
  'icon-backward',
  'icon-play',
  'icon-pause',
  'icon-stop',
  'icon-forward',
  'icon-fast-forward',
  'icon-step-forward',
  'icon-eject',
  'icon-chevron-left',
  'icon-chevron-right',
  'icon-plus-sign',
  'icon-minus-sign',
  'icon-remove-sign',
  'icon-ok-sign',
  'icon-question-sign',
  'icon-info-sign',
  'icon-screenshot',
  'icon-remove-circle',
  'icon-ok-circle',
  'icon-ban-circle',
  'icon-arrow-left',
  'icon-arrow-right',
  'icon-arrow-up',
  'icon-arrow-down',
  'icon-share-alt',
  'icon-mail-forward',
  'icon-resize-full',
  'icon-resize-small',
  'icon-plus',
  'icon-minus',
  'icon-asterisk',
  'icon-exclamation-sign',
  'icon-gift',
  'icon-leaf',
  'icon-fire',
  'icon-eye-open',
  'icon-eye-close',
  'icon-warning-sign',
  'icon-plane',
  'icon-calendar',
  'icon-random',
  'icon-comment',
  'icon-magnet',
  'icon-chevron-up',
  'icon-chevron-down',
  'icon-retweet',
  'icon-shopping-cart',
  'icon-folder-close',
  'icon-folder-open',
  'icon-resize-vertical',
  'icon-resize-horizontal',
  'icon-bar-chart',
  'icon-twitter-sign',
  'icon-facebook-sign',
  'icon-camera-retro',
  'icon-key',
  'icon-cogs',
  'icon-comments',
  'icon-thumbs-up',
  'icon-thumbs-down',
  'icon-star-half',
  'icon-heart-empty',
  'icon-signout',
  'icon-linkedin-sign',
  'icon-pushpin',
  'icon-external-link',
  'icon-signin',
  'icon-trophy',
  'icon-github-sign',
  'icon-upload-alt',
  'icon-lemon',
  'icon-phone',
  'icon-check-empty',
  'icon-bookmark-empty',
  'icon-phone-sign',
  'icon-twitter',
  'icon-facebook',
  'icon-github',
  'icon-unlock',
  'icon-credit-card',
  'icon-rss',
  'icon-hdd',
  'icon-bullhorn',
  'icon-bell',
  'icon-certificate',
  'icon-hand-right',
  'icon-hand-left',
  'icon-hand-up',
  'icon-hand-down',
  'icon-circle-arrow-left',
  'icon-circle-arrow-right',
  'icon-circle-arrow-up',
  'icon-circle-arrow-down',
  'icon-globe',
  'icon-wrench',
  'icon-tasks',
  'icon-filter',
  'icon-briefcase',
  'icon-fullscreen',
  'icon-group',
  'icon-link',
  'icon-cloud',
  'icon-beaker',
  'icon-cut',
  'icon-copy',
  'icon-paper-clip',
  'icon-save',
  'icon-sign-blank',
  'icon-reorder',
  'icon-list-ul',
  'icon-list-ol',
  'icon-strikethrough',
  'icon-underline',
  'icon-table',
  'icon-magic',
  'icon-truck',
  'icon-pinterest',
  'icon-pinterest-sign',
  'icon-google-plus-sign',
  'icon-google-plus',
  'icon-money',
  'icon-caret-down',
  'icon-caret-up',
  'icon-caret-left',
  'icon-caret-right',
  'icon-columns',
  'icon-sort',
  'icon-sort-down',
  'icon-sort-up',
  'icon-envelope-alt',
  'icon-linkedin',
  'icon-undo',
  'icon-rotate-left',
  'icon-legal',
  'icon-dashboard',
  'icon-comment-alt',
  'icon-comments-alt',
  'icon-bolt',
  'icon-sitemap',
  'icon-umbrella',
  'icon-paste',
  'icon-lightbulb',
  'icon-exchange',
  'icon-cloud-download',
  'icon-cloud-upload',
  'icon-user-md',
  'icon-stethoscope',
  'icon-suitcase',
  'icon-bell-alt',
  'icon-coffee',
  'icon-food',
  'icon-file-alt',
  'icon-building',
  'icon-hospital',
  'icon-ambulance',
  'icon-medkit',
  'icon-fighter-jet',
  'icon-beer',
  'icon-h-sign',
  'icon-plus-sign-alt',
  'icon-double-angle-left',
  'icon-double-angle-right',
  'icon-double-angle-up',
  'icon-double-angle-down',
  'icon-angle-left',
  'icon-angle-right',
  'icon-angle-up',
  'icon-angle-down',
  'icon-desktop',
  'icon-laptop',
  'icon-tablet',
  'icon-mobile-phone',
  'icon-circle-blank',
  'icon-quote-left',
  'icon-quote-right',
  'icon-spinner',
  'icon-circle',
  'icon-reply',
  'icon-mail-reply',
  'icon-folder-close-alt',
  'icon-folder-open-alt',
  'icon-expand-alt',
  'icon-collapse-alt',
  'icon-smile',
  'icon-frown',
  'icon-meh',
  'icon-gamepad',
  'icon-keyboard',
  'icon-flag-alt',
  'icon-flag-checkered',
  'icon-terminal',
  'icon-code',
  'icon-reply-all',
  'icon-mail-reply-all',
  'icon-star-half-full',
  'icon-star-half-empty',
  'icon-location-arrow',
  'icon-crop',
  'icon-code-fork',
  'icon-unlink',
  'icon-question',
  'icon-info',
  'icon-exclamation',
  'icon-superscript',
  'icon-subscript',
  'icon-eraser',
  'icon-puzzle-piece',
  'icon-microphone',
  'icon-microphone-off',
  'icon-shield',
  'icon-calendar-empty',
  'icon-fire-extinguisher',
  'icon-rocket',
  'icon-maxcdn',
  'icon-chevron-sign-left',
  'icon-chevron-sign-right',
  'icon-chevron-sign-up',
  'icon-chevron-sign-down',
  'icon-html5',
  'icon-css3',
  'icon-anchor',
  'icon-unlock-alt',
  'icon-bullseye',
  'icon-ellipsis-horizontal',
  'icon-ellipsis-vertical',
  'icon-rss-sign',
  'icon-play-sign',
  'icon-ticket',
  'icon-minus-sign-alt',
  'icon-check-minus',
  'icon-level-up',
  'icon-level-down',
  'icon-check-sign',
  'icon-edit-sign',
  'icon-external-link-sign',
  'icon-share-sign'
  );
  
  asort($icons);
  $new_icons= array();
  foreach ($icons as $icon ) {
  	$icon = array(
  		'label' => substr($icon, 5),
  	    'value' => $icon
  	);
  	
  	
  	array_push($new_icons, $icon);
  }
  
  
 
  $all_settings = array(
   array(
     'label'       => 'Main Logo',
     'id'          => 'logo',
     'type'        => 'upload',
     'desc'        => 'Upload the main logo for your website.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Main Logo Top Margin',
     'id'          => 'logo_margin',
     'type'        => 'text',
     'desc'        => 'Top Margin for the logo for your website, Default:0px.',
     'std'         => '0px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'favicon',
     'id'          => 'favicon',
     'type'        => 'upload',
     'desc'        => 'Upload a 16px x 16px Png/Gif image that will represent your website\'s favicon.',
     'std'         => get_template_directory_uri() .'/favicon.png',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Choose your Homepage',
     'id'          => 'homepage',
     'type'        => 'page-select',
     'desc'        => 'Choose the page to display its content and slider as your homepage.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Preview Mode',
     'id'          => 'preview',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable Preview Mode to test some colors changes in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'no',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Enable SEO',
     'id'          => 'seo',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable Built in SEO Features.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Website Description',
     'id'          => 'web_description',
     'type'        => 'textarea-simple',
     'desc'        => 'Add your website description "it will be used in facebook share".',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   
   array(
     'label'       => 'Contact Page e-mail',
     'id'          => 'contact_page',
     'type'        => 'text',
     'desc'        => 'Add the contact e-email for the contact form.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   
   array(
     'label'       => 'Enable gzip compression',
     'id'          => 'gzip',
     'type'        => 'select',
     'desc'        => 'Enable gzip compression for a better spead loading.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'no',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   
   array(
     'label'       => 'Google Analytics Code',
     'id'          => 'google_analytics',
     'type'        => 'textarea-simple',
     'desc'        => 'Paste your Google Analytics (or other) tracking code here. This will be added into your theme.',
     'std'         => '',
     'rows'        => '10',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Custom CSS Code',
     'id'          => 'custom_css',
     'type'        => 'textarea-simple',
     'desc'        => 'Paste your custom css code.',
     'std'         => '',
     'rows'        => '10',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Custom Javascript Code',
     'id'          => 'custom_js',
     'type'        => 'textarea-simple',
     'desc'        => 'Paste your custom Javascript code.',
     'std'         => '',
     'rows'        => '10',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'general_default'
   ),
   array(
     'label'       => 'Show Top bar',
     'id'          => 'show_top_bar',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable Top Bar in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   array(
     'label'       => 'Responsive',
     'id'          => 'responsive',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable Responsive in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   array(
     'label'       => 'Make the top Bar Fixed',
     'id'          => 'top_bar_fixed',
     'type'        => 'select',
     'desc'        => 'Choose Yes to make the top bar stick on the top in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   array(
     'label'       => 'RTL',
     'id'          => 'rtl',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable RTL in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'no',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   
   
   array(
     'label'       => 'Menu Position',
     'id'          => 'menu',
     'type'        => 'select',
     'desc'        => 'Choose your menu position "side or top, Default: side".',
     'choices'     => array(
       array (
         'label'       => 'Side',
         'value'       => 'side'
       ),
       array (
         'label'       => 'Top',
         'value'       => 'top'
       )
     ),
     'std'         => 'side',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   array(
     'label'       => 'Left Sidebar Enable',
     'id'          => 'left_sidebar_enable',
     'type'        => 'select',
     'desc'        => 'Choose Yes to enable Left Sidebar in your website.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   array(
     'label'       => 'Website Width',
     'id'          => 'website_width',
     'type'        => 'select',
     'desc'        => 'Choose Your website layout Wide or narrow, Default: Wide.',
     'choices'     => array(
       array (
         'label'       => 'Wide i.e. 1170px',
         'value'       => 'wide'
       ),
       array (
         'label'       => 'Narrow i.e 970px',
         'value'       => 'narrow'
       )
     ),
     'std'         => 'wide',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'layout_option'
   ),
   
   //// Stylings
   array(
     'label'       => 'Primary Color',
     'id'          => 'primary_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick a the main color for the theme (default: #d64a2b ).',
     'std'         => 'd64a2b',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Title Color',
     'id'          => 'title_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the title color for the theme (default: #d64a2b ).',
     'std'         => '#d64a2b',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Widget Title Color',
     'id'          => 'widget_title_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the Widget title color for the theme (default: #d64a2b ).',
     'std'         => '#d64a2b',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Breaking News Title Color',
     'id'          => 'breaking_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the Breaking News title color for the theme (default: #d64a2b ).',
     'std'         => '#d64a2b',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Top Bar Background Color',
     'id'          => 'top_bg_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the Top Bar Background Color for the theme (default: #57595a ).',
     'std'         => '#57595a',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Side Menu Background Color',
     'id'          => 'side_bg_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the Side Menu Background Color for the theme (default: #eee ).',
     'std'         => '#eee',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Footer Background Color',
     'id'          => 'footer_bg_color',
     'type'        => 'colorpicker',
     'desc'        => 'Pick the Footer Background Color for the theme (default: #333 ).',
     'std'         => '#333',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   array(
     'label'       => 'Main Background',
     'id'          => 'main_background',
     'type'        => 'background',
     'desc'        => 'Upload the background pattern you want, Default: The wood pattern.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'styling'
   ),
   
   
   //Fonts
   array(
     'label'       => 'Heading Font',
     'id'          => 'heading_font',
     'type'        => 'select',
     'desc'        => 'Select your Header font from the available fonts, Fonts are provided via Google Fonts API',
     'choices'     =>  $google_fonts,
     'std'         => 'Oswald',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Body Font',
     'id'          => 'body_font',
     'type'        => 'select',
     'desc'        => 'Select your body "Default" font from the available fonts, Fonts are provided via Google Fonts API',
     'choices'     =>  $google_fonts,
     'std'         => 'Arial',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Top Menu font size',
     'id'          => 'top_menu_fsize',
     'type'        => 'text',
     'desc'        => 'Add Top Menu font size, Default:13px .',
     'std'         => '13px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Side Menu font size',
     'id'          => 'side_menu_fsize',
     'type'        => 'text',
     'desc'        => 'Add Side Menu font size, Default:16px .',
     'std'         => '16px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Breaking News Title font size',
     'id'          => 'breaking_title_fsize',
     'type'        => 'text',
     'desc'        => 'Add Breaking News Title font size, Default:20px .',
     'std'         => '20px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Breaking News Text font size',
     'id'          => 'breaking_text_fsize',
     'type'        => 'text',
     'desc'        => 'Add Breaking News Text font size., Default:15px ',
     'std'         => '15px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Article Thumb Title font size',
     'id'          => 'article_title_fsize',
     'type'        => 'text',
     'desc'        => 'Add Article Thumb Title font size, Default:22px .',
     'std'         => '22px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Title font size',
     'id'          => 'title_fsize',
     'type'        => 'text',
     'desc'        => 'Add Title font size, Default:16px .',
     'std'         => '16px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Widget Title font size',
     'id'          => 'widget_title_fsize',
     'type'        => 'text',
     'desc'        => 'Add Widget Title font size, Default:16px .',
     'std'         => '16px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Logo font size',
     'id'          => 'logo_fsize',
     'type'        => 'text',
     'desc'        => 'Add Logo font size, Default:80px .',
     'std'         => '80px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   array(
     'label'       => 'Slider Title font size',
     'id'          => 'slider_title_fsize',
     'type'        => 'text',
     'desc'        => 'Add Slider Title font size, Default:25px .',
     'std'         => '25px',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'fonts'
   ),
   
   //// Social
   array(
     'label'       => 'Enable Comments Count in social Box',
     'id'          => 'comments_count_box',
     'type'        => 'select',
     'desc'        => 'Choose Yes to Enable Comments Count in social Box.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Facebook username',
     'id'          => 'facebook',
     'type'        => 'text',
     'desc'        => 'Add your facebook username.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Facebook App ID',
     'id'          => 'facebook_ID',
     'type'        => 'text',
     'desc'        => 'Add your facebook App ID "used for analytics with your likes and social integration".',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Default facebook thumb',
     'id'          => 'facebook_thumb',
     'type'        => 'upload',
     'desc'        => 'Upload the default thumb for your website in facebook sharing, "Mostly showen when sharing your homepage".',
     'std'         => get_template_directory_uri() .'/library/images/thumb.jpg',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   
   array(
     'label'       => 'Twitter username',
     'id'          => 'twitter',
     'type'        => 'text',
     'desc'        => 'Add your twitter username.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Google + profile',
     'id'          => 'google_plus',
     'type'        => 'text',
     'desc'        => 'Add your Google Plus Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Pinterest',
     'id'          => 'pinit',
     'type'        => 'text',
     'desc'        => 'Add your Pinterest Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
  array(
    'label'       => 'Linked In',
    'id'          => 'linkedin',
    'type'        => 'text',
    'desc'        => 'Add your Linked In Profile Link.',
    'std'         => '',
    'rows'        => '',
    'post_type'   => '',
    'taxonomy'    => '',
    'class'       => '',
    'section'     => 'social'
  ),
   array(
     'label'       => 'Flickr profile',
     'id'          => 'flickr',
     'type'        => 'text',
     'desc'        => 'Add your Flickr Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Vimeo profile',
     'id'          => 'vimeo',
     'type'        => 'text',
     'desc'        => 'Add your Vimeo Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Youtube profile',
     'id'          => 'youtube',
     'type'        => 'text',
     'desc'        => 'Add your Youtube Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
   array(
     'label'       => 'Dribbble profile',
     'id'          => 'dribbble',
     'type'        => 'text',
     'desc'        => 'Add your Dribbble Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),   
   array(
     'label'       => 'Behance profile',
     'id'          => 'behance',
     'type'        => 'text',
     'desc'        => 'Add your Behance Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ), 
   array(
     'label'       => 'Instagram profile',
     'id'          => 'instagram',
     'type'        => 'text',
     'desc'        => 'Add your Instagram Profile Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),   
   array(
     'label'       => 'RSS feed Link',
     'id'          => 'rss',
     'type'        => 'text',
     'desc'        => 'Add your RSS Feed Link.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'social'
   ),
  
   
   /// header
   
     array(
       'label'       => 'Top Menu Enable',
       'id'          => 'top_menu',
       'type'        => 'select',
       'desc'        => 'Show Top Menu or Enable Custom Top Menu Area, Default Yes.',
       'choices'     => array(
         array (
           'label'       => 'Yes',
           'value'       => 'yes'
         ),
         array (
           'label'       => 'No',
           'value'       => 'no'
         ),
         array (
           'label'       => 'Custom',
           'value'       => 'custom'
         )
       ),
       'std'         => 'yes',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ), 
     array(
       'label'       => 'Top Menu Custom Area',
       'id'          => 'top_menu_custom',
       'type'        => 'textarea-simple',
       'desc'        => 'Top Menu Custom Area Code Here',
       'std'         => '',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ),
     array(
       'label'       => 'Social Icons Enable',
       'id'          => 'social_icons',
       'type'        => 'select',
       'desc'        => 'Show Social Icons or Enable Custom Social Icons Area, Default Yes.',
       'choices'     => array(
         array (
           'label'       => 'Yes',
           'value'       => 'yes'
         ),
         array (
           'label'       => 'No',
           'value'       => 'no'
         ),
         array (
           'label'       => 'Custom',
           'value'       => 'custom'
         )
       ),
       'std'         => 'yes',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ), 
     array(
       'label'       => 'Social Icons Custom Area',
       'id'          => 'social_icons_custom',
       'type'        => 'textarea-simple',
       'desc'        => 'Social Icons Custom Area Code Here',
       'std'         => '',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ),
     array(
       'label'       => 'Search Button Enable',
       'id'          => 'search',
       'type'        => 'select',
       'desc'        => 'Show Search Button, Default Yes.',
       'choices'     => array(
         array (
           'label'       => 'Yes',
           'value'       => 'yes'
         ),
         array (
           'label'       => 'No',
           'value'       => 'no'
         )
       ),
       'std'         => 'yes',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ), 
     array(
       'label'       => 'Top Ad Enable',
       'id'          => 'ad_728x90_enable',
       'type'        => 'select',
       'desc'        => 'Show Ad 728x90, Default Yes.',
       'choices'     => array(
         array (
           'label'       => 'Yes 728x90',
           'value'       => 'yes'
         ),
         array (
           'label'       => 'Yes 468x60',
           'value'       => 'yes_468x60'
         ),
         array (
           'label'       => 'No',
           'value'       => 'no'
         )
       ),
       'std'         => 'yes',
       'rows'        => '',
       'post_type'   => '',
       'taxonomy'    => '',
       'class'       => '',
       'section'     => 'header'
     ), 
   array(
     'label'       => 'Ad 728x90',
     'id'          => 'ad_728x90',
     'type'        => 'textarea-simple',
     'desc'        => 'Top Ad - Add the Ad Code Here',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'header'
   ), 
   array(
     'label'       => 'Ad 320x50',
     'id'          => 'ad_320x50',
     'type'        => 'textarea-simple',
     'desc'        => 'Mobile Ad - Add the Ad Code Here',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'header'
   ),   
   /// Article Settings
   array(
     'label'       => 'Slider Image Size',
     'id'          => 'slider_size',
     'type'        => 'select',
     'desc'        => 'Select Slider Image Size for your theme',
     'choices'     => array(
       array (
         'label'       => '700x450',
         'value'       => '700'
       ),
       array (
         'label'       => '640x300',
         'value'       => '590'
       )
     ),
     'std'         => '700',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Meta Data Options',
     'id'          => 'single_meta_style',
     'type'        => 'select',
     'desc'        => 'Select the view for your meta data, Default: Block Style',
     'choices'     => array(
       array (
         'label'       => 'Block Style',
         'value'       => 'block'
       ),
       array (
         'label'       => 'Line Style',
         'value'       => 'line'
       )
     ),
     'std'         => 'block',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Time/Date Display Options',
     'id'          => 'time_date',
     'type'        => 'select',
     'desc'        => 'Select the Format for time display',
     'choices'     => array(
       array (
         'label'       => 'Month - Day - Year',
         'value'       => 'month'
       ),
       array (
         'label'       => 'Month - Day - Year - Clock',
         'value'       => 'clock'
       )
     ),
     'std'         => 'month',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Like System Enable',
     'id'          => 'like_enable',
     'type'        => 'select',
     'desc'        => 'Select use the Like system or not',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Related Posts Enable',
     'id'          => 'related_enable',
     'type'        => 'select',
     'desc'        => 'Select use the Like system or not',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Tags  Enable',
     'id'          => 'tags_enable',
     'type'        => 'select',
     'desc'        => 'Select use the Like system or not',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Featured Media Enable',
     'id'          => 'featured_enable',
     'type'        => 'select',
     'desc'        => 'Featured Media inside Article Enable',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Social Share Enable',
     'id'          => 'social_share_enable',
     'type'        => 'select',
     'desc'        => 'Social Share Enable',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Comments Section Enable',
     'id'          => 'comments_enable',
     'type'        => 'select',
     'desc'        => 'Select to include the comments section or not',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Comments Section Order',
     'id'          => 'comments_order',
     'type'        => 'select',
     'desc'        => 'Select the Comments Order in your article, Default: Facebook - WP Comments',
     'choices'     => array(
       array (
         'label'       => 'Facebook - WP Comments',
         'value'       => 'facebook_comments'
       ),
       array (
         'label'       => 'WP Comments - Facebook',
         'value'       => 'comments_facebook'
       )
     ),
     'std'         => 'facebook_comments',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   array(
     'label'       => 'Enable Facebook Comments',
     'id'          => 'facebook_comments',
     'type'        => 'select',
     'desc'        => 'Show Facebook Comments Section? Default Yes.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
    
   array(
     'label'       => 'Facebook Color',
     'id'          => 'facebook_color',
     'type'        => 'select',
     'desc'        => 'Select Facebook Color Mode. Default Light.',
     'choices'     => array(
       array (
         'label'       => 'Light',
         'value'       => 'light'
       ),
       array (
         'label'       => 'Dark',
         'value'       => 'dark'
       )
     ),
     'std'         => 'light',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ), 
   
   
   array(
     'label'       => 'Default Thumbnail for Commenter',
     'id'          => 'avatar',
     'type'        => 'upload',
     'desc'        => 'Upload Default Thumbnail for Commenters.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article'
   ),
   
  
   array(
     'label'       => 'Select The Categories you want to set special comaprison settings',
     'id'          => 'article_com_cat',
     'type'        => 'category-checkbox',
     'desc'        => 'Check the categories you want to set special comparison . Default No.  <br /><p>Note Please click refersh after save to be able to view all the categories options</p>',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article_comp'
   ), 
   
   
   //// Items Settings
   array(
     'label'       => 'Featured Media Enable',
     'id'          => 'featured_enable_item',
     'type'        => 'select',
     'desc'        => 'Featured Media inside Article Enable',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'item'
   ),
   array(
     'label'       => 'Category Page Top Slider',
     'id'          => 'category_slider_item',
     'type'        => 'select',
     'desc'        => 'Choose Your Slider type for the category page.',
     'choices'     => array(
       array (
         'label'       => 'Latest Articles',
         'value'       => 'latest'
       ),
       array (
         'label'       => 'No Slider',
         'value'       => 'none'
       )
     ),
     'std'         => 'latest',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'item'
   ),
   
   array(
     'label'       => 'Category Articles Display Style',
     'id'          => 'category_type_item',
     'type'        => 'select',
     'desc'        => 'Choose Your articles display type for the category page.',
     'choices'     => array(
       array (
         'label'       => 'Blog Style 1',
         'value'       => '1'
       ),
       array (
         'label'       => 'Blog Style 2',
         'value'       => '2'
       ),
       array (
         'label'       => 'Blog Style 3',
         'value'       => '3'
       ),
       array (
         'label'       => 'Blog Style 4',
         'value'       => '4'
       ),
       array (
         'label'       => 'Blog Style 5',
         'value'       => '5'
       )
     ),
     'std'         => '1',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'item'
   ),
   
   
   array(
     'label'       => 'Categories',
     'id'          => 'categories_item',
     'type'        => 'list-item',
     'desc'        => 'Add Categories Colors & Icons.',
     'settings'    => array(
     
     
       array(
         'label'       => 'Category',
         'id'          => 'category',
         'type'        => 'taxonomy-select',
         'desc'        => 'Select the category',
         'choices'     => '',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => 'item_type',
         'class'       => '',
       )
       ,array(
         'label'       => 'Color',
         'id'          => 'color',
         'type'        => 'colorpicker',
         'desc'        => 'Pick a category color(default: #d64a2b ).',
         'std'         => '#d64a2b ',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Icon',
         'id'          => 'icon',
         'type'        => 'select',
         'desc'        => 'Choose Your Icon.',
         'choices'     => $new_icons,
         'std'         => 'tag',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Layout Style',
         'id'          => 'layout',
         'type'        => 'select',
         'desc'        => 'Choose Your Category Page Layout.',
         'choices'     => array(
           array (
             'label'       => 'Right Sidebar',
             'value'       => 'right'
           ),
           array (
             'label'       => 'Full Width',
             'value'       => 'full'
           )
         ),
         'std'         => 'right',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Category Page Background',
         'id'          => 'background',
         'type'        => 'background',
         'desc'        => 'Upload the background pattern you want for the category page',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       ),
     ),
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'item'
   ),
   
  
   
    array(
      'label'       => 'Select The Categories you want to set special comaprison settings',
      'id'          => 'item_com_cat',
      'type'        => 'taxonomy-checkbox',
      'desc'        => 'Check the categories you want to set special comparison settings. Default No.  <br /><p>Note Please click refersh after save to be able to view all the categories options</p>',
      'std'         => '',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => 'item_type',
      'class'       => '',
      'section'     => 'item_comp'
    ), 
    
   
   
   /// Breaking News
   
   array(
     'label'       => 'Breaking News Enable',
     'id'          => 'breaking_enable',
     'type'        => 'select',
     'desc'        => 'Show Breaking News Section? Default Yes.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   array(
     'label'       => 'Breaking News Title',
     'id'          => 'breaking-news-title',
     'type'        => 'text',
     'desc'        => 'Add The Text you want to appear beside the section, Default Breaking News.',
     'std'         => 'Breaking News',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ), 
   array(
     'label'       => 'Breaking News Data',
     'id'          => 'breaking_data',
     'type'        => 'select',
     'desc'        => 'Select the source for the custom posts.',
     'choices'     => array(
       array (
         'label'       => 'Latest 10 Articles',
         'value'       => 'latest'
       ),
       array (
         'label'       => 'Popular 10 Articles',
         'value'       => 'popular'
       ),
       array (
         'label'       => 'Latest 10 Articles From Category "Choose Below"',
         'value'       => 'category'
       ),
       array (
         'label'       => 'Latest 10 Articles From Tag "Choose Below"',
         'value'       => 'tag'
       ),
       array (
         'label'       => 'Manually Select the Articles "Choose Below"',
         'value'       => 'manual'
       ),
       array (
         'label'       => 'Manually add text, Add Below',
         'value'       => 'text'
       )
     ),
     'std'         => 'latest',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   array(
     'label'       => 'Category',
     'id'          => 'breaking_category',
     'type'        => 'category-select',
     'desc'        => 'Select the category',
     'choices'     => '',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   array(
     'label'       => 'Tag',
     'id'          => 'breaking_tag',
     'type'        => 'tag-select',
     'desc'        => 'Select the tag',
     'choices'     => '',
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   
   array(
     'label'       => 'Custom Text',
     'id'          => 'breaking_text',
     'type'        => 'list-item',
     'desc'        => 'Add Custom Text.',
     'settings'    => array(
       array(
         'label'       => 'Custom Text',
         'id'          => 'text',
         'type'        => 'textarea-simple',
         'desc'        => 'Add Your Custom Text',
         'choices'     => '',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       ),
     ),
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   array(
     'label'       => 'The News',
     'id'          => 'breaking_news',
     'type'        => 'list-item',
     'desc'        => 'Add The Articles You want to appear in The Breaking News Section, if not set we will show for you the latest 10 Articles.',
     'settings'    => array(
       array(
         'label'       => 'Choose the post',
         'id'          => 'breaking_post',
         'type'        => 'text',
         'desc'        => 'Add the Post ID Add to the breaking news section.',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       )
     ),
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'breaking-news'
   ),
   
   //// Categories
   array(
     'label'       => 'Category Hover Image Type',
     'id'          => 'hover_view',
     'type'        => 'select',
     'desc'        => 'Choose Your Hover Type for the category elements.',
     'choices'     => array(
       array (
         'label'       => 'Enlarge Image',
         'value'       => 'view'
       ),
       array (
         'label'       => 'Permalink to Article',
         'value'       => 'link'
       ),
       array (
         'label'       => 'No Hover',
         'value'       => 'none'
       )
     ),
     'std'         => 'view',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'categories'
   ),
   array(
     'label'       => 'Category Page Top Slider',
     'id'          => 'category_slider',
     'type'        => 'select',
     'desc'        => 'Choose Your Slider type for the category page.',
     'choices'     => array(
       array (
         'label'       => 'Latest Articles',
         'value'       => 'latest'
       ),
       array (
         'label'       => 'Popular Articles',
         'value'       => 'popular'
       ),
       array (
         'label'       => 'No Slider',
         'value'       => 'none'
       )
     ),
     'std'         => 'popular',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'categories'
   ),
   
   array(
     'label'       => 'Category Articles Display Style',
     'id'          => 'category_type',
     'type'        => 'select',
     'desc'        => 'Choose Your articles display type for the category page.',
     'choices'     => array(
       array (
         'label'       => 'Blog Style 1',
         'value'       => '1'
       ),
       array (
         'label'       => 'Blog Style 2',
         'value'       => '2'
       ),
       array (
         'label'       => 'Blog Style 3',
         'value'       => '3'
       ),
       array (
         'label'       => 'Blog Style 4',
         'value'       => '4'
       ),
       array (
         'label'       => 'Blog Style 5',
         'value'       => '5'
       )
     ),
     'std'         => '1',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'categories'
   ),
   array(
     'label'       => 'Default Display Style',
     'id'          => 'result_type',
     'type'        => 'select',
     'desc'        => 'Choose Your Default Display type for Tags/Search/Date.',
     'choices'     => array(
       array (
         'label'       => 'Blog Style 1',
         'value'       => '1'
       ),
       array (
         'label'       => 'Blog Style 2',
         'value'       => '2'
       ),
       array (
         'label'       => 'Blog Style 5',
         'value'       => '5'
       )
     ),
     'std'         => '1',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'categories'
   ),
   
   
   array(
     'label'       => 'Categories',
     'id'          => 'categories',
     'type'        => 'list-item',
     'desc'        => 'Add Categories Colors & Icons.',
     'settings'    => array(
     
     
       array(
         'label'       => 'Category',
         'id'          => 'category',
         'type'        => 'category-select',
         'desc'        => 'Select the category',
         'choices'     => '',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       )
       ,array(
         'label'       => 'Color',
         'id'          => 'color',
         'type'        => 'colorpicker',
         'desc'        => 'Pick a category color(default: #d64a2b ).',
         'std'         => '#d64a2b ',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Icon',
         'id'          => 'icon',
         'type'        => 'select',
         'desc'        => 'Choose Your Icon.',
         'choices'     => $new_icons,
         'std'         => 'tag',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Layout Style',
         'id'          => 'layout',
         'type'        => 'select',
         'desc'        => 'Choose Your Category Page Layout.',
         'choices'     => array(
           array (
             'label'       => 'Right Sidebar',
             'value'       => 'right'
           ),
           array (
             'label'       => 'Full Width',
             'value'       => 'full'
           )
         ),
         'std'         => 'right',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => '',
       ),
       array(
         'label'       => 'Category Page Background',
         'id'          => 'background',
         'type'        => 'background',
         'desc'        => 'Upload the background pattern you want for the category page',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       ),
     ),
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'categories'
   ),
   
       
   ////Sidebars
   array(
     'label'       => 'Sidebars',
     'id'          => 'sidebars',
     'type'        => 'list-item',
     'desc'        => 'Add Unlimited Sidebars to your website.',
     'settings'    => array(
       array(
         'label'       => 'Slug',
         'id'          => 'slug',
         'type'        => 'text',
         'desc'        => 'Sidebar Slug "All lowercase and must be unique".',
         'std'         => '',
         'rows'        => '',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       ),
       array(
         'label'       => 'Description',
         'id'          => 'description',
         'type'        => 'textarea-simple',
         'desc'        => 'Sidebar Description.',
         'std'         => '',
         'rows'        => '5',
         'post_type'   => '',
         'taxonomy'    => '',
         'class'       => ''
       )
     ),
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'sidebars'
   ),
   array(
     'label'       => 'Enable Footer',
     'id'          => 'footer_enable',
     'type'        => 'select',
     'desc'        => 'Enable Footer? Default Yes.',
     'choices'     => array(
       array (
         'label'       => 'Yes',
         'value'       => 'yes'
       ),
       array (
         'label'       => 'No',
         'value'       => 'no'
       )
     ),
     'std'         => 'yes',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'footer'
   ),
   array(
     'label'       => 'Choose your footer.',
     'id'          => 'footer_template',
     'type'        => 'custom-post-type-select',
     'desc'        => 'Choose your footer from the templates you created.',
     'std'         => '',
     'rows'        => '',
     'post_type'   => 'template',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'footer'
     
   )
   
   );  
  
  
  
  
  $cat_settings = array(
  	array(
      'label'       => 'Slug',
      'id'          => 'slug',
      'type'        => 'text',
      'desc'        => 'Enter the meta data slug "should be in english".',
      'std'         => '',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => '',
    ),
    array(
      'label'       => 'Icon',
      'id'          => 'icon',
      'type'        => 'select',
      'desc'        => 'Choose Your Meta data Icon.',
      'choices'     => $new_icons,
      'std'         => 'tag',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => '',
    ),
    array(
      'label'       => 'Title Show',
      'id'          => 'title_show',
      'type'        => 'select',
      'desc'        => 'Select the way to show the title',
      'choices'     => array(
        array (
          'label'       => 'Icon with text as tooltip',
          'value'       => 'icon_tooltip'
        ),
        array (
          'label'       => 'Just Icon',
          'value'       => 'icon'
        ),
        array (
          'label'       => 'Just Text',
          'value'       => 'text'
        ),
        array (
          'label'       => 'None',
          'value'       => 'none'
        )
      ),
      'std'         => 'icon_tooltip',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => '',
    ),
    array(
      'label'       => 'Data type',
      'id'          => 'type',
      'type'        => 'select',
      'desc'        => 'Choose Your Meta data type.',
      'choices'     => array(
        array (
          'label'       => 'Title',
          'value'       => 'title'
        ),
        array (
          'label'       => 'Text',
          'value'       => 'text'
        )
      ),
      'std'         => 'text',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => '',
    )
  );
  
  $array = array(
    'label'       => 'Common Meta data',
    'id'          => 'custom_meta_item_all',
    'type'        => 'list-item',
    'desc'        => 'Add Meta data to include, Note: this data will be used in the compairing.',
    'settings'    => $cat_settings,
    'std'         => '',
    'rows'        => '',
    'post_type'   => '',
    'taxonomy'    => '',
    'class'       => '',
    'section'     => 'item_comp'
  );
  
  array_push($all_settings, $array);
  
  $item_com_cat = ot_get_option( 'item_com_cat');
  
  if(is_array($item_com_cat)){
  
  		foreach ($item_com_cat as $key => $cat_id) {
  			
  			$category = get_term( $cat_id, 'item_type' );
  			$array = array(
  			  'label'       => $category->name. ' Meta data',
  			  'id'          => 'custom_meta_item_'. $category->term_id,
  			  'type'        => 'list-item',
  			  'desc'        => 'Add Meta data to include, Note: this data will be used in the compairing.',
  			  'settings'    => $cat_settings,
  			  'std'         => '',
  			  'rows'        => '',
  			  'post_type'   => '',
  			  'taxonomy'    => '',
  			  'class'       => '',
  			  'section'     => 'item_comp'
  			);
  			
  			array_push($all_settings, $array);
  			
  		}
  
  }		
  		
 
  
  $array = array(
     'label'       => 'Common Meta data',
     'id'          => 'custom_meta_all',
     'type'        => 'list-item',
     'desc'        => 'Add Meta data to include, Note: this data will be used in the compairing.',
     'settings'    => $cat_settings,
     'std'         => '',
     'rows'        => '',
     'post_type'   => '',
     'taxonomy'    => '',
     'class'       => '',
     'section'     => 'article_comp'
   );
   
   array_push($all_settings, $array);
   
  $article_com_cat = ot_get_option( 'article_com_cat');
  
  if(is_array($article_com_cat)){
  
  		foreach ($article_com_cat as $key => $cat_id) {
  			
  			$category = get_category($cat_id);
  			
  			$array = array(
  			  'label'       => $category->name. ' Meta data',
  			  'id'          => 'custom_meta_'. $category->term_id,
  			  'type'        => 'list-item',
  			  'desc'        => 'Add Meta data to include, Note: this data will be used in the compairing.',
  			  'settings'    => $cat_settings,
  			  'std'         => '',
  			  'rows'        => '',
  			  'post_type'   => '',
  			  'taxonomy'    => '',
  			  'class'       => '',
  			  'section'     => 'article_comp'
  			);
  			
  			array_push($all_settings, $array);
  			
  		}
  
  }
  
  /**
   * Create a custom settings array that we pass to 
   * the OptionTree Settings API Class.
   */
  $custom_settings = array(
    'contextual_help' => array(
      'content'       => array( 
        array(
          'id'        => 'general_help',
          'title'     => 'General',
          'content'   => ''
        )
      ),
      'sidebar'       => ''
    ),
    'sections'        => array(
      array(
        'title'       => 'General Settings',
        'id'          => 'general_default'
      ),
      array(
        'title'       => 'Layout Options',
        'id'          => 'layout_option'
      ),
      array(
        'title'       => 'Header Options',
        'id'          => 'header'
      ),
      array(
        'title'       => 'Colors Options',
        'id'          => 'styling'
      ),
      array(
        'title'       => 'Fonts Options',
        'id'          => 'fonts'
      ),
      
      array(
        'title'       => 'Social Settings ',
        'id'          => 'social'
      ),
      array(
        'title'       => 'Breaking News',
        'id'          => 'breaking-news'
      ),
      array(
        'title'       => 'Article Settings',
        'id'          => 'article'
      ),
      array(
        'title'       => 'Article Comparison Settings',
        'id'          => 'article_comp'
      ),
      array(
        'title'       => 'Items Settings',
        'id'          => 'item'
      ),
      array(
        'title'       => 'Items Comparison Settings',
        'id'          => 'item_comp'
      ),
      array(
        'title'       => 'Category',
        'id'          => 'categories'
      ),
      array(
        'title'       => 'Sidebars',
        'id'          => 'sidebars'
      ),
      array(
        'title'       => 'Footer Settings',
        'id'          => 'footer'
      )
    ),
    'settings'        => $all_settings
  );
  
    
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}