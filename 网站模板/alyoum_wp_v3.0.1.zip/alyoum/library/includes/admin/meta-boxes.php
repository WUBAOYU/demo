<?php
/**
 * Initialize the meta boxes. 
 */
add_action( 'admin_init', '_custom_meta_boxes' );

/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types
 * in demo-theme-options.php.
 *
 * @return    void
 *
 * @access    private
 * @since     2.0
 */
function _custom_meta_boxes() {
  
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
   
   $sidebars_new = ot_get_option( 'sidebars', array() );
   
  $sidebars= array(
  	array(
  		'label' => 'Default',
  		'value' => 'default'
  	),
  	array(
  		'label' => 'Primary Sidebar',
  		'value' => 'primary'
  	),
  	array(
  		'label' => 'Post Sidebar',
  		'value' => 'post'
  	),
  	array(
  		'label' => 'Page Sidebar',
  		'value' => 'page'
  	)
  );
  
  $left_sidebars= array(
  	array(
  		'label' => 'Default',
  		'value' => 'default'
  	),
  	array(
  		'label' => 'Primary Sidebar',
  		'value' => 'left-default'
  	),
  	array(
  		'label' => 'Post Sidebar',
  		'value' => 'left-post'
  	),
  	array(
  		'label' => 'Page Sidebar',
  		'value' => 'left-page'
  	)
  );
  
  foreach ($sidebars_new as $sidebar_new) {
  	$array=array(
  		'label' => $sidebar_new['title'],
  		'value' => $sidebar_new['slug']
  	);
  	array_push($sidebars, $array);
  	array_push($left_sidebars, $array);
  	
  }
  
  $article_meta_array = array();
  $counter = 1;
  
  
  $data = ot_get_option('custom_meta_all');
  if(is_array($data)){
  	
  			foreach ($data as $meta) {
  				if($meta['type']=='title'){
  					$array = array(
  						'label'       => '#'.$counter.' - common - '.$meta['title'],
  						'id'          => 'meta_list_all_'.$meta['slug'],
  						'type'        => 'text',
  						'desc'        => 'Add '.$meta['title'].' title.',
  						'std'         => '',
  						'rows'        => '',
  						'post_type'   => '',
  						'taxonomy'    => '',
  						'class'       => ''
  					);
  				}else {
  					$array = array(
  						'label'       => '#'.$counter.' - common - '.$meta['title'],
  						'id'          => 'meta_list_all_'.$meta['slug'],
  						'type'        => 'textarea',
  						'desc'        => 'Add '.$meta['title'].' text, HTML, Shortcode accepted.',
  						'std'         => '',
  						'rows'        => '',
  						'post_type'   => '',
  						'taxonomy'    => '',
  						'class'       => ''
  					);
  				}
  				array_push($article_meta_array, $array);
  				$counter++;
  	
  			}
  
  }
  
  
  $item_meta_array = array();
  $counter = 1;
  
  
  $data = ot_get_option('custom_meta_item_all');
  if(is_array($data)){
  	
  			foreach ($data as $meta) {
  				if($meta['type']=='title'){
  					$array = array(
  						'label'       => '#'.$counter.' - common - '.$meta['title'],
  						'id'          => 'meta_list_item_all_'.$meta['slug'],
  						'type'        => 'text',
  						'desc'        => 'Add '.$meta['title'].' title.',
  						'std'         => '',
  						'rows'        => '',
  						'post_type'   => '',
  						'taxonomy'    => '',
  						'class'       => ''
  					);
  				}else {
  					$array = array(
  						'label'       => '#'.$counter.' - common - '.$meta['title'],
  						'id'          => 'meta_list_item_all_'.$meta['slug'],
  						'type'        => 'textarea',
  						'desc'        => 'Add '.$meta['title'].' text, HTML, Shortcode accepted.',
  						'std'         => '',
  						'rows'        => '',
  						'post_type'   => '',
  						'taxonomy'    => '',
  						'class'       => ''
  					);
  				}
  				array_push($item_meta_array, $array);
  				$counter++;
  	
  			}
  
  }
  
  
  
  $post_categories = ot_get_option( 'article_com_cat');	
  if(is_array($post_categories)){
  	foreach($post_categories as $key => $c){
  	
  	$data = ot_get_option('custom_meta_' . $c);
  	if(is_array($data)){
  		
  				foreach ($data as $meta) {
  					if($meta['type']=='title'){
  						$array = array(
  							'label'       => '#'.$counter.' - '.$cat->name.' - '.$meta['title'],
  							'id'          => 'meta_list_cat'.$c.'_'.$meta['slug'],
  							'type'        => 'text',
  							'desc'        => 'Add '.$meta['title'].' title.',
  							'std'         => '',
  							'rows'        => '',
  							'post_type'   => '',
  							'taxonomy'    => '',
  							'class'       => ''
  						);
  					}else {
  						$array = array(
  							'label'       => '#'.$counter.' - '.$cat->name.' - '.$meta['title'],
  							'id'          => 'meta_list_cat'.$c.'_'.$meta['slug'],
  							'type'        => 'textarea',
  							'desc'        => 'Add '.$meta['title'].' text, HTML, Shortcode accepted.',
  							'std'         => '',
  							'rows'        => '',
  							'post_type'   => '',
  							'taxonomy'    => '',
  							'class'       => ''
  						);
  					}
  					array_push($article_meta_array, $array);
  					$counter++;
  		
  				}
  	
  	}
  	
  }
  }
  
   $post_categories = ot_get_option( 'item_com_cat');	
   if(is_array($post_categories)){
   		foreach($post_categories as $key => $c){
   	
   	$single_cat = get_term( $c, 'item_type' );
   		
   	$data = ot_get_option('custom_meta_item_' . $c);
   	if(is_array($data)){
   				foreach ($data as $meta) {
   					if($meta['type']=='title'){
   						$array = array(
   							'label'       => '#'.$counter.' - '.$single_cat->name.' - '.$meta['title'],
   							'id'          => 'meta_list_item_cat'.$c.'_'.$meta['slug'],
   							'type'        => 'text',
   							'desc'        => 'Add '.$meta['title'].' title.',
   							'std'         => '',
   							'rows'        => '',
   							'post_type'   => '',
   							'taxonomy'    => '',
   							'class'       => ''
   						);
   					}else {
   						$array = array(
   							'label'       => '#'.$counter.' - '.$single_cat->name.' - '.$meta['title'],
   							'id'          => 'meta_list_item_cat'.$c.'_'.$meta['slug'],
   							'type'        => 'textarea',
   							'desc'        => 'Add '.$meta['title'].' text, HTML, Shortcode accepted.',
   							'std'         => '',
   							'rows'        => '',
   							'post_type'   => '',
   							'taxonomy'    => '',
   							'class'       => ''
   						);
   					}
   					array_push($item_meta_array, $array);
   					$counter++;
   		
   				}
   	
   	}
   }
    }
   
    
 
   
   if(is_array($article_meta_array)){
   		
   		$article_meta_list_register = array(
   		  'id'          => 'article_list',
   		  'title'       => 'Article Meta Settings',
   		  'desc'        => '',
   		  'pages'       => array( 'post'),
   		  'context'     => 'normal',
   		  'priority'    => 'high',
   		  'fields'      => $article_meta_array
   		);
   }
   
   
    if(is_array($item_meta_array)){
    
    		$item_meta_list_register = array(
    		  'id'          => 'item_list',
    		  'title'       => 'Item Meta Settings',
    		  'desc'        => '',
    		  'pages'       => array( 'item'),
    		  'context'     => 'normal',
    		  'priority'    => 'high',
    		  'fields'      => $item_meta_array
    		);
    }
    
   
  $general = array(
    'id'          => 'general',
    'title'       => 'General Settings',
    'desc'        => '',
    'pages'       => array( 'post', 'page','item' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Layout',
        'id'          => 'meta_layout',
        'type'        => 'select',
        'desc'        => 'Choose your Layout, Default: Right sidebar.',
        'choices'     => array(
          array(
            'label'       => 'Right Sidebar',
            'value'       => 'right'
          ),
          array(
            'label'       => 'Left Sidebar',
            'value'       => 'left'
          ),
          array(
            'label'       => 'Full Width',
            'value'       => 'full'
          )
        ),
        'std'         => 'right',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Sidebar',
        'id'          => 'meta_sidebar',
        'type'        => 'select',
        'desc'        => 'Select the Page sidebar.',
        'choices'     => $sidebars,
        'std'         => 'default',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Left Sidebar',
        'id'          => 'meta_left_sidebar',
        'type'        => 'select',
        'desc'        => 'Select the Left Page sidebar.',
        'choices'     => $left_sidebars,
        'std'         => 'default',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Breaking News Bar',
        'id'          => 'meta_breaking',
        'type'        => 'select',
        'desc'        => 'Show/Hide the Breaking news bar in this page: Default: Yes',
        'choices'     => array(
          array(
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array(
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'yes',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
  	)
  );
  
  
  
  
  $stylings = array(
    'id'          => 'meta_styling',
    'title'       => 'Styling Settings',
    'desc'        => '',
    'pages'       => array( 'post', 'page' ,'item'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Background',
        'id'          => 'meta_background',
        'type'        => 'background',
        'desc'        => 'Add Custom Background only for this page.',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      
      array(
        'label'       => 'Custom Color',
        'id'          => 'meta_custom_color',
        'type'        => 'colorpicker',
        'desc'        => 'Pick a Primary color for the theme ',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
  	)
  );
  
  
  $meta_gallery_slider = array(
    'id'          => 'meta_gallery_slider',
    'title'       => 'Post Format Settings',
    'desc'        => '',
    'pages'       => array( 'post'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Post Format Slides => Gallery',
        'id'          => 'meta_slides_post_type',
        'type'        => 'list-item',
        'desc'        => 'Add Slides to your page.',
        'settings'    => array(
          array(
            'label'       => 'Upload',
            'id'          => 'image',
            'type'        => 'upload',
            'desc'        => 'The Main image for the slide "At least to have width 760px".',
            'std'         => '',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => ''
          )
        ),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Video ID',
        'id'          => 'meta_attachment',
        'type'        => 'text',
        'desc'        => 'Add ID related the the Video Format.',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Video Type',
        'id'          => 'meta_video_type',
        'type'        => 'select',
        'desc'        => 'Choose the video type in case of video posts, then enter the video id for youtube,dailymotion and vimeo',
        'choices'     => array(
          array(
            'label'       => 'Youtube',
            'value'       => 'youtube'
          ),
          array(
            'label'       => 'Dailymotion',
            'value'       => 'dailymotion'
          ),
          array(
            'label'       => 'Vimeo',
            'value'       => 'vimeo'
          )
        ),
        'std'         => 'vimeo',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Audio Link or Soundcloud id',
        'id'          => 'meta_audio_attachment',
        'type'        => 'text',
        'desc'        => 'Add Audio Link or Soundcloud id.',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Audio Type',
        'id'          => 'meta_audio_type',
        'type'        => 'select',
        'desc'        => 'Choose the video type in case of video posts, then enter the video id for youtube,dailymotion and vimeo',
        'choices'     => array(
          array(
            'label'       => 'Audio file',
            'value'       => 'audio'
          ),
          array(
            'label'       => 'Sound Cloud',
            'value'       => 'soundcloud'
          )
        ),
        'std'         => 'soundcloud',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
  	,
  	array(
  	  'label'       => 'Metro View',
  	  'id'          => 'meta_metro',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro View of the Flip Card If you choosed Metro Elements.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Photo',
  	      'value'       => 'photo'
  	    ),
  	    array(
  	      'label'       => 'Details',
  	      'value'       => 'details'
  	    )
  	  ),
  	  'std'         => 'photo',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	),
  	array(
  	  'label'       => 'Metro View Size',
  	  'id'          => 'meta_metro_size',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro size of the element View.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Large',
  	      'value'       => 'large'
  	    ),
  	    array(
  	      'label'       => 'Medium',
  	      'value'       => 'medium'
  	    ),
  	    array(
  	      'label'       => 'Wide',
  	      'value'       => 'wide'
  	    ),
  	    array(
  	      'label'       => 'Tall',
  	      'value'       => 'tall'
  	    )
  	  ),
  	  'std'         => 'medium',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	)
  	)
  );
  
  
  $meta_items_metro = array(
    'id'          => 'meta_items_metro',
    'title'       => 'Metro Settings',
    'desc'        => '',
    'pages'       => array( 'item'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      
  	array(
  	  'label'       => 'Metro View',
  	  'id'          => 'meta_metro',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro View of the Flip Card If you choosed Metro Elements.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Photo',
  	      'value'       => 'photo'
  	    ),
  	    array(
  	      'label'       => 'Details',
  	      'value'       => 'details'
  	    )
  	  ),
  	  'std'         => 'photo',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	),
  	array(
  	  'label'       => 'Metro View Size',
  	  'id'          => 'meta_metro_size',
  	  'type'        => 'select',
  	  'desc'        => 'Choose the Metro size of the element View.',
  	  'choices'     => array(
  	    array(
  	      'label'       => 'Large',
  	      'value'       => 'large'
  	    ),
  	    array(
  	      'label'       => 'Medium',
  	      'value'       => 'medium'
  	    ),
  	    array(
  	      'label'       => 'Wide',
  	      'value'       => 'wide'
  	    ),
  	    array(
  	      'label'       => 'Tall',
  	      'value'       => 'tall'
  	    )
  	  ),
  	  'std'         => 'medium',
  	  'rows'        => '',
  	  'post_type'   => '',
  	  'taxonomy'    => '',
  	  'class'       => ''
  	)
  	)
  );
    
  
  
  $slides_type = array(
    'id'          => 'slider',
    'title'       => 'Slider Settings',
    'desc'        => '',
    'pages'       => array( 'slides'),
    'context'     => 'side',
    'priority'    => 'low',
    'fields'      => array(
          array(
            'label'       => 'Button link',
            'id'          => 'slides_readmore',
            'type'        => 'text',
            'desc'        => 'Add the link for the button, leave blank to remove the button.',
            'std'         => '',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => ''
          ),
          array(
            'label'       => 'Slide Type',
            'id'          => 'meta_slide_float_type',
            'type'        => 'select',
            'desc'        => 'Choose the Slide type Right or Left "We float the image"',
            'choices'     => array(
              array(
                'label'       => 'Left Side',
                'value'       => 'left'
              ),
              array(
                'label'       => 'Right Side',
                'value'       => 'right'
              )
            ),
            'std'         => 'left',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => ''
          )
          
  	)
  );
  
  
   $slider_video = array(
    'id'          => 'meta_slider_video',
    'title'       => 'Slide Settings',
    'desc'        => '',
    'pages'       => array( 'slides'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Slide Type',
        'id'          => 'meta_slide_type',
        'type'        => 'select',
        'desc'        => 'Choose the slide type',
        'choices'     => array(
          array(
            'label'       => '1- Use Featured Image as a background and the title and content as the box',
            'value'       => 'type_1'
          ),
          array(
            'label'       => '2- Use video fields as the source for the slide',
            'value'       => 'type_2'
          ),
          array(
            'label'       => '3- Get the slide content from a post, Choose it from the dropdown below',
            'value'       => 'type_3'
          )
        ),
        'std'         => 'type_1',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Choose the post',
        'id'          => 'meta_slide_post',
        'type'        => 'post-select',
        'desc'        => 'Choose the Post to display its content as the slide.',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Video ID',
        'id'          => 'meta_slide_video_link',
        'type'        => 'text',
        'desc'        => 'Add the ID of the video.',
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Video Type',
        'id'          => 'meta_video_type',
        'type'        => 'select',
        'desc'        => 'Choose the video type in case of video posts, then enter the video id for youtube,dailymotion and vimeo',
        'choices'     => array(
          array(
            'label'       => 'Youtube',
            'value'       => 'youtube'
          ),
          array(
            'label'       => 'Dailymotion',
            'value'       => 'dailymotion'
          ),
          array(
            'label'       => 'Vimeo',
            'value'       => 'vimeo'
          )
        ),
        'std'         => 'youtube',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
  	)
  );
  
  
  
  $meta_description = array(
    'id'          => 'meta_description_id',
    'title'       => 'Page Description',
    'desc'        => '',
    'pages'       => array(  'page' , 'post'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'Description',
        'id'          => 'meta_description',
        'type'        => 'textarea-simple',
        'desc'        => 'This Description will be used in facebook share and google search results.',
        'std'         => '',
        'rows'        => '5',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'label'       => 'Enable Featured Media',
        'id'          => 'enable_featured_media',
        'type'        => 'select',
        'desc'        => 'Choose to enable the featured media for this article or not',
        'choices'     => array(
          array(
            'label'       => 'Default',
            'value'       => ''
          ),
          array(
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array(
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
  	)
  );
  
  $layout_builder = array(
    'id'          => 'meta_layout',
    'title'       => 'Page Options',
    'desc'        => '',
    'pages'       => array( 'page'),
    'context'     => 'normal',
    'priority'    => 'low',
    'fields'      => array(
    array(
      'label'       => 'Use Layout Builder',
      'id'          => 'meta_use_layout_builder',
      'type'        => 'select',
      'desc'        => 'Use the Layout Builder in this page ?,Default: No.',
      'choices'     => array(
        array (
          'label'       => 'Yes',
          'value'       => 'yes'
        ),
       	array (
       	  'label'       => 'No',
       	  'value'       => 'no'
       	)
      ),
      'std'         => 'no',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Templates',
      'id'          => 'meta_template_id',
      'type'        => 'custom-post-type-select',
      'desc'        => '<p>Choose any template of the available templates or You can Create Templates <a href="'.home_url().'/wp-admin/themes.php?page=aq-page-builder&action=edit&template=0">Here</a></p>',
      'std'         => '',
      'rows'        => '',
      'post_type'   => 'template',
      'taxonomy'    => '',
      'class'       => ''
      
    ),
    array(
      'label'       => 'Show Title/breadcrumbs',
      'id'          => 'meta_breadcrumbs',
      'type'        => 'select',
      'desc'        => 'Choose Yes/No to to Show Title and breadcrumbs, Default: Yes.',
      'choices'     => array(
        array (
          'label'       => 'Yes',
          'value'       => 'yes'
        ),
        	array (
        	  'label'       => 'No',
        	  'value'       => 'no'
        	)
      ),
      'std'         => 'yes',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    )
    )
  );
  
  $review = array(
    'id'          => 'meta_review',
    'title'       => 'Review Options',
    'desc'        => '',
    'pages'       => array( 'post','item'),
    'context'     => 'normal',
    'priority'    => 'low',
    'fields'      => array(
    array(
      'label'       => 'Enable Review Box',
      'id'          => 'meta_use_review',
      'type'        => 'select',
      'desc'        => 'Use the Review Box in this page ?,Default: No.',
      'choices'     => array(
        array (
          'label'       => 'Yes',
          'value'       => 'yes'
        ),
       	array (
       	  'label'       => 'No',
       	  'value'       => 'no'
       	)
      ),
      'std'         => 'no',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
   
    array(
      'label'       => 'Reviews',
      'id'          => 'meta_reviews',
      'type'        => 'list-item',
      'desc'        => 'Add Reviews to your post.',
      'settings'    => array(
        array(
          'label'       => 'Rating Value',
          'id'          => 'rating',
          'type'        => 'text',
          'desc'        => 'Add the rating Value From 0 to 100.',
          'std'         => '100',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'class'       => ''
        )
        
      ),
      'std'         => '',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Rating Comment',
      'id'          => 'meta_review_comment',
      'type'        => 'textarea-simple',
      'desc'        => 'Comment about the Product you are reviewing.',
      'std'         => '',
      'rows'        => '5',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Review Type',
      'id'          => 'meta_review_type',
      'type'        => 'select',
      'desc'        => 'Select to Type of the review in this article?, Default: Stars.',
      'choices'     => array(
        array (
          'label'       => 'Stars',
          'value'       => 'stars'
        ),
       	array (
       	  'label'       => 'Percentage',
       	  'value'       => 'percentage'
       	),
       	array (
       	   'label'       => 'Points',
       	   'value'       => 'points'
        )
      ),
      'std'         => 'stars',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ),
    array(
      'label'       => 'Show Default Review Box',
      'id'          => 'meta_show_review',
      'type'        => 'select',
      'desc'        => 'Select to Show the default Review Box in this article?, Turn this off to add the Review Widget Default: No.',
      'choices'     => array(
        array (
          'label'       => 'Yes',
          'value'       => 'yes'
        ),
       	array (
       	  'label'       => 'No',
       	  'value'       => 'no'
       	)
      ),
      'std'         => 'no',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'class'       => ''
    ))
    ,
    'std'         => '',
    'rows'        => '',
    'post_type'   => '',
    'taxonomy'    => '',
    'class'       => ''
	
  
);
  
    
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $general );
  ot_register_meta_box( $meta_description );
  ot_register_meta_box( $stylings );
  ot_register_meta_box( $review );
  ot_register_meta_box( $meta_gallery_slider );
  ot_register_meta_box( $slides_type );
  ot_register_meta_box( $slider_video );
  ot_register_meta_box( $layout_builder );
  ot_register_meta_box( $meta_items_metro );
  
   	if(is_array($article_meta_array) ){
   	  ot_register_meta_box( $article_meta_list_register );
   	}
   	
   	if(is_array($item_meta_array) ){
   	  ot_register_meta_box( $item_meta_list_register );
   	}
   
   
   
     
  
  
  
  

  

}