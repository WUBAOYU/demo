<?php


class C5_theme_options {
	
	function __construct() {
		
	}
	
	function hook() {
		
		add_action('admin_init', array($this, 'theme_options'), 1);
		
		add_action( 'admin_enqueue_scripts', array($this, 'css_load') );
	}
	
	function css_load($hook) {
	    
	     wp_enqueue_style( 'c5ab-font-awesome', C5BP_extra_uri . 'fonts/font-awesome-4.0.3/css/font-awesome.min.css');
	     
	     
	}
	
	function get_templates_list() {
		$templates = get_option('c5ab_templates');
		if(!is_array($templates)){
			$this->update_templates_list();
			$templates = get_option('c5ab_templates');
		}
		$types_array = array();
		$types_array[] = array(
			'label'       => 'Default template',
			'value'       => ''
		); 
		foreach ($templates as $key => $value) {
			$types_array[] = array(
				'label'       => $value,
				'value'       => $key
			); 
		}
		return $types_array;
		
	}
	
	function update_templates_list() {
		$array = c5ab_get_option('post_types');
		$templates = array();
		if(is_array($array)){
			foreach($array as $type){
				$args = array(
					'post_type'=> $type,
					'posts_per_page'    => -1,
				);
				// The Query
				query_posts( $args );
				
				// The Loop
				while ( have_posts() ) : the_post();
				    $template = get_post_meta(get_the_ID(), 'c5ab_data', true);
				    if( is_array(@unserialize( base64_decode( $template) )) ){
				    	$templates[ get_the_ID() ] = get_the_title();
				    }
				endwhile;
				
				// Reset Query
				wp_reset_query();
			}
		}
		
		update_option('c5ab_templates' , $templates);
		
	}
	
	function theme_options() {
		if(class_exists('C5AB_ICONS')){
			$obj = new C5AB_ICONS();
			$icons = $obj->get_icons_as_images();
		}else {
			$icons = array();
		}
		
		$args =array('show_ui'=> true);
		$types_array = array();
		$output = 'objects'; // names or objects
		
		$post_types = get_post_types( $args, $output );
		//print_r($post_types);
		$exlude_array = array(
			'attachment',
			'skin',
			'header',
			'footer'
		);
		foreach ( $post_types  as $key => $post_type ) {
			
			if(!in_array($key,  $exlude_array) ){
				$types_array[] = array(
					'label'       => $post_type->label,
					'value'       => $key
				); 
			}
		}
		
		$page_templates = $this->get_templates_list();
		
	    /**
	     * Get a copy of the saved settings array. 
	     */
	    $saved_settings = get_option('option_tree_settings', array());
	
	    /**
	     * Create a custom settings array that we pass to 
	     * the OptionTree Settings API Class.
	     */
	    $custom_settings = array(
	        'contextual_help' => array(
	        ),
	        'sections' => array(
	            array(
	                'title' => 'General',
	                'id' => 'general_default'
	            ),
	            array(
	                'title' => 'Default Skins',
	                'id' => 'layout_option'
	            ),
	            array(
	                'title' => 'Default Templates',
	                'id' => 'default_templates'
	            ),
	            
	            array(
	                'title' => 'Social Icons',
	                'id' => 'social'
	            ),
	            array(
	                'title' => 'Custom Post Types',
	                'id' => 'custom_post'
	            ),
	            array(
	                'title' => 'Article Settings',
	                'id' => 'article'
	            ),
	            array(
	                'title' => 'Search Settings',
	                'id' => 'search'
	            ),
	            array(
	                'title' => 'Sidebars',
	                'id' => 'sidebars'
	            ),
	            array(
	                'title' => 'Menu Locations',
	                'id' => 'menus'
	            ),
	            array(
	                'title' => 'Custom Fonts ',
	                'id' => 'fonts'
	            ),
	            
	        ),
	        'settings' => array(
	            array(
	                'label' => 'Main Logo',
	                'id' => 'logo',
	                'type' => 'upload',
	                'desc' => 'Upload the main logo for your website.',
	                'std' => '',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Logo Height',
	                'id' => 'logo_height',
	                'type' => 'numeric-slider',
	                'desc' => 'Slide to select your Logo Height in <strong>pixels</strong>. "We will calculate the width automaticly based on the height"',
	                'std' => '27',
	                'min_max_step' => '10,300,1',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Main Logo Top Margin',
	                'id' => 'logo_margin',
	                'type' => 'numeric-slider',
	                'desc' => 'Top Margin for the logo for your website, Default:7px.',
	                'std' => '7',
	                'min_max_step' => '0,300,1',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'favicon',
	                'id' => 'favicon',
	                'type' => 'upload',
	                'desc' => 'Upload a 16px x 16px Png/Gif image that will represent your website\'s favicon.',
	                'std' => get_template_directory_uri() . '/favicon.png',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Preview Mode',
	                'id' => 'preview',
	                'type' => 'on_off',
	                'desc' => 'Choose ON to enable Preview Mode to test some colors changes in your website.',
	                'std' => 'on',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Quick Read Ad',
	                'id' => 'quick_read_ad',
	                'type' => 'textarea-simple',
	                'desc' => 'Add Quick Read Ad Content.',
	                'std' => '',
	                
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Google Analytics Code',
	                'id' => 'google_analytics',
	                'type' => 'textarea-simple',
	                'desc' => 'Paste your Google Analytics (or other) tracking code here. This will be added into your theme.',
	                'std' => '',
	                'rows' => '10',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Custom CSS Code',
	                'id' => 'custom_css',
	                'type' => 'textarea-simple',
	                'desc' => 'Paste your custom css code.',
	                'std' => '',
	                'rows' => '10',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Custom Javascript Code',
	                'id' => 'custom_js',
	                'type' => 'textarea-simple',
	                'desc' => 'Paste your custom Javascript code.',
	                'std' => '',
	                'rows' => '10',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'general_default'
	            ),
	            array(
	                'label' => 'Choose The default Skin',
	                'id' => 'skin_default',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for website.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Articles',
	                'id' => 'skin_default_article',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Articles.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Pages',
	                'id' => 'skin_default_page',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Pages.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Category Page',
	                'id' => 'skin_default_category',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Category Page.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Tags Page',
	                'id' => 'skin_default_tag',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Tags Page.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Search Page',
	                'id' => 'skin_default_search',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Search Page.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for Archive Page "Year, Month"',
	                'id' => 'skin_default_archive',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for Archive Page " Year, Month".',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            array(
	                'label' => 'Choose The default Skin for 404 Page',
	                'id' => 'skin_default_404',
	                'type' => 'custom-post-type-select',
	                'desc' => 'Choose The default Skin for 404 Page.',
	                'std' => '',
	                'rows' => '',
	                'post_type' => 'skin',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'layout_option'
	            ),
	            /// Article Settings
	            
	            //// templates
	            array(
	                'label' => 'Default Page template.',
	                'id' => 'default_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => 'Category Page template.',
	                'id' => 'cat_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => 'Tag Page template.',
	                'id' => 'tag_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => 'Author Page template.',
	                'id' => 'author_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => 'Search Page template.',
	                'id' => 'search_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => 'Archive Page template.',
	                'id' => 'archive_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            array(
	                'label' => '404 Page template.',
	                'id' => '404_template',
	                'type' => 'select',
	                'desc' => 'Choose your Default Category Page template.',
	                'choices'=> $page_templates,
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'default_templates'
	            ),
	            ////Sidebars
	            array(
	                'label' => 'Sidebars',
	                'id' => 'sidebars',
	                'type' => 'list-item',
	                'desc' => 'Add Unlimited Sidebars to your website.',
	                'settings' => array(
	                    array(
	                        'label' => 'Slug',
	                        'id' => 'slug',
	                        'type' => 'text',
	                        'desc' => 'Sidebar Slug "All lowercase and must be unique".',
	                        'std' => '',
	                        
	                    ),
	                    array(
	                        'label' => 'Description',
	                        'id' => 'description',
	                        'type' => 'textarea-simple',
	                        'desc' => 'Sidebar Description.',
	                        'std' => '',
	                        'rows' => '5',
	                        'post_type' => '',
	                        'taxonomy' => '',
	                        'class' => ''
	                    )
	                ),
	                'std' => '',
	                
	                'section' => 'sidebars'
	            ),
	            ////Menus
	            array(
	                'label' => 'Menu Locations',
	                'id' => 'menus',
	                'type' => 'list-item',
	                'desc' => 'Add Unlimited Menu Locations to your website.',
	                'settings' => array(
	                    array(
	                        'label' => 'Location',
	                        'id' => 'location',
	                        'type' => 'text',
	                        'desc' => 'Menu Location You will get the menu by that name. "No spaces"',
	                        'std' => '',
	                        
	                    )
	                ),
	                'std' => '',
	                
	                'section' => 'menus'
	            ),
	            //// custom fonts
	            array(
	                'label' => 'Custom Fonts',
	                'id' => 'custom_fonts',
	                'type' => 'list-item',
	                'desc' => 'Add New Custom font.',
	                'settings' => array(
	                    array(
	                        'label' => 'folder name',
	                        'id' => 'folder',
	                        'type' => 'text',
	                        'desc' => 'type the folder name you added to /library/fonts/',
	                        'std' => '',
	                        
	                    ),
	                    array(
	                        'label' => '.css file name',
	                        'id' => 'css',
	                        'type' => 'text',
	                        'desc' => 'add .css file name for the font face"type it without the extension"',
	                        'std' => '',
	                        
	                    )
	                ),
	                'std' => '',
	                
	                'section' => 'fonts'
	            ),
	            array(
	                'label' => 'Default Search Post Type',
	                'id' => 'search_post',
	                'type' => 'select',
	                'desc' => 'Choose the post type you want to make the search based on.',
	                'choices' => $types_array,
	                'std' => 'post',
	                'section' => 'search'
	            ),
	            array(
	                'label' => 'Show Category Filter',
	                'id' => 'search_filter',
	                'type' => 'on_off',
	                'desc' => 'Show Category Filter.',
	                'std' => 'on',
	                'section' => 'search'
	            ),
	            //// custom post type
	            array(
	                'label' => 'Custom Post Types',
	                'id' => 'custom_posts',
	                'type' => 'list-item',
	                'desc' => '',
	                'settings' => $this->custom_post_type(),
	                'std' => '',
	                
	                'section' => 'custom_post'
	            ),
	            array(
	                'label' => 'Facebook App ID',
	                'id' => 'facebook_ID',
	                'type' => 'text',
	                'desc' => 'Add Facebook App ID.',
	                'std' => '',
	                'section' => 'social'
	            ),
	            //// social icons
	            array(
	                'label' => 'Social Top Icons',
	                'id' => 'social_icons',
	                'type' => 'list-item',
	                'desc' => '',
	                'settings' => array(
	                    array(
	                        'label' => 'Link',
	                        'id' => 'link',
	                        'type' => 'text',
	                        'desc' => 'Your Social Link',
	                        'choices' => '',
	                        'std' => '',
	                        'rows' => '',
	                        'post_type' => '',
	                        'taxonomy' => '',
	                        'class' => ''
	                    ),
	                    array(
	                        'label' => 'Icon',
	                        'id' => 'icon',
	                        'type' => 'radio-text',
	                        'desc' => 'Add Link Icon class, Default fa fa-facebook',
	                        'std' => 'fa fa-facebook',
	                        'choices'=>$icons,
	                        'rows' => '',
	                        'post_type' => '',
	                        'taxonomy' => '',
	                        'class' => ''
	                    ),
	                    array(
	                        'label' => 'Type',
	                        'id' => 'type',
	                        'type' => 'select',
	                        'desc' => 'Select Link Type, Default Link',
	                        'choices' => array(
	                            array(
	                                'label' => 'Link',
	                                'value' => 'link'
	                            ),
	                            array(
	                                'label' => 'Search',
	                                'value' => 'search'
	                            ),
	                            array(
	                                'label' => 'Account',
	                                'value' => 'account'
	                            ),
	                            array(
	                                'label' => 'Email',
	                                'value' => 'email'
	                            ),
	                            array(
	                                'label' => 'Languages',
	                                'value' => 'languages'
	                            )
	                        ),
	                        'std' => 'link',
	                        'rows' => '',
	                        'post_type' => '',
	                        'taxonomy' => '',
	                        'class' => ''
	                    ),
	                ),
	                'std' => '',
	                'rows' => '',
	                'post_type' => '',
	                'taxonomy' => '',
	                'class' => '',
	                'section' => 'social'
	            )
	        )
	    );
	    
	    
	    
		$custom_settings['settings'] = array_merge($custom_settings['settings'], $this->article_settings());
	    /* allow settings to be filtered before saving */
	    $custom_settings = apply_filters('option_tree_settings_args', $custom_settings);
	
	    /* settings are not the same update the DB */
	    if ($saved_settings !== $custom_settings) {
	        update_option('option_tree_settings', $custom_settings);
	    }
	}
	
	function article_settings() {
		$settings = array(
			array(
			    'label' => 'Follow Category styling Settings',
			    'id' => 'posts_styling',
			    'type' => 'on_off',
			    'desc' => 'Follow the article category styling Settings, Default: On.',
			    'std' => 'on',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Meta data',
			    'id' => 'single_meta_style',
			    'type' => 'select',
			    'desc' => 'Choose the view of the article meta data',
			    'choices' => array(
			        array(
			            'label' => 'Line',
			            'value' => 'line'
			        ),
			        array(
			            'label' => 'Block',
			            'value' => 'block'
			        )
			    ),
			    'std' => 'normal',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Posts Meta Data Enable',
			    'id' => 'meta_data',
			    'type' => 'checkbox',
			    'desc' => 'Posts Meta Data Enable or Disable.',
			    'choices' => $this->single_checkboxes(),
			    'std' => $this->single_checkboxes_defaults(),
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Date Format Posts Type',
			    'id' => 'c5_date_format',
			    'type' => 'select',
			    'desc' => 'Set The Date format "Normal date: 12th January, 2013" or "Ago date: 2 days ago"',
			    'choices' => array(
			        array(
			        	'label'=>'Date & Time',
			        	'value'=>'date_time'
			        ),
			        array(
			        	'label'=>'Only Date',
			        	'value'=>'date'
			        ),
			        array(
			        	'label'=>'Only Time',
			        	'value'=>'time'
			        ),
			        array(
			        	'label'=>'Ago Format',
			        	'value'=>'ago'
			        ),
			    ),
			    'std' => 'normal',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Related Posts Type',
			    'id' => 'related_type',
			    'type' => 'select',
			    'desc' => 'Select Related Posts selection type based on:',
			    'choices' => array(
			        array(
			            'label' => 'Tags',
			            'value' => 'tags'
			        ),
			        array(
			            'label' => 'Category',
			            'value' => 'category'
			        ),
			        array(
			            'label' => 'Random',
			            'value' => 'random'
			        )
			    ),
			    'std' => 'tags',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Before Article Section Content',
			    'id' => 'article_before',
			    'type' => 'textarea-simple',
			    'desc' => 'Add a content to show before each article',
			    'std' => '',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'After Article Section Content',
			    'id' => 'article_after',
			    'type' => 'textarea-simple',
			    'desc' => 'Add a content to show after each article',
			    'std' => '',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Comments Section Order',
			    'id' => 'comments_order',
			    'type' => 'select',
			    'desc' => 'Select the Comments Order in your article, Default: Facebook - WP Comments',
			    'choices' => array(
			        array(
			            'label' => 'Facebook - WP Comments',
			            'value' => 'facebook_comments'
			        ),
			        array(
			            'label' => 'WP Comments - Facebook',
			            'value' => 'comments_facebook'
			        )
			    ),
			    'std' => 'facebook_comments',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Facebook Color',
			    'id' => 'facebook_color',
			    'type' => 'select',
			    'desc' => 'Select Facebook Color Mode. Default Light.',
			    'choices' => array(
			        array(
			            'label' => 'Light',
			            'value' => 'light'
			        ),
			        array(
			            'label' => 'Dark',
			            'value' => 'dark'
			        )
			    ),
			    'std' => 'light',
			    
			    'section' => 'article'
			),
			array(
			    'label' => 'Default Thumbnail for Commenter',
			    'id' => 'avatar',
			    'type' => 'upload',
			    'desc' => 'Upload Default Thumbnail for Commenters.',
			    'std' => '',
			    
			    'section' => 'article'
			),
		);
		return $settings;
	}
	
	function custom_post_type() {
		$settings = array(
		    array(
		        'label' => 'Slug',
		        'id' => 'slug',
		        'type' => 'text',
		        'desc' => 'Add Post type slug, this will be used in the url',
		        'std' => '',
		        
		    ),
		    array(
		        'label' => 'Category Name',
		        'id' => 'category_name',
		        'type' => 'text',
		        'desc' => 'Add Category name"',
		        'std' => 'Category',
		    )
		    ,
		    array(
		        'label' => 'Category slug',
		        'id' => 'category',
		        'type' => 'text',
		        'desc' => 'Add Category to this custom post, add its slug here "this will be used in the url of the category page"',
		        'std' => '',
		    ),
		    array(
		        'label' => 'Posts Skin',
		        'id' => 'posts_skin',
		        'type' => 'custom-post-type-select',
		        'desc' => 'Choose Default Posts Skin.',
		        'post_type' => 'skin',
		        'std' => '',
		        
		    ),
		    array(
		        'label' => 'Follow Category styling Settings',
		        'id' => 'posts_styling',
		        'type' => 'on_off',
		        'desc' => 'Follow the article category styling Settings, Default: On.',
		        'std' => 'on',
		        
		    ),
		    array(
		        'label' => 'Meta data',
		        'id' => 'single_meta_style',
		        'type' => 'select',
		        'desc' => 'Choose the view of the article meta data',
		        'choices' => array(
		            array(
		                'label' => 'Line',
		                'value' => 'line'
		            ),
		            array(
		                'label' => 'Block',
		                'value' => 'block'
		            )
		        ),
		        'std' => 'normal',
		        
		        'section' => 'article'
		    ),
		    array(
		        'label' => 'Posts Meta Data Enable',
		        'id' => 'meta_data',
		        'type' => 'checkbox',
		        'desc' => 'Posts Meta Data Enable or Disable.',
		        'choices' => $this->single_checkboxes(),
		        'std' => $this->single_checkboxes_defaults(),
		        'section' => ''
		    ),
		    array(
		        'label' => 'Date Format Posts Type',
		        'id' => 'c5_date_format',
		        'type' => 'select',
		        'desc' => 'Set The Date format "Normal date: 12th January, 2013" or "Ago date: 2 days ago"',
		        'choices' => array(
		            array(
		            	'label'=>'Date & Time',
		            	'value'=>'date_time'
		            ),
		            array(
		            	'label'=>'Only Date',
		            	'value'=>'date'
		            ),
		            array(
		            	'label'=>'Only Time',
		            	'value'=>'time'
		            ),
		            array(
		            	'label'=>'Ago Format',
		            	'value'=>'ago'
		            ),
		        ),
		        'std' => 'normal',
		        'section' => 'article'
		    ),
		    array(
		        'label' => 'Related Posts Type',
		        'id' => 'related_type',
		        'type' => 'select',
		        'desc' => 'Select Related Posts selection type based on:',
		        'choices' => array(
		            array(
		                'label' => 'Tags',
		                'value' => 'tags'
		            ),
		            array(
		                'label' => 'Category',
		                'value' => 'category'
		            ),
		            array(
		                'label' => 'Random',
		                'value' => 'random'
		            )
		        ),
		        'std' => 'tags',
		        
		    ),
		    array(
		        'label' => 'Before Article Section Content',
		        'id' => 'article_before',
		        'type' => 'textarea',
		        'desc' => 'Add a content to show before each article',
		        'std' => '',
		        
		    ),
		    array(
		        'label' => 'After Article Section Content',
		        'id' => 'article_after',
		        'type' => 'textarea',
		        'desc' => 'Add a content to show after each article',
		        'std' => '',
		        
		    ),
		    array(
		        'label' => 'Comments Section Order',
		        'id' => 'comments_order',
		        'type' => 'select',
		        'desc' => 'Select the Comments Order in your article, Default: Facebook - WP Comments',
		        'choices' => array(
		            array(
		                'label' => 'Facebook - WP Comments',
		                'value' => 'facebook_comments'
		            ),
		            array(
		                'label' => 'WP Comments - Facebook',
		                'value' => 'comments_facebook'
		            )
		        ),
		        'std' => 'facebook_comments',
		        
		    ),
		    array(
		        'label' => 'Facebook Color',
		        'id' => 'facebook_color',
		        'type' => 'select',
		        'desc' => 'Select Facebook Color Mode. Default Light.',
		        'choices' => array(
		            array(
		                'label' => 'Light',
		                'value' => 'light'
		            ),
		            array(
		                'label' => 'Dark',
		                'value' => 'dark'
		            )
		        ),
		        'std' => 'light',
		        
		    ),
		);
		
		return $settings;
	}
	
	function single_checkboxes_defaults() {
		$array = array();
		
		foreach ($this->single_checkboxes() as $value) {
			$array[] = $value['value'];
		}
		return $array;
	}
	
	function single_checkboxes() {
		$array = array(
		    array(
		        'label' => 'Show Featured Media',
		        'value' => 'media'
		    ),
		    array(
		        'label' => 'Show Social Share count',
		        'value' => 'social_count'
		    ),
		    array(
		        'label' => 'Show Author Name',
		        'value' => 'author'
		    ),
		    array(
		        'label' => 'Show Date',
		        'value' => 'date'
		    ),
		    array(
		        'label' => 'Show Commenets Count',
		        'value' => 'comments_count'
		    ),
		    array(
		        'label' => 'Show Categories',
		        'value' => 'category'
		    ),
		    array(
		        'label' => 'Show Like Button',
		        'value' => 'like'
		    ),
		    array(
		        'label' => 'Show View Count',
		        'value' => 'view'
		    ),
		    array(
		        'label' => 'Show Tags',
		        'value' => 'tags'
		    ),
		    array(
		        'label' => 'Show Related Posts',
		        'value' => 'related'
		    ),
		    array(
		        'label' => 'Enable Facebook Comments',
		        'value' => 'fb_commnets'
		    ),
		    array(
		        'label' => 'Enable WordPress Comments',
		        'value' => 'wp_commnets'
		    )
		);
		
		return $array;
	}
	
	
	function get_meta_options(){
		
		$post_type = get_post_type();
		if($post_type == 'post'){
				return ot_get_option('meta_data');
		}else {
			$custom_posts = ot_get_option('custom_posts');
			if(is_array($custom_posts)){
				foreach ($custom_posts as $custom_post) {
					if($custom_post['slug']==$post){
						return $custom_post['meta_data'];
					}
				}
			}
		}
		
		return $this->single_checkboxes_defaults();
	}
	
	
	function get_meta_option($option) {
		$post_type = get_post_type();
		if($post_type == 'post'){
				return ot_get_option($option);
		}else {
			$custom_posts = ot_get_option('custom_posts');
			if(is_array($custom_posts)){
				foreach ($custom_posts as $custom_post) {
					if($custom_post['slug']==$post){
						return $custom_post[$option];
					}
				}
			}
		}
		return ot_get_option($option);
	}
}

$theme_options= new C5_theme_options();
$theme_options->hook();