<?php 

add_filter('ot_show_pages', '__return_false');


 ?>