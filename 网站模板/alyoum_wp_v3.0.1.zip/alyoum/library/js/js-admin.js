jQuery(document).ready(function ($) {





$(document).on("click", "#wp-admin-bar-c5_install_demo", function (e) {
    
    data = '<h3>Install Demo Content</h3><p>Click Install Demo Content to load all the demo content for you, Just click it and let us do the magic.</p><p class="c5_install_button btn btn-primary float_right">Install demo content</p>';
    $.magnificPopup.open({
      items: {
        src: data
      },
      mainClass: 'mfp-install-demo-post',
      type: 'inline'
    }, 0);
    
    
 }); 
 
 
 $(document).on("click", ".c5_install_button", function (e) {
     
     data = '<h3>Install Demo Content</h3><p>installing now...</p>';
     $.magnificPopup.open({
       items: {
         src: data
       },
       mainClass: 'mfp-install-demo-post',
       type: 'inline'
     }, 0);
     
     
     window.location.href = $("#website_dir").val() + '/wp-admin/admin.php?import=c5_wordpress';
     
     
     
  }); 
 
 

 
 });