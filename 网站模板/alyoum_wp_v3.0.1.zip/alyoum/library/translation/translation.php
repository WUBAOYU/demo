<?php

// Adding Translation Option
load_theme_textdomain( 'code125', get_template_directory() .'/library/translation' );
?>
