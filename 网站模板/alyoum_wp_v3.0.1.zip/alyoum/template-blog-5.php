<?php
/*
Template Name: Blog Layout 5 Template
*/
?><?php get_header(); 
$meta_values = get_post_custom($post->ID);

			 
			 
			 
			  ?>
			 
				<div id="inner-content" class="wrap clearfix">
					<?php 
					
					if(!isset($meta_values['meta_breadcrumbs'][0])){
						$meta_values['meta_breadcrumbs'][0] = 'yes';
					} 
					if($meta_values['meta_breadcrumbs'][0] == 'yes'){ ?>
					<div class="title_wrap row-fluid">
						<div class="border">
							<div id="title_crumb">
								<h1 class="heading1"><?php echo $post->post_title; ?></h1>
								<div class="clearfix"></div>
								<?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
								</div>
								<div class="arrow_down"></div>
						
						<div class="clearfix"></div>
						</div>
					</div>
					
					<?php }
					
					
					 ?>
					
					<div id="inner-page-content">
					<div class="row-fluid">
				    
				    
				    <div id="main" class="span12  clearfix" role="main">

					    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					    <article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
						
						    					
						    <section class="post-content clearfix" itemprop="articleBody">
						    <div id="blog-3col-wrap" class="clearfix">
						     <?php echo do_shortcode('[posts_5 posts_per_page="15" paging="true" order="DESC" orderby="date"]'); ?>
						     </div>							
						       </section> <!-- end article section -->
												  
					
					    </article> <!-- end article -->
					
					    <?php endwhile; ?>		
					
					    <?php else : ?>
					
    					    <article id="post-not-found" class="hentry clearfix">
    					    	<header class="article-header">
    					    		<h1><?php _e("Oops, Post Not Found!", "code125"); ?></h1>
    					    	</header>
    					    	<section class="post-content">
    					    		<p><?php _e("Uh Oh. Something is missing. Try double checking things.", "code125"); ?></p>
    					    		 <?php wp_link_pages( $args ); ?>
    					    	</section>
    					    	<footer class="article-footer">
    					    	    <p><?php _e("This is the error message in the page.php template.", "code125"); ?></p>
    					    	</footer>
    					    </article>
					
					    <?php endif; ?>
			
    				</div> <!-- end #main -->
      
				    </div>
				    </div>
				</div> <!-- end #inner-content -->
    

<?php get_footer(); ?>