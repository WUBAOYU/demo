<?php get_header(); ?>

<div id="content">

    <div id="inner-content" class="wrap  clearfix">


        <?php
            ob_start();
            single_cat_title();
            $single_cat_title = ob_get_contents();
            ob_end_clean();
            ?> 

            
        <div id="inner-page-content">
            <div class="border">
                <div class="row-fluid">

                    <?php
                    $category_type = ot_get_option('category_type');

                    if ($category_type == '3') {
                        $main_class = 'span12';
                    } else {
                        $main_class = 'span8';
                    }
                    if (is_category()) {
                        $thisCat = get_term_by('name', $single_cat_title, 'category');
                        $category_layout = get_option('category_layout_' . $thisCat->term_id);
                        if ($category_layout == 'full') {
                            $main_class = 'span12';
                        }
                    }
                    ?>
                    <div id="main" class="<?php echo $main_class; ?>  clearfix" role="main">
                        <?php
                        	$category = get_the_category();
                            $thisCat = get_term_by('id', $category[0]->cat_ID, 'category');
                            $category_icon = get_option('category_icon_' . $thisCat->term_id);
                            ?>
                            <?php if (isset($category_icon) && $category_icon != '') { ?>
                                <div class="row-fluid">

                                    <div class="span2 cat_icon">
                                        <span class="list-icon large  <?php echo $category_icon; ?>"></span>
                                    </div>
                                    <div class="span10 article_author cat_page"><a ><?php echo $single_cat_title; ?></a><p><?php echo $thisCat->description ?></p></div>
                                </div>
                                <div style="height: 30px;"></div>
                            <?php } ?>

                            <?php
                            $category_slider = ot_get_option('category_slider');

                            if ($category_slider == 'latest') {
                                $args = array(
                                    'category' => $thisCat->term_id,
                                    'orderby' => 'post_date',
                                    'order' => 'DESC');
                                $posts_array = get_posts($args);

                                if (count($posts_array) != 0) {
                                    $code = '[posts_slider]';
                                    foreach ($posts_array as $the_post) {
                                        $code = $code . '[posts_slide id="' . $the_post->ID . '"]';
                                    }
                                    $code = $code . '[/posts_slider]';
                                    echo do_shortcode($code);
                                }
                            } elseif ($category_slider == 'popular') {
                                $args = array(
                                    'category' => $thisCat->term_id,
                                    'orderby' => 'comment_count',
                                    'order' => 'DESC');
                                $posts_array = get_posts($args);

                                if (count($posts_array) != 0) {
                                    $code = '[posts_slider]';
                                    foreach ($posts_array as $the_post) {
                                        $code = $code . '[posts_slide id="' . $the_post->ID . '"]';
                                    }
                                    $code = $code . '[/posts_slider]';

                                    echo do_shortcode($code);
                                }
                            
                        }

				 if ($category_type == '3' ) { ?>
                    <div id="blog-3col">
                 <?php }elseif ($category_type == '5') { ?>
                 	<div id="blog-5" class=" blog-5 small clearfix">
                <?php } ?>
                    <?php
                    $counter = 1;
                    if (have_posts()) : while (have_posts()) : the_post();


                            $data = '';
                            if ($category_type == '2' ) {
                                include(TEMPLATEPATH . '/blog-style2.php');
                            } elseif ($category_type == '3') {
								
                                include(TEMPLATEPATH . '/blog-style3.php');
                            } elseif ($category_type == '4') {
                            	$data = $data . '<div class="float_left mini-4">';
                                include(TEMPLATEPATH . '/blog-style4.php');
                                $data = $data . '</div>';
                            }
                            elseif ($category_type == '5') {
                            	
                                include(TEMPLATEPATH . '/blog-style5.php');
                                
                            } else {
                                include(TEMPLATEPATH . '/blog-style1.php');
                            }


                            echo $data;

                        endwhile;
                        ?>	
                        <?php if ($category_type == '3') { ?>
                        </div>
                    <?php }elseif ($category_type == '5') { ?>
                    	</div>
                    <?php } ?>

                    <?php if (function_exists('bones_page_navi')) { // if experimental feature is active  ?>

                        <?php bones_page_navi(); // use the page navi function  ?>

                    <?php } else { // if it is disabled, display regular wp prev & next links  ?>
                        <nav class="wp-prev-next">
                            <ul class="clearfix">
                                <li class="prev-link"><?php next_posts_link(_e('&laquo; Older Entries', "code125")) ?></li>
                                <li class="next-link"><?php previous_posts_link(_e('Newer Entries &raquo;', "code125")) ?></li>
                            </ul>
                        </nav>
                    <?php } ?>

                <?php else : ?>

                    <article id="post-not-found" class="hentry clearfix">
                        <header class="article-header">
                            <h1><?php _e("No Articles Here", "code125"); ?></h1>
                        </header>

                    </article>

                <?php endif; ?>

            </div> <!-- end #main -->
            <?php if ($category_type != '3' && $category_layout !='full') { ?>
                <div id="sidebar" class="sidebar span4 clearfix" role="complementary">

                    <?php
                    get_sidebar('page'); // sidebar Page 
                    ?>

                </div>
            <?php } ?>
            


        </div> <!-- end #inner-content -->

    </div> <!-- end #content -->
</div>
</div>
</div>

<?php get_footer(); ?>