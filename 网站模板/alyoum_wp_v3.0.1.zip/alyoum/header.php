<?php
$header_encoding = $_SERVER['HTTP_ACCEPT_ENCODING'];

if(strpos($header_encoding , 'gzip')){
	ob_start("ob_gzhandler");
}
$header_obj = new C5_build_header();
$header_obj->hook();
$header_obj->head();



?>

<body <?php body_class(); ?>>

<?php 
$preview = ot_get_option('preview');
if($preview == 'on'){
	$C5_preview_obj = new C5_preview();
	$C5_preview_obj->render();
}
 ?>
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=<?php echo ot_get_option('facebook_ID') ?>";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
    <?php
    
    
    global $c5_header_data;
    
    $header_obj->floating();
    
    ?>
    
   <?php $header_obj->top_bar(); ?> 
<div id="main-container" class="c5-main-width c5-main-width-<?php echo $GLOBALS['c5-main-width']; ?>">

<header class="header " role="banner">
	
    <div id="inner-header" class=" clearfix">
		 <?php $header_obj->main_content(); ?>
		 <div class="clearfix"></div>
		 <?php $header_obj->below_logo(); ?>
	</div>
 </header>
 <div id="floating-trigger"></div>
 
