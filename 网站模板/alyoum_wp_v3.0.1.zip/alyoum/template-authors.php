<?php
/*
Template Name: Authors Template
*/
?>
<?php get_header(); 
$meta_values = get_post_custom($post->ID);

			 
			 if(!isset($meta_values['meta_layout'][0])){
			 	$meta_values['meta_layout'][0] = 'right';
			 }
			 
			 
			 if( $meta_values['meta_layout'][0] == 'right' || $meta_values['meta_layout'][0] == 'left'){
			 	
			 	$main_class= 'span8';
			 	
			 }else{
			 
			 	$main_class= 'span12';
			 
			 }
			 
			  ?>
			 
				<div id="inner-content" class="wrap clearfix">
					<?php 
					
					if(!isset($meta_values['meta_breadcrumbs'][0])){
						$meta_values['meta_breadcrumbs'][0] = 'yes';
					} 
					if($meta_values['meta_breadcrumbs'][0] == 'yes'){ ?>
					<div class="title_wrap row-fluid">
						<div class="border">
							<div id="title_crumb">
								<h1 class="heading1"><?php echo $post->post_title; ?></h1>
								<div class="clearfix"></div>
								<?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
								</div>
								<div class="arrow_down"></div>
						
						<div class="clearfix"></div>
						</div>
					</div>
					
					<?php }
					
				 
					 ?>
					
					<div id="inner-page-content">
					<div class="row-fluid">
				    <?php if ($meta_values['meta_layout'][0] == 'left') { ?>
				    
				    <div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				    	
				    	<?php
				    	if(!isset($meta_values['meta_sidebar'][0])){
				    		$meta_values['meta_sidebar'][0] = 'default';
				    	}
				    	
				    	if ($meta_values['meta_sidebar'][0] == "default") {
				    	    get_sidebar('page'); // sidebar Page 
				    	} else {
				    	    if($meta_values['meta_sidebar'][0] == 'primary'){
				    	    	get_sidebar();
				    	    }else{
				    	    	dynamic_sidebar($meta_values['meta_sidebar'][0]);
				    	    }
				    	}
				    	?>
				    	
				    </div>	
				    <?php 	
				    	
				    } ?>
				    
				    <div id="main" class="<?php echo $main_class ?>  clearfix" role="main">

					    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					    <article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
						
						    					
						    <section class="post-content clearfix" itemprop="articleBody">
						     <?php 
						     the_content();
						      $all_authors = code125_all_authors();
						      
						      
						      foreach($all_authors as $user_id) :
						      	
						      	
						      	$user = get_userdata($user_id);
						      				
						      				$facebook_user = get_the_author_meta( 'facebook', $user_id);
						      				$twitter_user = get_the_author_meta( 'twitter', $user_id);
						      				$position_user = get_the_author_meta( 'position', $user_id);
						      				
						      				$google_plus_user = get_the_author_meta( 'google_plus', $user_id);
						      				$behance_user = get_the_author_meta( 'behance', $user_id);
						      				$dribble_user = get_the_author_meta( 'dribble', $user_id);
						      				
						      				$avatar = get_avatar( $user_id, '100', '', '<span class="icon-user"></span>' );
						      				
						      				echo '<div class="template-author-widget author_widget clearfix">';
						      				?>
						      				<div class="row-fluid">
						      				<div class="span12"><a href="<?php echo get_author_posts_url($user_id) ?>" class="author-avatar"><?php echo $avatar; ?></a>
						      				<h3><a href="<?php echo get_author_posts_url($user_id) ?>"><?php echo $user->display_name; ?></a></h3><p><?php echo $position_user; ?></p><ul class="social-icons clearfix">
						      				<?php 
						      				if($facebook_user != ''){
						      					echo '<li><a href="http://www.facebook.com/people/@/'.$facebook_user.'" class="icon-facebook"></a></li>';
						      				}
						      				
						      				if($twitter_user != ''){
						      					echo '<li><a href="http://www.twitter.com/'.$twitter_user.'" class="icon-twitter"></a></li>';
						      				}
						      				
						      				if($google_plus_user != ''){
						      					echo '<li><a href="'.$google_plus_user.'" class="icon-google-plus"></a></li>';
						      				}
						      				
						      				if($behance_user != ''){
						      					echo '<li><a href="'.$behance_user.'" class="code125-social-behance"></a></li>';
						      				}
						      				
						      				if($dribble_user != ''){
						      					echo '<li><a href="'.$dribble_user.'" class="code125-social-dribble"></a></li>';
						      				}
						      				
						      				if($user->user_email != ''){
						      					echo '<li><a href="mailto:'.$user->user_email.'" class="icon-envelope-alt"></a></li>';
						      				}
						      				
						      				if($user->user_url != ''){
						      					echo '<li><a href="'.$user->user_url.'" class="icon-link"></a></li>';
						      				}
						      				
						      				
						      				 ?>
						      				</li></ul></div>
						      				</div>
						      				
						      				<?php
						      				echo '<p class="author_description"><span class="arrow-up"></span>'.$user->user_description.'</p>';
						      				
						      				echo '</div>';
						      	
						      	
						      endforeach;
						      ?>							
						       </section> <!-- end article section -->
												  
					
					    </article> <!-- end article -->
					
					    <?php endwhile; ?>		
					
					    <?php else : ?>
					
    					    <article id="post-not-found" class="hentry clearfix">
    					    	<header class="article-header">
    					    		<h1><?php _e("Oops, Post Not Found!", "code125"); ?></h1>
    					    	</header>
    					    	<section class="post-content">
    					    		<p><?php _e("Uh Oh. Something is missing. Try double checking things.", "code125"); ?></p>
    					    		 <?php wp_link_pages( $args ); ?>
    					    	</section>
    					    	<footer class="article-footer">
    					    	    <p><?php _e("This is the error message in the page.php template.", "code125"); ?></p>
    					    	</footer>
    					    </article>
					
					    <?php endif; ?>
			
    				</div> <!-- end #main -->
    
				   <?php if ( $meta_values['meta_layout'][0] == 'right'  ) { ?>
				   	
				   	<div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				   		
				   		<?php
				   		if(!isset($meta_values['meta_sidebar'][0])){
				   			$meta_values['meta_sidebar'][0] = 'default';
				   		}
				   		
				   		if ($meta_values['meta_sidebar'][0] == "default") {
				   		    get_sidebar('page'); // sidebar Page 
				   		} else {
				   			if($meta_values['meta_sidebar'][0] == 'primary'){
				   				get_sidebar();
				   			}else{
				   		    	dynamic_sidebar($meta_values['meta_sidebar'][0]);
				   		    }
				   		}
				   		?>
				   		
				   	</div>
				   
				   <?php } ?>
				    
				    </div>
				    </div>
				</div> <!-- end #inner-content -->
    

<?php get_footer(); ?>