
 	<?php ob_start();
 		 the_permalink();
 		 $permalink = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_title();
 		 $the_title = ob_get_contents();
 		 ob_end_clean();
  
 		  		
  				ob_start();
  				the_author_posts_link();
  				$the_author_posts_link = ob_get_contents();
  				ob_end_clean();
  
 		
  
 		 ob_start();
 		 the_post_thumbnail('mixed-size-4');
 		 $the_post_thumbnail = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_excerpt_max_charlength(250);
 		 $the_excerpt_max_charlength = ob_get_contents();
 		 ob_end_clean();
  		
  		 	
  		$id_link = get_post_thumbnail_id();
  		
  		$image_url = wp_get_attachment_image_src( $id_link, "full"); 
  
  

 
 $data = $data . '<article class="blog-thumb style_1 clearfix">';
 
 
  
  
  
 
  if($the_post_thumbnail !=''){
 $data = $data . '<div class="row-fluid"><div class="span4 thumb-style2 thumb-wrap">';
  
 $data = $data . get_thumb_hover(get_the_ID(),'mixed-size-4',ot_get_option( 'hover_view' ));
  
 $data = $data . '</div><div class="span8">';
 $data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">';
 if(is_sticky()){
 	$data = $data . '<span class="sticky icon-paper-clip"> </span> ';
 }
 
 $data = $data .$the_title.'</a></h2>';
 
  $data = $data . '<ul class="meta-entry clearfix"><li><p><span class="icon-user"> </span> '.$the_author_posts_link.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div>'; 
 
 $data = $data . '<p class="content-short">'.$the_excerpt_max_charlength.'</p></div></div></article>';	 
  }else{
  	
  	$data = $data . '<h2 class=" blogtitle"><a class="title" href="'.$permalink.'">';
  	if(is_sticky()){
  		$data = $data . '<span class="sticky icon-paper-clip"> </span> ';
  	}
  	$data = $data .$the_title.'</a></h2>';
  	
  	 $data = $data . '<ul class="meta-entry clearfix"><li><p><span class="icon-user"> </span> '.$the_author_posts_link.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul>'; 
  	
  	
  	$data = $data . '<div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p></article>';  
  	
  	
  	
  	
  }
  
  
  ?>