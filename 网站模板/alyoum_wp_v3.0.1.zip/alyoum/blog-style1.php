
 	<?php
 		 $permalink =  get_permalink();
 		 
 		 $the_title = get_the_title();
 		 
 		 
  				ob_start();
  				the_author_posts_link();
  				$the_author_posts_link = ob_get_contents();
  				ob_end_clean();
  
 		 ob_start();
 		 the_post_thumbnail('blog-post-thumb');
 		 $the_post_thumbnail = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_excerpt_max_charlength(300);
 		 $the_excerpt_max_charlength = ob_get_contents();
 		 ob_end_clean();
  		
  		
  		$comments_number = get_total_number_of_comments(get_the_ID(),'text');
  		
 		 ob_start();
 		 the_category(' - ');
 		 $cat_echo_p = ob_get_contents();
 		 ob_end_clean();
  	
  
  
  $meta_values = get_post_custom(get_the_ID());
 
  $data = $data . '<article class="blog-thumb style_1 clearfix"><h2 class=" blogtitle"><a class="title" href="'.$permalink.'">';
  
  if(is_sticky()){
  	$data = $data . '<span class="sticky icon-paper-clip"> </span> ';
  }
  $data = $data . $the_title.'</a></h2>';


 
  $data = $data . '<ul class="meta-entry clearfix"><li><p><span class="icon-user"> </span> '.$the_author_posts_link.'</p></li><li><p><span class="icon-tag"> </span> '.$cat_echo_p.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li>';
  
  $comments_enable= ot_get_option('comments_enable');
  if($comments_enable !='no'){
    $data = $data . '<li><p><span class="icon-comment"> </span> '.$comments_number.'</p></li>';
    }
    
      $data = $data . '<li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div>'; 
  
  
  
  
  
  $format = get_post_format();
  if ($format == 'video') {
  
  	if(isset($meta_values['meta_video_type'][0])){
  	
  	if($meta_values['meta_video_type'][0] == 'vimeo'){
  			$data = $data . do_shortcode(' [vimeo clip_id="'.$meta_values['meta_attachment'][0].'" width="100%" height="340"] ');
  	}elseif ($meta_values['meta_video_type'][0] == 'youtube') {
  			$data = $data . do_shortcode(' [youtube id="'.$meta_values['meta_attachment'][0].'" width="100%" height="340"] ');	
  	}elseif ($meta_values['meta_video_type'][0] == 'dailymotion') {
  			$data = $data . do_shortcode(' [dailymotion id="'.$meta_values['meta_attachment'][0].'" width="100%" height="340"] ');	
  	}else{
  		$data = $data . $the_post_thumbnail;
  	}
  	
  	}
  	
  }
  
  elseif ($format == 'audio') {
  
  	
  	if(isset($meta_values['meta_audio_type'][0])){
  	if($meta_values['meta_audio_type'][0] == 'audio'){
  		$data = $data . do_shortcode(' [audio src="'.$meta_values['meta_audio_attachment'][0].'" ] ');
  	}else {
		$data = $data . do_shortcode(' [soundcloud id="'.$meta_values['meta_audio_attachment'][0].'" ] ');
	}
	}
  	
  	
  
  }elseif($format == 'gallery') {
  
  
  
  if(isset($meta_values['meta_slides_post_type'][0])){
  $code = '[flexslider]';
   $gallery = unserialize($meta_values['meta_slides_post_type'][0]); 
  					foreach ($gallery as $slide ) {
  					
  					$code = $code . '[flexslider_slide ] <img src="'.$slide['image'].'" alt="" /> [/flexslider_slide]';
  					}
  					
  $code = $code . '[/flexslider]';
  
  
  $data = $data . do_shortcode($code);
  
  }
 
  
  }else{
  if($the_post_thumbnail !=''){
 	$data = $data . '<a href="'.$permalink.'">'.$the_post_thumbnail.'</a>';
   }  
  }	
    
  $data = $data .'<div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>'.do_shortcode('[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" icon="icon-circle-arrow-right" text="'.__('Read More','code125').'" link="'.$permalink.'"]').'</article>'
  
  
  ?>