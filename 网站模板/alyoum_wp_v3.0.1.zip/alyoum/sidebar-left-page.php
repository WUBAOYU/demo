					<?php if ( is_active_sidebar( 'left-page' ) ) : ?>

						<?php dynamic_sidebar( 'left-page' ); ?>

					<?php else : ?>

						

					<?php endif; ?>