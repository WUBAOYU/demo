<?php
/*
Template Name: Login Page Template
*/
?><?php get_header(); 
$meta_values = get_post_custom($post->ID);

			 
			 if(!isset($meta_values['meta_layout'][0])){
			 	$meta_values['meta_layout'][0] = 'right';
			 }
			 
			 
			 if( $meta_values['meta_layout'][0] == 'right' || $meta_values['meta_layout'][0] == 'left'){
			 	
			 	$main_class= 'span8';
			 	
			 }else{
			 
			 	$main_class= 'span12';
			 
			 }
			 
			  ?>
			 
				<div id="inner-content" class="wrap clearfix">
					<?php 
					
					if(!isset($meta_values['meta_breadcrumbs'][0])){
						$meta_values['meta_breadcrumbs'][0] = 'yes';
					} 
					if($meta_values['meta_breadcrumbs'][0] == 'yes'){ ?>
					<div class="title_wrap row-fluid">
						<div class="border">
							<div id="title_crumb">
								<h1 class="heading1"><?php echo $post->post_title; ?></h1>
								<div class="clearfix"></div>
								<?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
								</div>
								<div class="arrow_down"></div>
						
						<div class="clearfix"></div>
						</div>
					</div>
					
					<?php }
					
					 ?>
					
					<div id="inner-page-content">
					<div class="row-fluid">
				    <?php if ($meta_values['meta_layout'][0] == 'left') { ?>
				    
				    <div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				    	
				    	<?php
				    	if(!isset($meta_values['meta_sidebar'][0])){
				    		$meta_values['meta_sidebar'][0] = 'default';
				    	}
				    	
				    	if ($meta_values['meta_sidebar'][0] == "default") {
				    	    get_sidebar('page'); // sidebar Page 
				    	} else {
				    	    if($meta_values['meta_sidebar'][0] == 'primary'){
				    	    	get_sidebar();
				    	    }else{
				    	    	dynamic_sidebar($meta_values['meta_sidebar'][0]);
				    	    }
				    	}
				    	?>
				    	
				    </div>	
				    <?php 	
				    	
				    } ?>
				    
				    <div id="main" class="<?php echo $main_class ?>  clearfix" role="main">

					    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					    <article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
						
						    					
						    <section class="post-content clearfix" itemprop="articleBody">
						     <?php 
						      the_content(); ?>
						       <div style="height: 30px;"></div>
						       	<form name="loginform" id="loginform" action="<?php echo home_url() ?>/wp-login.php" method="post" class="clearfix">
						       				
						       					<input type="text" name="log" class="element-block" id="user_login" class="input" placeholder="<?php _e('username','code125') ?>" size="20" />
						       					<input type="password" name="pwd" class="element-block" id="user_pass" class="input" placeholder="<?php _e('******','code125') ?>" size="20" />
						       				
						       				<p class="login-submit">
						       					<input type="submit" name="wp-submit" id="wp-submit" class="button-primary" value="Log In">
						       					<label><input name="rememberme" type="checkbox" id="rememberme" value="forever"><?php _e( 'Remember Me','code125')?></label>
						       					<a class="button-primary" href="<?php echo wp_lostpassword_url( home_url() ); ?>"><?php _e('Forget Password','code125')?></a>
						       					<a class="button-primary" href="<?php echo home_url() ?>/wp-login.php?action=register"><?php _e('Register','code125')?></a>
						       					<input type="hidden" name="redirect_to" value="<?php echo get_permalink() ?>">
						       				</p>
						       				
						       			</form>
						      						
						       </section> <!-- end article section -->
												  
					
					    </article> <!-- end article -->
					
					    <?php endwhile; ?>		
					
					    <?php else : ?>
					
    					    <article id="post-not-found" class="hentry clearfix">
    					    	<header class="article-header">
    					    		<h1><?php _e("Oops, Post Not Found!", "code125"); ?></h1>
    					    	</header>
    					    	<section class="post-content">
    					    		<p><?php _e("Uh Oh. Something is missing. Try double checking things.", "code125"); ?></p>
    					    		 <?php wp_link_pages( $args ); ?>
    					    	</section>
    					    	<footer class="article-footer">
    					    	    <p><?php _e("This is the error message in the page.php template.", "code125"); ?></p>
    					    	</footer>
    					    </article>
					
					    <?php endif; ?>
			
    				</div> <!-- end #main -->
    
				   <?php if ( $meta_values['meta_layout'][0] == 'right'  ) { ?>
				   	
				   	<div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				   		
				   		<?php
				   		if(!isset($meta_values['meta_sidebar'][0])){
				   			$meta_values['meta_sidebar'][0] = 'default';
				   		}
				   		
				   		if ($meta_values['meta_sidebar'][0] == "default") {
				   		    get_sidebar('page'); // sidebar Page 
				   		} else {
				   			if($meta_values['meta_sidebar'][0] == 'primary'){
				   				get_sidebar();
				   			}else{
				   		    	dynamic_sidebar($meta_values['meta_sidebar'][0]);
				   		    }
				   		}
				   		?>
				   		
				   	</div>
				   
				   <?php } ?>
				    
				    </div>
				    </div>
				</div> <!-- end #inner-content -->
    

<?php get_footer(); ?>