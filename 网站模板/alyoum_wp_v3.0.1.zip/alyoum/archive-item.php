<?php get_header(); ?>

<div id="content">

    <div id="inner-content" class="wrap  clearfix">


        <?php if (is_tag()) {
            ?> 

            <div class="title_wrap">
                <div class="border">
                    <div id="title_crumb">
                        <h1 class="heading1"><?php _e("Articles Tagged:", "code125"); ?> <?php single_tag_title(); ?></h1>
                        <?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>

            <?php
        }  elseif (is_day()) { ?>

            <div class="title_wrap">
                <div class="border">
                    <div id="title_crumb">
                        <h1 class="heading1"><?php _e("Daily Archives:", "code125"); ?> <?php the_time('l, F j, Y'); ?></h1>
                        <?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>


        <?php } elseif (is_month()) { ?>
            <div class="title_wrap">
                <div class="border">
                    <div id="title_crumb">
                        <h1 class="heading1"><?php _e("Monthly Archives:", "code125"); ?> <?php the_time('F Y'); ?></h1>
                        <?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>


        <?php } elseif (is_year()) { ?>
            <div class="title_wrap">
                <div class="border">
                    <div id="title_crumb">
                        <h1 class="title"><?php _e("Yearly Archives:", "code125"); ?> <?php the_time('Y'); ?>
                        </h1>
                        <?php if (function_exists('code125_breadcrumbs')) code125_breadcrumbs(); ?>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>

        <?php } ?>
        <div id="inner-page-content">
        <div class="border">
        <div class="row-fluid">
        <div id="main" class="span8  clearfix" role="main">
        <?php $result_type = ot_get_option( 'result_type' );
        
        if($result_type == '5'){
        	echo '<div id="blog-5" class=" blog-5 small clearfix">';
        } ?>
        					    <?php if (have_posts()) : while (have_posts()) : the_post(); 
        					    
        					    
        					    
        					     $data = '';	
        					     if($result_type == '2'){
        					     	include(TEMPLATEPATH . '/item-style2.php');
        					     }elseif ($result_type == '5') {
        					     	include(TEMPLATEPATH . '/item-style5.php');
        					     }else {
        					     	include(TEMPLATEPATH . '/item-style1.php');
        					     }
        					     
        					      				      
        					       	echo $data; 
        					    
        					     endwhile; 	
        					     if($result_type == '5'){
        					     	echo '</div>';
        					     }
        					     ?>
        					
        					        <?php if (function_exists('bones_page_navi')) { // if experimental feature is active ?>
        						
        						        <?php bones_page_navi(); // use the page navi function ?>
        
        					        <?php } else { // if it is disabled, display regular wp prev & next links ?>
        						        <nav class="wp-prev-next">
        							        <ul class="clearfix">
        								        <li class="prev-link"><?php next_posts_link(_e('&laquo; Older Entries', "code125")) ?></li>
        								        <li class="next-link"><?php previous_posts_link(_e('Newer Entries &raquo;', "code125")) ?></li>
        							        </ul>
        					    	    </nav>
        					        <?php } ?>
        					
        					    <?php else : ?>
        					
            					    <article id="post-not-found" class="hentry clearfix">
            						    <header class="article-header">
            							    <h1><?php _e("Sorry, No Results.", "code125"); ?></h1>
            					    	</header>
            						    <section class="post-content">
            							    <p><?php _e("Try your search again.", "code125"); ?></p>
                						</section>
            	    					
            				    	</article>
        					
        					    <?php endif; ?>
        			
            				</div> <!-- end #main -->
            							   	
            							   	<div id="sidebar" class="sidebar span4 clearfix" role="complementary">
            							   		
            							   		<?php
            							   		
            							   		    get_sidebar('page'); // sidebar Page 
            							   		
            							   		?>
            							   		
            							   	</div>
            							   
                        
                        </div> <!-- end #inner-content -->
                        
        			</div> <!-- end #content -->
        			</div>

    </div> <!-- end #content -->
</div>
</div>
</div>

<?php get_footer(); ?>