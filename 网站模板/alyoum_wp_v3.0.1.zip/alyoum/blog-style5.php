<?php ob_start();
 		 the_permalink();
 		 $permalink = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_title();
 		 $the_title = ob_get_contents();
 		 ob_end_clean();
 		
 		
 		if($GLOBALS['metro-size'] =='small'){
 			$size_prefix= 'metro';
 		}else {
 			$size_prefix= 'mixed';
 		}
  
 		 $id_link = get_post_thumbnail_id(get_the_ID());
 		 
 		 $image_url = wp_get_attachment_image_src( $id_link, $size_prefix . '-size-4');
 		 
 		 $image_url2 = wp_get_attachment_image_src( $id_link, 'full');
 		
 		$meta_values = get_post_custom(get_the_ID());
 		 if(!isset($meta_values['meta_metro_size'][0])){
 		 		$meta_values['meta_metro_size'][0] = 'medium';
 		 }
 		 
 		 if($meta_values['meta_metro_size'][0] == 'large'){
 		 	 $image_url = wp_get_attachment_image_src( $id_link, $size_prefix . '-size-1');
 		 	
 		 }elseif ($meta_values['meta_metro_size'][0] == 'wide') {
 		 	$image_url = wp_get_attachment_image_src( $id_link, $size_prefix . '-size-2');
 		 }elseif ($meta_values['meta_metro_size'][0] == 'tall') {
 		 	$image_url = wp_get_attachment_image_src( $id_link, $size_prefix . '-size-3');
 		 }
  		
  if(is_array($image_url)){ 
   $category = get_the_category(get_the_ID());
   
    
    	
  	$data = $data . '<div class="flip-post element '.$meta_values['meta_metro_size'][0].' '. $category[0]->slug .' clearfix"><div class="flip-wrap">';
  	if(!isset($meta_values['meta_metro'][0])){
   		$meta_values['meta_metro'][0] = 'photo';
   	}
   	
   	if($meta_values['meta_metro'][0] == 'photo'){
   		$data = $data . '<div class="post-front">';
   		$data = $data . '<img src="'. $image_url[0] .'" alt="" />';
   		$data = $data . '</div><div class="post-back post-data-bg">';
   		$data = $data . '<div class="post-back-wrap">';
   		
   		$data = $data . '<a class="cat-link" href="'.get_category_link($category[0]->term_id).'"><span class="'.get_option( 'category_icon_' . $category[0]->term_id ).'"></span></a>';
   		
   		
   		
   		$data = $data . '<a class="title-link" href="'. $permalink.'">'. $the_title .'</a>';
   		
   		
   		$data = $data . '</div></div>';
   	
   	}else {
		$data = $data . '<div class="post-front post-data-bg">';
		$data = $data . '<div class="post-back-wrap">';
		
		$data = $data . '<a class="cat-link" href="'.get_category_link($category[0]->term_id).'"><span class="'.get_option( 'category_icon_' . $category[0]->term_id ).'"></span></a>';
		
		
		
		$data = $data . '<a class="title-link" href="'. $permalink.'">'. $the_title .'</a>';
		$data = $data . '</div></div><div class="post-back">';
		$data = $data . '<a  href="'. $permalink.'"><img src="'. $image_url[0] .'" alt="" /></a>';
		
		$data = $data . '</div>';
	}
   	
   	$data = $data . '</div></div>';
   	 	
   }
  ?>