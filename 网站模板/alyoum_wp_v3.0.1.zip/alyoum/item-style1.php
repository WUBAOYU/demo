
 	<?php ob_start();
 		 the_permalink();
 		 $permalink = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_title();
 		 $the_title = ob_get_contents();
 		 ob_end_clean();
  
 		 
  				ob_start();
  				the_author_posts_link();
  				$the_author_posts_link = ob_get_contents();
  				ob_end_clean();
  
 		 ob_start();
 		 the_post_thumbnail('blog-post-thumb');
 		 $the_post_thumbnail = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_excerpt_max_charlength(300);
 		 $the_excerpt_max_charlength = ob_get_contents();
 		 ob_end_clean();
  		
  		
  	
  
  
  $meta_values = get_post_custom(get_the_ID());
  $user_ID =  get_the_author_meta('ID') ;
  $facebook_user = get_the_author_meta( 'facebook', $user_ID);
  $twitter_user = get_the_author_meta( 'twitter', $user_ID);
  $position_user = get_the_author_meta( 'position', $user_ID);
  
  $data = $data . '<article class="blog-thumb style_1 clearfix"><h2 class=" blogtitle"><a class="title" href="'.$permalink.'">';
  
  if(is_sticky()){
  	$data = $data . '<span class="sticky icon-paper-clip"> </span> ';
  }
  $data = $data . $the_title.'</a></h2>';


 
  $data = $data . '<ul class="meta-entry clearfix"><li><p><span class="icon-user"> </span> '.$the_author_posts_link.'</p></li><li><p><span class="icon-calendar"> </span> '.get_the_time('F') .' '. get_the_time('j') .', '. get_the_time('Y').'</p></li><li>'.getPostLikeLink(get_the_ID()).'</li><li>'.get_stars_average(get_the_ID()).'</li></ul><div class="clearfix"></div>'; 
  
  
  
  
  
    if($the_post_thumbnail !=''){
 	$data = $data . '<a href="'.$permalink.'">'.$the_post_thumbnail.'</a>';
   }  
   
  $data = $data .'<div class="clearfix"></div><p class="content-short">'.$the_excerpt_max_charlength.'</p>'.do_shortcode('[button_2 color="'.$GLOBALS['primary_color'].'" size="button-med" float="right" icon="icon-circle-arrow-right" text="'.__('Read More','code125').'" link="'.$permalink.'"]').'</article>'
  
  
  ?>