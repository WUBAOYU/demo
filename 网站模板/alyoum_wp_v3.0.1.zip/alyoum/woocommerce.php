<?php get_header(); ?>
<?php 

$layout_obj = new C5_theme_layout();

$layout_obj->build_layout('woocommerce');


 ?>
			

<?php get_footer(); ?>