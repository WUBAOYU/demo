					<?php if ( is_active_sidebar( 'left-default' ) ) : ?>

						<?php dynamic_sidebar( 'left-default' ); ?>

					<?php else : ?>

					<?php endif; ?>