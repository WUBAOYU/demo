<?php get_header(); 
$meta_values = get_post_custom($post->ID);
?>
			
			<div id="content">
			<?php
			
			 
			 if(!isset($meta_values['meta_layout'][0])){
			 	$meta_values['meta_layout'][0] = 'right';
			 }
			 
			 
			 if( $meta_values['meta_layout'][0] == 'right' || $meta_values['meta_layout'][0] == 'left'){
			 	
			 	$main_class= 'span8';
			 	
			 }else{
			 
			 	$main_class= 'span12';
			 
			 }
			 
			  ?>
			 
				<div id="inner-content" class="wrap clearfix">
					<div id="inner-page-content">
					<div class="border">
					<div class="row-fluid">
				    <?php if ($meta_values['meta_layout'][0] == 'left') { ?>
				    
				    <div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				    	
				    	<?php
				    	if(!isset($meta_values['meta_sidebar'][0])){
				    		$meta_values['meta_sidebar'][0] = 'default';
				    	}
				    	
				    	if ($meta_values['meta_sidebar'][0] == "default") {
				    	    get_sidebar('post'); // sidebar Page 
				    	} else {
				    	    dynamic_sidebar($meta_values['meta_sidebar'][0]);
				    	}
				    	?>
				    	
				    </div>	
				    <?php 	
				    	
				    } ?>
				    
				    <div id="main" class="<?php echo $main_class ?>  clearfix" role="main">

					    <?php if (have_posts())  : the_post(); ?>
					
					    <article id="post-<?php the_ID(); ?>" <?php post_class('blog-thumb single post-content clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
					    <h1 class="heading1"><?php echo $post->post_title; ?></h1>
					    
					    <div class="clearfix"></div>
					    	<?php 
					    	 	$data = '';
					    	 	
					    	 	ob_start();
					    	 	         the_permalink();
					    	 	         $permalink = ob_get_contents();
					    	 	         ob_end_clean();
					    	 	 
					    	 	
					    	 	ob_start();
					    	 	the_post_thumbnail('blog-post-thumb-inside');
					    	 	$the_post_thumbnail = ob_get_contents();
					    	 	ob_end_clean();
					    	 	
					    	 	ob_start();
					    	 	the_excerpt_max_charlength(300);
					    	 	$the_excerpt_max_charlength = ob_get_contents();
					    	 	ob_end_clean();
					    	 	
					    	 	$featured_enable_item =  ot_get_option( 'featured_enable_item');
					    	 	if($featured_enable_item!='no'){
					    	 		if($the_post_thumbnail !=''){
					    	 			$data = $data . '<a href="'.$permalink.'">'.$the_post_thumbnail.'</a>';
					    	 	  
					    	 		}
					    	 	}
					    	 		echo $data; 
					    	 	?>
					    	 		<div style="height: 30px;"></div>
					    	 		<ul class="share clearfix">
					    	 			<li class="fb"><div class="fb-like" data-href="<?php the_permalink() ?>" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false"></div></li>
					    	 			<li class="tw"><a href="https://twitter.com/share" class="twitter-share-button">Tweet</a>
					    	 			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></li>
					    	 			<li class="gp"><!-- Place this tag where you want the +1 button to render. -->
					    	 			<div class="g-plusone" data-size="medium" data-href="<?php the_permalink() ?>"></div>
					    	 			
					    	 			<!-- Place this tag after the last +1 button tag. -->
					    	 			<script type="text/javascript">
					    	 			  (function() {
					    	 			    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
					    	 			    po.src = 'https://apis.google.com/js/plusone.js';
					    	 			    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
					    	 			  })();
					    	 			</script></li>
					    	 			<?php 
					    	 			$id_link = get_post_thumbnail_id();
					    	 			
					    	 			$image_url = wp_get_attachment_image_src( $id_link, "full"); 
					    	 			 ?>
					    	 			<li class="pinit"><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink() ?>&media=<?php echo $image_url[0]; ?>&description=<?php echo $the_excerpt_max_charlength; ?>" class="pin-it-button" count-layout="horizontal"><img border="0" src="//assets.pinterest.com/images/PinExt.png" title="Pin It" /></a></li>
					    	 			
					    	 		</ul>
					    	 		<div class="clearfix"></div>
					    	 		
					    	 	
					    	 	<?php
					    	 	
					    	 	the_content();
					    	 	
					    	 	
					    	 	?>
					    	 	<div class="clearfix"></div>
					    	 	<div class="pagination">
					    	 	<?php wp_link_pages(); ?>
					    	 	</div>
					    	 	
					        </article> <!-- end article -->
					
					    	
					
					    <?php else : ?>
					
    					    <article id="post-not-found" class="hentry clearfix">
    					    	<header class="article-header">
    					    		<h1><?php _e("Oops, Post Not Found!", "bonestheme"); ?></h1>
    					    	</header>
    					    	<section class="post-content">
    					    		<p><?php _e("Uh Oh. Something is missing. Try double checking things.", "bonestheme"); ?></p>
    					    	</section>
    					    	<footer class="article-footer">
    					    	    <p><?php _e("This is the error message in the page.php template.", "bonestheme"); ?></p>
    					    	</footer>
    					    </article>
					
					    <?php endif; ?>
			
    				</div> <!-- end #main -->
    				
    			
				  <?php
				  if(!isset($meta_values['meta_layout'][0])){
				  	$meta_values['meta_layout'][0] = 'right';
				  }
				  
				   if ( $meta_values['meta_layout'][0] == 'right'  ) { ?>
				  				   	
				  				   	<div id="sidebar" class="sidebar span4 clearfix" role="complementary">
				  				   		
				  				   		<?php
				  				   		if(!isset($meta_values['meta_sidebar'][0])){
				  				   			$meta_values['meta_sidebar'][0] = 'default';
				  				   		}
				  				   		
				  				   		if ($meta_values['meta_sidebar'][0] == "default") {
				  				   		    get_sidebar('post'); // sidebar Page 
				  				   		} else {
				  				   		    dynamic_sidebar($meta_values['meta_sidebar'][0]);
				  				   		}
				  				   		?>
				  				   		
				  				   	</div>
				  				   
				  				   <?php } ?>
				  				    
				  				    </div>
				  				    </div>
				  				    </div>
				  				</div> <!-- end #inner-content -->
				      
				  			</div> <!-- end #content -->
				  
				  <?php get_footer(); ?>