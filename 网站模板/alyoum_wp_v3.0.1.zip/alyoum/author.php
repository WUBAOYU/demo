<?php get_header(); ?>

<div id="content">

    <div id="inner-content" class="wrap  clearfix">

<?php

            $curauth = (get_query_var('author_name')) ? get_user_by('slug', get_query_var('author_name')) : get_userdata(get_query_var('author'));
            ?>

       
        <div id="inner-page-content">
            <div class="border">
                <div class="row-fluid">

                   
                    <div id="main" class="span8 clearfix" role="main">
                      <?php
                            $facebook_user = get_the_author_meta('facebook', $curauth->ID);
                            $twitter_user = get_the_author_meta('twitter', $curauth->ID);
                            $position_user = get_the_author_meta('position', $curauth->ID);


                            $google_plus_user = get_the_author_meta('google_plus', $curauth->ID);
                            $behance_user = get_the_author_meta('behance', $curauth->ID);
                            $dribble_user = get_the_author_meta('dribble', $curauth->ID);

                            $data = '<div class="row-fluid  meta-data-single"><div class="span2">';

                            $data = $data . get_avatar($curauth->ID, '100', '', '<span class="icon-user"></span>') . '</div><div class="span3 article_author"><a >' . $curauth->display_name . '</a><p>' . $position_user . '</p><div class="clearfix"></div>';
                            if ($twitter_user != '') {
                                $data = $data . '<div class=""><a href="https://twitter.com/' . $twitter_user . '" class="twitter-follow-button" data-show-count="false" data-show-screen-name="false">Follow @' . $twitter_user . '</a>
					    		<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div>';
                            }

                            if ($facebook_user != '') {
                                $data = $data . '<div class="float_left_fb"><div class="fb-follow" data-href="https://www.facebook.com/' . $facebook_user . '" data-layout="button_count" data-show-faces="true" data-font="verdana" data-width="100"></div></div>';
                            }
                            echo $data;
                            $data = '';
                            ?>
                        </div>
                        <div class="span7">
                            <ul class="social-icons clearfix">
                                <?php
                                if ($facebook_user != '') {
                                    echo '<li><a href="http://www.facebook.com/people/@/' . $facebook_user . '" class="icon-facebook"></a></li>';
                                }

                                if ($twitter_user != '') {
                                    echo '<li><a href="http://www.twitter.com/' . $twitter_user . '" class="icon-twitter"></a></li>';
                                }

                                if ($google_plus_user != '') {
                                    echo '<li><a href="' . $google_plus_user . '" class="icon-google-plus"></a></li>';
                                }

                                if ($behance_user != '') {
                                    echo '<li><a href="' . $behance_user . '" class="code125-social-behance"></a></li>';
                                }

                                if ($dribble_user != '') {
                                    echo '<li><a href="' . $dribble_user . '" class="code125-social-dribble"></a></li>';
                                }

                                if ($curauth->user_email != '') {
                                    echo '<li><a href="mailto:' . $curauth->user_email . '" class="icon-envelope-alt"></a></li>';
                                }

                                if ($curauth->user_url != '') {
                                    echo '<li><a href="' . $curauth->user_url . '" class="icon-link"></a></li>';
                                }
                                ?>
                            </ul>
                            <?php
                            echo '<p class="author_description arrow_left"><span class="arrow-left"></span>' . $curauth->user_description . '</p>';
                            ?>
                        </div>
                    </div>
                    <div style="height: 30px;"></div>


              
                    <?php $result_type = ot_get_option( 'result_type' );
                    
                    if($result_type == '5'){
                    	echo '<div id="blog-5" class="blog-5 small clearfix">';
                    } ?>
                    					    <?php if (have_posts()) : while (have_posts()) : the_post(); 
                    					    
                    					    
                    					    
                    					     $data = '';	
                    					     if($result_type == '2'){
                    					     	include(TEMPLATEPATH . '/blog-style2.php');
                    					     }elseif ($result_type == '5') {
                    					     	include(TEMPLATEPATH . '/blog-style5.php');
                    					     }else {
                    					     	include(TEMPLATEPATH . '/blog-style1.php');
                    					     }
                    					     
                    					      				      
                    					       	echo $data; 
                    					    
                    					     endwhile; 	
                    					     if($result_type == '5'){
                    					     	echo '</div>';
                    					     }
                    					     ?>
                    					
                    					        <?php if (function_exists('bones_page_navi')) { // if experimental feature is active ?>
                    						
                    						        <?php bones_page_navi(); // use the page navi function ?>
                    
                    					        <?php } else { // if it is disabled, display regular wp prev & next links ?>
                    						        <nav class="wp-prev-next">
                    							        <ul class="clearfix">
                    								        <li class="prev-link"><?php next_posts_link(_e('&laquo; Older Entries', "code125")) ?></li>
                    								        <li class="next-link"><?php previous_posts_link(_e('Newer Entries &raquo;', "code125")) ?></li>
                    							        </ul>
                    					    	    </nav>
                    					        <?php } ?>
                    					
                    					    <?php else : ?>
                    					
                        					    <article id="post-not-found" class="hentry clearfix">
                        						    <header class="article-header">
                        							    <h1><?php _e("Sorry, No Results.", "code125"); ?></h1>
                        					    	</header>
                        						    <section class="post-content">
                        							    <p><?php _e("Try your search again.", "code125"); ?></p>
                            						</section>
                        	    					
                        				    	</article>
                    					
                    					    <?php endif; ?>
                    			
                    

            </div> <!-- end #main -->
                <div id="sidebar" class="sidebar span4 clearfix" role="complementary">

                    <?php
                    get_sidebar('page'); // sidebar Page 
                    ?>

                </div>
            

        </div> <!-- end #inner-content -->

    </div> <!-- end #content -->
</div>
</div>
</div>

<?php get_footer(); ?>