<?php



define('C5_ROOT', get_template_directory() . '/');
define('C5_URL', get_template_directory_uri() . '/');

//require_once(C5_ROOT . 'library/includes/wp-less.php' );
require_once(C5_ROOT . 'library/bones.php' ); // if you remove this, bones will break

require_once(C5_ROOT . 'library/includes/awesome-builder/loader.php' );
require_once(C5_ROOT . 'library/includes/skins/loader.php' );

require_once(C5_ROOT . 'library/includes/admin-ui/C5_admin_ui.php' );
require_once(C5_ROOT . 'library/includes/option-tree/c5-loader.php' );
require_once(C5_ROOT . 'library/includes/option-tree/theme-options.php' );
require_once(C5_ROOT . 'library/includes/category/category.php' );
require_once(C5_ROOT . 'library/includes/custom-post-type/c5-custom-post.php' );
require_once(C5_ROOT . 'library/includes/article/like.php' );
require_once(C5_ROOT . 'library/includes/article/article-content.php' );
require_once(C5_ROOT . 'library/includes/meta-boxes.php' );
require_once(C5_ROOT . 'library/includes/post-formats.php' );
require_once(C5_ROOT . 'library/includes/layout/layout.php' );
require_once(C5_ROOT . 'library/includes/header/build-header.php' );
require_once(C5_ROOT . 'library/includes/bread-crumb.php' );
require_once(C5_ROOT . 'library/includes/article/social-share-count.php' );
require_once(C5_ROOT . 'library/includes/preview/preview.php' );


require_once(C5_ROOT . 'library/includes/widget-import-export/widget-data.php' );
require_once(C5_ROOT . 'library/includes/update_notifier.php' );
require_once(C5_ROOT . 'library/includes/tgm-plugin-activation/class-tgm-plugin-activation.php' );
require_once(C5_ROOT . 'library/includes/tgm-plugin-activation/revslider.php' );
require_once(C5_ROOT . 'library/includes/auto-import/c5_import_class.php' );


require_once(C5_ROOT . 'library/translation/translation.php' );

add_action( 'after_setup_theme', 'c5_basic_file_loading', 2 );
function c5_basic_file_loading() {
	
	require_once(C5_ROOT . 'library/includes/article/rating.php' );
	require_once(C5_ROOT . 'library/includes/menu/C5_menu.php' );
	require_once(C5_ROOT . 'library/includes/menu/menu.php' );
	
	require_once(C5_ROOT . 'library/includes/blog/C5_post.php' );
	require_once(C5_ROOT . 'library/includes/blog/posts.php' );	
}


function c5_import_admin_notice() {
    ?>
    	<input type="hidden" name="website_dir" id="website_dir" value="<?php echo home_url(); ?>" />
    	<style>
    		#option-tree-settings-api .ui-tabs,
    		.ot-metabox-wrapper{
    			direction: ltr;
    		}
    		
    		#wp-admin-bar-c5_install_demo{
    			cursor: pointer;
    		}
    		.mfp-install-demo-post.mfp-auto-cursor  .mfp-content{
    			max-width:500px;
    			background: white;
    			padding: 30px;
    		}
    		
    		.btn {
    		display: inline-block;
    		padding: 8px 12px;
    		margin-bottom: 0;
    		font-size: 14px;
    		font-weight: 500;
    		line-height: 1.428571429;
    		text-align: center;
    		white-space: nowrap;
    		vertical-align: middle;
    		cursor: pointer;
    		border: 1px solid transparent;
    		border-radius: 4px;
    		}
    		a.btn{
    			text-decoration:none;
    		}
    		
    		.btn-primary {
    		color: #fff;
    		background-color: #428bca;
    		border-color: #428bca;
    		}
    		
    		.btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active {
    		background-color: #357ebd;
    		border-color: #3071a9;
    		}
    		
    		.btn:hover, .btn:focus {
    		color: #fff;
    		text-decoration: none;
    		}
    	</style>
    <?php
}
add_action( 'admin_notices', 'c5_import_admin_notice' );

function c5_import_admin_js($hook) {
   wp_register_script( 'admin-import-js', get_stylesheet_directory_uri() . '/library/js/js-admin.js', array( 'jquery' ), '', true );
   wp_enqueue_script( 'admin-import-js' );
}
add_action( 'admin_enqueue_scripts', 'c5_import_admin_js' );

/************* ACTIVE SIDEBARS ********************/

// Sidebars & Widgetizes Areas
function c5_register_sidebars() {
	$all_sidebars = array(
		array(
			'id'=>'sidebar',
			'name'=>'Primary Sidebar',
			'description' => 'Default Sidebar for All Pages'
		),
		array(
			'id'=>'article',
			'name'=>'Article Sidebar',
			'description' => 'Default Sidebar for Articles'
		),
		array(
			'id'=>'small_sidebar',
			'name'=>'Small Primary Sidebar',
			'description' => 'Default Small Sidebar for All Pages'
		),
		array(
			'id'=>'small_article',
			'name'=>'Small Article Sidebar',
			'description' => 'Default Small Sidebar for Articles'
		)
	);
	
	$sidebars = ot_get_option('sidebars', array());
	if ($sidebars) {
	    foreach ($sidebars as $sidebar) {
	    	$all_sidebars[] = array(
	    		'id'=>$sidebar['slug'],
	    		'name'=>$sidebar['title'],
	    		'description' => $sidebar['description']
	    	);
	    }
	}
	
	foreach ($all_sidebars as  $sidebar) {
		register_sidebar(array(
			'id' => $sidebar['id'],
			'name' => $sidebar['name'],
			'description' => $sidebar['description'],
			'before_widget' => '<div id="%1$s" class="widget c5_al_widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="title">',
			'after_title' => '</h3>',
		));
	}
	
	
} // don't remove this bracket!

/************* COMMENT LAYOUT *********************/

// Comment Layout
function c5_comments( $comment, $args, $depth ) {
	?>
   <li <?php comment_class(); ?>>
   	<article id="comment-<?php comment_ID(); ?>" class="clearfix">
   		<header class="comment-author vcard clearfix">
   		    <?php /*
   		        this is the new responsive optimized comment image. It used the new HTML5 data-attribute to display comment gravatars on larger screens only. What this means is that on larger posts, mobile sites don't have a ton of requests for comment images. This makes load time incredibly fast! If you'd like to change it back, just replace it with the regular wordpress gravatar call:
   		        echo get_avatar($comment,$size='32',$default='<path_to_url>' );
   		    */ ?>
   		    <!-- custom gravatar call -->
   		    <?php echo get_avatar($comment,$size='64',$default= ot_get_option('avatar') ); ?>
   		    <!-- end custom gravatar call -->
   			<?php printf('<cite class="fn">%s</cite>', get_comment_author_link()) ?><br><time class="time_class" datetime="<?php echo comment_time('Y-m-j'); ?>"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php comment_time('F jS, Y'); ?> </a></time>
   			<?php edit_comment_link(__('(Edit)', 'code125'),'  ','') ?>
   			<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
   		</header>
   		<?php if ($comment->comment_approved == '0') : ?>
      			<div class="alert info">
         			<p><?php _e('Your comment is awaiting moderation.', 'code125') ?></p>
         		</div>
   		<?php endif; ?>
   		<section class="comment_content clearfix">
   			<?php comment_text() ?>
   		</section>
   		
   	</article>
   <!-- </li> is added by wordpress automatically -->
<?php
} // don't remove this bracket!



?>
