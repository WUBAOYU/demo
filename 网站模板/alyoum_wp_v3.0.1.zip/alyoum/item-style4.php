
 	<?php ob_start();
 		 the_permalink();
 		 $permalink = ob_get_contents();
 		 ob_end_clean();
  
 		 ob_start();
 		 the_title();
 		 $the_title = ob_get_contents();
 		 ob_end_clean();
 
  
 		 $id_link = get_post_thumbnail_id(get_the_ID());
 		 
 		 $image_url = wp_get_attachment_image_src( $id_link, 'mixed-size-4');
 		 
 		 $image_url2 = wp_get_attachment_image_src( $id_link, 'full');
 		 
  	
  if(is_array($image_url)){ 
   	
   	$data = $data . '<div class="mini-post">';
   	
    $category = wp_get_post_terms( get_the_ID(), 'item_type');
   	
   	$data = $data . '<div class="dark-mini-wrap thumb-wrap item-cat-'. $category[0]->slug .'">';
   
   	$data = $data . '<a  href="'. $permalink.'"><img src="'. $image_url[0] .'" alt="" /></a>';
  
   	$data = $data . '<p class="dark-mini"><a  href="'. $permalink.'">'. $the_title .'</a></p></div></div>';
   	 	
   }
  ?>